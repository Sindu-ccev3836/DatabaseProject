
# alkali1/__init__.py
__version__ = "1.0.0"
