"""
Alkali Lakehouse configuration utilities.

This package provides canonical, engine-facing helpers for
resolving and managing datastore configuration by ds_alias.

Public APIs:
- get_default_ds_cfg
- update_ds_cfg
- get_ds_cfg
"""

from .ds_cfg import (
    get_default_ds_cfg,
    update_ds_cfg,
    get_ds_cfg
)

__all__ = [
    "get_default_ds_cfg",
    "update_ds_cfg",
    "get_ds_cfg"
]
