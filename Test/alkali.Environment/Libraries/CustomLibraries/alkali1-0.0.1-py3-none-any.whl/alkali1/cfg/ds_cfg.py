from pyspark.sql import functions as F
from alkali1.io.lh import read_table


def get_default_ds_cfg(
    spark,
    env: str,
    ver: str,
    cfg_ws_id: str,
    cfg_ws_name: str,
    cfg_ds_type: str,     # kept for API compatibility
    cfg_ds_id: str,
    cfg_ds_name: str,
    cfg_ds_schema: str,
    cfg_ds_table: str,
    retry_number: int = 0,
    logger=None,
    fail_on_missing_alias: bool = False,
):
    """
    Build and return the default datastore configuration for the Alkali
    Lakehouse platform as a dictionary keyed by ds_alias.

    This function reads datastore metadata from a cross-workspace configuration
    table (scoped by env and ver) and materializes an engine-ready datastore
    contract optimized for runtime resolution by ds_alias.

    The returned structure enables O(1) lookup for datastore configuration
    during execution planning and runtime resolution.

    The default Alkali Lakehouse datastore domains include:
      - Landing
      - Bronze / Bronze Staging
      - Silver
      - Gold
      - ETL Config / Control
      - ETL Log
      - Schema History
      - Data Quality (DQ)
      - Monitoring
      - Audit
      - Master Data
      - AI
      - AI Contract

    Design principles:
      - Engine-first contract (dict keyed by ds_alias)
      - Pure function (no global variables, no side effects)
      - Deterministic output for the same (env, ver)
      - Clear separation of logical alias vs physical configuration

    Parameters
    ----------
    spark : SparkSession
        Active Spark session
    env : str
        Environment identifier (e.g. DEV, QAT, PROD)
    ver : str
        Configuration version (e.g. 1.0.0)
    cfg_ws_id, cfg_ws_name, cfg_ds_id, cfg_ds_name, cfg_ds_schema, cfg_ds_table : str
        Location of the cross-workspace configuration table
    retry_number : int, optional
        Retry count for config table access
    logger : optional
        Logger passed through to read_table
    fail_on_missing_alias : bool, optional
        If True, raises an error when required datastore aliases are missing

    Returns
    -------
    dict[str, dict]
        Dictionary keyed by ds_alias. Each value contains:
          - ds_type
          - workspace (ws_id, ws_name)
          - datastore (ds_id, ds_name)
    """

    # --------------------------------------------------------------
    # 1) Read config table
    # --------------------------------------------------------------
    df = (
        read_table(
            spark=spark,
            ws_id=cfg_ws_id,
            ws_name=cfg_ws_name,
            ds_id=cfg_ds_id,
            ds_name=cfg_ds_name,
            schema=cfg_ds_schema,
            table=cfg_ds_table,
            retry_number=retry_number,
            logger=logger,
        )
        .filter((F.col("env") == env) & (F.col("ver") == ver))
        .select("ds_alias", "ds_type", "ws_id", "ws_name", "ds_id", "ds_name")
    )

    rows = df.collect()
    alias_map = {r["ds_alias"]: r.asDict() for r in rows}

    # --------------------------------------------------------------
    # 2) Optional validation
    # --------------------------------------------------------------
    required_aliases = {
        "landing",
        "bronze",
        "silver",
        "gold",
        "bronze_stg",
        "etl_config",
        "etl_ctrl",
        "etl_log",
        "schema_history",
        "dq",
        "monitor",
        "audit",
        "master",
        "ai",
        "ai_contract",
    }

    missing = required_aliases - alias_map.keys()
    if fail_on_missing_alias and missing:
        raise ValueError(
            f"Missing required ds_alias for env={env}, ver={ver}: {sorted(missing)}"
        )

    # --------------------------------------------------------------
    # 3) Helper to build canonical config block
    # --------------------------------------------------------------
    def build_cfg(alias: str):
        row = alias_map.get(alias)
        if not row:
            return {
                "ds_type": None,
                "workspace": {"ws_id": None, "ws_name": None},
                "datastore": {"ds_id": None, "ds_name": None},
            }

        return {
            "ds_type": row["ds_type"],
            "workspace": {
                "ws_id": row["ws_id"],
                "ws_name": row["ws_name"],
            },
            "datastore": {
                "ds_id": row["ds_id"],
                "ds_name": row["ds_name"],
            },
        }

    # --------------------------------------------------------------
    # 4) Build engine-facing datastore map
    # --------------------------------------------------------------
    ds_stores = {
        "landing_ds":        build_cfg("landing"),
        "bronze_ds":         build_cfg("bronze"),
        "silver_ds":         build_cfg("silver"),
        "gold_ds":           build_cfg("gold"),
        "bronze_stg_ds":     build_cfg("bronze_stg"),

        "etl_config_ds":     build_cfg("etl_config"),
        "etl_ctrl_ds":       build_cfg("etl_config"),   # mirrors existing behaviour

        "dq_ds":             build_cfg("dq"),
        "log_ds":            build_cfg("etl_log"),
        "schema_history_ds": build_cfg("etl_log"),      # mirrors existing behaviour

        "monitor_ds":        build_cfg("monitor"),
        "audit_ds":          build_cfg("audit"),
        "master_ds":         build_cfg("master"),
        "ai_ds":             build_cfg("ai"),
        "ai_contract_ds":    build_cfg("ai_contract"),
    }

    return ds_stores


def update_ds_cfg(
    spark,
    ds_stores: dict,
    ds_alias: str,
    ds_type: str,
    ws_name: str,
    ws_id: str,
    ds_name: str,
    ds_id: str,
    logger=None,
):
    """
    Update or insert a single datastore configuration in a ds_stores dictionary
    returned by get_default_ds_config().

    This function updates the datastore configuration identified by ds_alias,
    allowing runtime or engine-level overrides of physical datastore bindings
    (e.g. workspace, datastore, or type).

    Parameters
    ----------
    spark : SparkSession
        Active Spark session (kept for API consistency; not used directly)
    ds_stores : dict
        Dictionary keyed by ds_alias, as returned by get_default_ds_config()
    ds_alias : str
        Logical datastore alias to update (e.g. 'silver_ds', 'ai_contract_ds')
    ds_type : str
        Datastore type (e.g. LAKEHOUSE, WAREHOUSE)
    ws_name : str
        Workspace name
    ws_id : str
        Workspace ID
    ds_name : str
        Datastore name
    ds_id : str
        Datastore ID
    logger : optional
        Logger for audit/debug messages

    Returns
    -------
    dict
        The updated ds_stores dictionary (same object, mutated in place)
    """

    if not ds_alias:
        raise ValueError("ds_alias must be provided")

    ds_stores[ds_alias] = {
        "ds_type": ds_type,
        "workspace": {
            "ws_id": ws_id,
            "ws_name": ws_name,
        },
        "datastore": {
            "ds_id": ds_id,
            "ds_name": ds_name,
        },
    }

    if logger:
        logger.info(
            f"Datastore config updated: ds_alias={ds_alias}, "
            f"ds_type={ds_type}, ws_name={ws_name}, ds_name={ds_name}"
        )

    return ds_stores

def get_ds_cfg(
    spark,
    ds_stores: dict,
    ds_alias: str,
    logger=None,
):
    """
    Resolve a datastore configuration from ds_stores by ds_alias.

    This function returns a flattened datastore configuration dictionary
    containing workspace and datastore identifiers, suitable for direct
    consumption by engines, activities, and file loaders.

    Parameters
    ----------
    spark : SparkSession
        Active Spark session (kept for API consistency; not used directly)
    ds_stores : dict
        Datastore configuration dictionary keyed by ds_alias
    ds_alias : str
        Logical datastore alias (e.g. 'silver_ds', 'ai_contract_ds')
    logger : optional
        Logger for debug or audit messages

    Returns
    -------
    dict
        {
            "ds_type": str,
            "ws_id": str,
            "ws_name": str,
            "ds_id": str,
            "ds_name": str
        }
    """

    if not isinstance(ds_stores, dict):
        raise ValueError("ds_stores must be a dictionary keyed by ds_alias")

    if ds_alias not in ds_stores:
        raise KeyError(f"Unknown datastore alias: {ds_alias}")

    cfg = ds_stores[ds_alias]

    result = {
        "ds_type": cfg.get("ds_type"),
        "ws_id": cfg.get("workspace", {}).get("ws_id"),
        "ws_name": cfg.get("workspace", {}).get("ws_name"),
        "ds_id": cfg.get("datastore", {}).get("ds_id"),
        "ds_name": cfg.get("datastore", {}).get("ds_name"),
    }

    if logger:
        logger.debug(f"Resolved datastore config for alias='{ds_alias}': {result}")

    return result

