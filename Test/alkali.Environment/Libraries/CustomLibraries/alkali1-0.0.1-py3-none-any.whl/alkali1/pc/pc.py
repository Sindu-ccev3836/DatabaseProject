from __future__ import annotations

import copy
import json
import re
from typing import Any, Dict, List, Optional, Set


# Supports placeholders in both full-value and embedded-string forms, e.g.
# "<param_name>" and "https://host/path_<param_name>".
# Optional whitespace inside angle brackets is tolerated, e.g. "< param_name >".
_PLACEHOLDER_RE = re.compile(r"<\s*([A-Za-z0-9_]+)\s*>")


class ParamPCBuildError(RuntimeError):
    """Raised when parameterized PC materialization fails validation."""


def _log(logger: Any, level: str, message: str) -> None:
    if logger is None:
        return
    fn = getattr(logger, level.lower(), None)
    if callable(fn):
        fn(str(message))


def _parse_json_object(name: str, value: str) -> Dict[str, Any]:
    if not isinstance(value, str) or not value.strip():
        raise ParamPCBuildError(f"{name} must be a non-empty JSON string")
    try:
        obj = json.loads(value)
    except Exception as exc:
        raise ParamPCBuildError(f"{name} is not valid JSON: {exc}") from exc
    if not isinstance(obj, dict):
        raise ParamPCBuildError(f"{name} must decode to a JSON object")
    return obj


def _parse_param_list(value: str) -> List[Dict[str, Any]]:
    if not isinstance(value, str) or not value.strip():
        raise ParamPCBuildError("pc_param must be a non-empty JSON string")

    try:
        obj = json.loads(value)
    except Exception as exc:
        raise ParamPCBuildError(f"pc_param is not valid JSON: {exc}") from exc

    if isinstance(obj, list):
        items = obj
    elif isinstance(obj, dict) and isinstance(obj.get("pc_template_params"), list):
        items = obj["pc_template_params"]
    else:
        raise ParamPCBuildError(
            "pc_param must decode to a JSON array of objects "
            "(or an object with key 'pc_template_params')"
        )

    normalized: List[Dict[str, Any]] = []
    for idx, item in enumerate(items):
        if not isinstance(item, dict):
            raise ParamPCBuildError(
                f"pc_param[{idx}] must be a JSON object, got {type(item).__name__}"
            )
        bad_keys = [k for k in item.keys() if not isinstance(k, str) or not k.strip()]
        if bad_keys:
            raise ParamPCBuildError(
                f"pc_param[{idx}] contains non-string or empty parameter names"
            )
        normalized.append(item)
    return normalized


def _collect_placeholders(node: Any) -> Set[str]:
    out: Set[str] = set()
    if isinstance(node, str):
        for m in _PLACEHOLDER_RE.finditer(node):
            out.add(m.group(1))
        return out
    if isinstance(node, list):
        for item in node:
            out.update(_collect_placeholders(item))
        return out
    if isinstance(node, dict):
        for val in node.values():
            out.update(_collect_placeholders(val))
        return out
    return out


def _find_unresolved(node: Any, path: str = "$") -> List[str]:
    findings: List[str] = []
    if isinstance(node, str):
        if _PLACEHOLDER_RE.search(node):
            findings.append(path)
        return findings
    if isinstance(node, list):
        for i, item in enumerate(node):
            findings.extend(_find_unresolved(item, f"{path}[{i}]"))
        return findings
    if isinstance(node, dict):
        for k, v in node.items():
            findings.extend(_find_unresolved(v, f"{path}.{k}"))
        return findings
    return findings


def _replace_in_string(value: str, params: Dict[str, Any], path: str) -> Any:
    full = _PLACEHOLDER_RE.fullmatch(value)
    if full:
        name = full.group(1)
        if name not in params:
            raise ParamPCBuildError(
                f"Missing required param '{name}' while resolving {path}"
            )
        return params[name]

    missing: List[str] = []

    def _repl(match: re.Match[str]) -> str:
        name = match.group(1)
        if name not in params:
            missing.append(name)
            return match.group(0)
        return str(params[name])

    resolved = _PLACEHOLDER_RE.sub(_repl, value)
    if missing:
        missing_unique = sorted(set(missing))
        raise ParamPCBuildError(
            f"Missing required params {missing_unique} while resolving {path}"
        )
    return resolved


def _replace_placeholders(node: Any, params: Dict[str, Any], path: str = "$") -> Any:
    if isinstance(node, str):
        return _replace_in_string(node, params, path)
    if isinstance(node, list):
        return [
            _replace_placeholders(item, params, f"{path}[{idx}]")
            for idx, item in enumerate(node)
        ]
    if isinstance(node, dict):
        return {
            key: _replace_placeholders(value, params, f"{path}.{key}")
            for key, value in node.items()
        }
    return node


def _validate_param_names(required: Set[str], params: Dict[str, Any], index: int) -> None:
    keys = set(params.keys())
    missing = sorted(required - keys)
    extra = sorted(keys - required)
    if missing:
        raise ParamPCBuildError(f"pc_param[{index}] missing required params: {missing}")
    if extra:
        raise ParamPCBuildError(f"pc_param[{index}] has extra parameter names: {extra}")


def _validate_pipeline_names(pipelines: List[Dict[str, Any]]) -> None:
    seen: Set[str] = set()
    duplicates: Set[str] = set()

    for idx, pipeline in enumerate(pipelines):
        name = pipeline.get("pipeline_name")
        if not isinstance(name, str) or not name.strip():
            raise ParamPCBuildError(
                f"pipelines[{idx}] must contain non-empty 'pipeline_name'"
            )
        key = name.strip()
        if key in seen:
            duplicates.add(key)
        seen.add(key)

    if duplicates:
        raise ParamPCBuildError(
            f"Duplicate pipeline names detected: {sorted(duplicates)}"
        )


def build_param_pc(
    pc_template: str,
    pc_param: str,
    logger: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Materialize a parameterized PC template.

    Args:
        pc_template: JSON string for template PC containing `pipeline_template`.
        pc_param: JSON string of parameter maps (list of objects).
        logger: Optional Python logger.

    Notes:
        Placeholders are supported as full string values and as parts of strings,
        for example: "<src_table>" and "https://host.com/endpoint_<endpoint_no>".

    Returns:
        Materialized PC as a Python dict.

    Raises:
        ParamPCBuildError: On parse, validation, or resolution failure.
    """
    _log(logger, "info", "build_param_pc: start")

    template_obj = _parse_json_object("pc_template", pc_template)
    template_pipelines = template_obj.get("pipeline_template")
    if not isinstance(template_pipelines, list) or not template_pipelines:
        raise ParamPCBuildError(
            "pc_template must contain non-empty 'pipeline_template' array"
        )

    static_obj = copy.deepcopy(template_obj)
    static_obj.pop("pipeline_template", None)
    static_unresolved = _find_unresolved(static_obj)
    if static_unresolved:
        raise ParamPCBuildError(
            "Unresolved placeholders found outside 'pipeline_template': "
            f"{static_unresolved}"
        )

    param_list = _parse_param_list(pc_param)
    if not param_list:
        raise ParamPCBuildError("pc_param must contain at least one parameter object")

    required_params = _collect_placeholders(template_pipelines)
    if not required_params:
        raise ParamPCBuildError(
            "pipeline_template contains no placeholders; parameterized expansion is not needed"
        )

    expanded: List[Dict[str, Any]] = []
    for p_idx, params in enumerate(param_list):
        _validate_param_names(required_params, params, p_idx)

        for t_idx, template_pipeline in enumerate(template_pipelines):
            if not isinstance(template_pipeline, dict):
                raise ParamPCBuildError(
                    "pipeline_template items must be JSON objects "
                    f"(got {type(template_pipeline).__name__} at index {t_idx})"
                )

            resolved = _replace_placeholders(
                copy.deepcopy(template_pipeline),
                params,
                path=f"$.pipeline_template[{t_idx}]",
            )
            unresolved = _find_unresolved(resolved, f"$.pipeline_template[{t_idx}]")
            if unresolved:
                raise ParamPCBuildError(
                    f"Unresolved placeholders remain after substitution: {unresolved}"
                )
            expanded.append(resolved)

    _validate_pipeline_names(expanded)

    result = copy.deepcopy(template_obj)
    result.pop("pipeline_template", None)
    result["pipelines"] = expanded

    unresolved_in_result = _find_unresolved(result)
    if unresolved_in_result:
        raise ParamPCBuildError(
            "Unresolved placeholders remain in materialized PC: "
            f"{unresolved_in_result}"
        )

    _log(
        logger,
        "info",
        f"build_param_pc: success pipelines={len(expanded)} params={len(param_list)}",
    )
    return result


__all__ = ["build_param_pc", "ParamPCBuildError"]
