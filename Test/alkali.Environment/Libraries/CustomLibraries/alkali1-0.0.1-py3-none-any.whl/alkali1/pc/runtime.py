# -*- coding: utf-8 -*-
"""
Runtime bootstrap for Alkali PC execution (single-engine).

STARTING POINT:
- Based on the older minimal runtime (validated pc_str only). [2](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/activity_registry.py)

PATCHES:
1) Support env_param["datastores"] in NEW dictionary form keyed by alias
   (still compatible with old list-of-dicts form).
2) Logger safety: ONLY pass ONE STRING to logger.info()/warning()/error()/debug().
   (Avoid AlkaliLogger interpreting positional arg #2 as `extra`.)
3) Engine compatibility: autoload activities/fileloaders + freeze registries.
4) Registry validation: exclude ENGINE-NATIVE activities (e.g. debug.stop) from
   “must be registered” checks, because engine v1.1.5 handles debug.stop natively. [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/engine.py)
"""

from __future__ import annotations

import json
import importlib
import pkgutil
from typing import Any, Dict, List, Set

# Engine module (we call pc_engine and optionally its autoload/freeze helpers)
from .engine import engine as _engine_mod

# Activity registry snapshot for validation / diagnostics
from .engine.activity_registry import registry_specs  # read-only snapshot of registered activities [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/engine.py)


# -----------------------------------------------------------------------------
# Validation helpers
# -----------------------------------------------------------------------------
def _require_non_empty_str(name: str, val: Any) -> str:
    if not isinstance(val, str) or not val.strip():
        raise RuntimeError(f"PC_RUNTIME_ERROR: '{name}' must be a non-empty string")
    return val.strip()


def _require_dict(name: str, val: Any) -> Dict[str, Any]:
    if not isinstance(val, dict):
        raise RuntimeError(f"PC_RUNTIME_ERROR: '{name}' must be a dict, got {type(val).__name__}")
    return val


# -----------------------------------------------------------------------------
# Logger helper — only pass strings to logger.<level>()
# -----------------------------------------------------------------------------
def _log_str(logger, level: str, message: Any) -> None:
    """
    Ensure we call logger.<level>(str_message) with EXACTLY ONE argument.
    This avoids AlkaliLogger signature issues where a 2nd positional arg becomes `extra`.
    """
    if not logger:
        return
    fn = getattr(logger, level.lower(), None)
    if callable(fn):
        fn(str(message))


# -----------------------------------------------------------------------------
# Datastore normalization
# -----------------------------------------------------------------------------
def _normalize_datastores(raw: Any) -> Dict[str, Dict[str, Any]]:
    """
    Normalize env_param["datastores"] into a dict keyed by alias.

    Accepts:
      - NEW form (dict): { "landing_ds": {...}, "bronze_ds": {...}, ... }
      - OLD form (list): [ {"ds_alias": "landing_ds", ...}, ... ]
      - None/empty -> {}

    Returns:
      dict[alias] = cfg, and injects cfg["ds_alias"] = alias if missing
      for backward compatibility with older activity implementations.
    """
    if not raw:
        return {}

    # NEW form: dict keyed by alias
    if isinstance(raw, dict):
        out: Dict[str, Dict[str, Any]] = {}
        for alias, cfg in raw.items():
            if not isinstance(alias, str) or not alias.strip():
                raise RuntimeError("PC_RUNTIME_ERROR: datastore alias keys must be non-empty strings")
            alias = alias.strip()

            if cfg is None:
                cfg = {}
            if not isinstance(cfg, dict):
                raise RuntimeError(
                    f"PC_RUNTIME_ERROR: datastores['{alias}'] must be a dict, got {type(cfg).__name__}"
                )

            # Inject ds_alias for compatibility
            if "ds_alias" not in cfg:
                cfg = dict(cfg)
                cfg["ds_alias"] = alias

            out[alias] = cfg
        return out

    # OLD form: list of dicts
    if isinstance(raw, list):
        out: Dict[str, Dict[str, Any]] = {}
        for i, cfg in enumerate(raw):
            if not isinstance(cfg, dict):
                raise RuntimeError(
                    f"PC_RUNTIME_ERROR: datastores[{i}] must be a dict, got {type(cfg).__name__}"
                )
            alias = cfg.get("ds_alias") or cfg.get("alias")
            if not isinstance(alias, str) or not alias.strip():
                raise RuntimeError(
                    f"PC_RUNTIME_ERROR: datastores[{i}] must include 'ds_alias' (or 'alias') as a non-empty string"
                )
            alias = alias.strip()

            if "ds_alias" not in cfg:
                cfg = dict(cfg)
                cfg["ds_alias"] = alias

            out[alias] = cfg
        return out

    raise RuntimeError(
        "PC_RUNTIME_ERROR: env_param['datastores'] must be a dict or list of dicts, "
        f"got {type(raw).__name__}"
    )


# -----------------------------------------------------------------------------
# PC parsing helpers (for validation checks)
# -----------------------------------------------------------------------------
def _parse_pc(pc_str: str) -> Dict[str, Any]:
    try:
        pc = json.loads(pc_str)
    except Exception as e:
        raise RuntimeError(f"PC_RUNTIME_ERROR: failed to parse pc_str JSON: {e}") from e
    if not isinstance(pc, dict):
        raise RuntimeError("PC_RUNTIME_ERROR: pc_str JSON must be a dict/object")
    return pc


def _extract_pipelines(pc: Dict[str, Any]) -> List[Dict[str, Any]]:
    if isinstance(pc.get("pipelines"), list):
        return pc["pipelines"]
    if isinstance(pc.get("pipeline"), dict):
        return [pc["pipeline"]]
    return []


def _extract_steps(pipeline: Dict[str, Any]) -> List[Dict[str, Any]]:
    if isinstance(pipeline.get("steps"), list):
        return pipeline["steps"]
    if isinstance(pipeline.get("activities"), list):
        return pipeline["activities"]
    return []


def _extract_activity_types(pc: Dict[str, Any]) -> Set[str]:
    required: Set[str] = set()
    for pl in _extract_pipelines(pc):
        for step in _extract_steps(pl):
            at = step.get("activity_type")
            if isinstance(at, str) and at.strip():
                required.add(at.strip())
    return required


# -----------------------------------------------------------------------------
# Autoload helpers
# -----------------------------------------------------------------------------
def _autoload_pkg(pkg_name: str) -> None:
    """
    Recursively import all submodules in a package to trigger activity registration.
    Mirrors the intent of engine autoloading design. [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/engine.py)
    """
    pkg = importlib.import_module(pkg_name)
    if not hasattr(pkg, "__path__"):
        return
    for _, name, _ in pkgutil.iter_modules(pkg.__path__, pkg.__name__ + "."):
        importlib.import_module(name)


def _ensure_activities_loaded(logger=None) -> None:
    """
    Try engine-native autoloaders first; then fallback to common package names.
    """
    # Prefer engine-native autoloaders if present
    if hasattr(_engine_mod, "_autoload_activities"):
        _engine_mod._autoload_activities()
    if hasattr(_engine_mod, "_autoload_fileloaders"):
        _engine_mod._autoload_fileloaders()

    # If registry has content, we are done
    if registry_specs():
        return

    _log_str(logger, "warning", "Activity registry empty after engine autoload; trying fallback package imports")

    # Fallback guesses (safe attempts)
    candidates = [
        "alkali1.pc.engine.activities",
        "alkali1.pc.activities",
        "alkali1.activities",
    ]
    for pkg in candidates:
        try:
            _autoload_pkg(pkg)
        except Exception:
            pass


# -----------------------------------------------------------------------------
# Engine-native activities (do NOT require registry entries)
# -----------------------------------------------------------------------------
# Engine v1.1.5 states debug.stop is engine-native stop point. [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/engine.py)
_ENGINE_NATIVE_ACTIVITIES: Set[str] = {
    "debug.stop",
}


# -----------------------------------------------------------------------------
# Public runtime entrypoint
# -----------------------------------------------------------------------------
def run_pc(
    *,
    spark,
    pc_str: str,
    env_param: Dict[str, Any],
    logger=None,
) -> Dict[str, Any]:
    """
    Alkali1 PC execution entrypoint (single-engine).
    """
    pc_str = _require_non_empty_str("pc_str", pc_str)
    env_param = _require_dict("env_param", env_param)

    pc = _parse_pc(pc_str)

    # Normalize datastores to new dict form
    env_param["datastores"] = _normalize_datastores(env_param.get("datastores"))

    # Log resolved aliases safely (string only)
    _log_str(logger, "info", f"Resolved datastore aliases: {sorted(env_param['datastores'].keys())}")

    # Load activities before engine execution
    _ensure_activities_loaded(logger=logger)

    # Validate registry contains all required activities EXCEPT engine-native ones
    required_all = _extract_activity_types(pc)
    required = set(a for a in required_all if a not in _ENGINE_NATIVE_ACTIVITIES)

    registered = set(registry_specs().keys())
    missing = sorted([a for a in required if a not in registered])

    if missing:
        msg = (
            "PC_RUNTIME_ERROR: Missing activities in registry.\n"
            f"- Required by PC: {sorted(required_all)}\n"
            f"- Engine-native (no registry needed): {sorted(_ENGINE_NATIVE_ACTIVITIES)}\n"
            f"- Missing (non-native): {missing}\n"
            f"- Registered (sample up to 50): {sorted(list(registered))[:50]}\n"
            "Action: ensure the activity modules are importable and call register_activity(...) "
            "for these names."
        )
        _log_str(logger, "error", msg)
        raise RuntimeError(msg)

    # Freeze registries if engine exposes helpers
    # Registry freeze semantics are part of the registry design. [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/engine.py)
    if hasattr(_engine_mod, "freeze_registry"):
        _engine_mod.freeze_registry()
    if hasattr(_engine_mod, "freeze_file_loader_registry"):
        _engine_mod.freeze_file_loader_registry()

    _log_str(logger, "info", "Invoking pc_engine(...)")

    # Invoke engine
    result = _engine_mod.pc_engine(
        spark=spark,
        pc_str=pc_str,
        logger=logger,
        env_param=env_param,
    )

    # Normalize result shape
    if result is None:
        result = {"status": "SUCCESS", "note": "engine returned None", "env_param": env_param}
    elif not isinstance(result, dict):
        result = {"status": "SUCCESS", "engine_result": result, "env_param": env_param}

    _log_str(logger, "info", "PC execution finished")
    return result


# -----------------------------------------------------------------------------
# Backward compatibility
# -----------------------------------------------------------------------------
run_pipeline = run_pc

__all__ = ["run_pc", "run_pipeline"]
