# File: alkalietl/pc/activities/debug_display.py

from __future__ import annotations

from typing import Any, Dict, Optional

import builtins
from pyspark.sql import DataFrame

from alkalietl.pc.activity_api import register_activity
from alkalietl.pc.activities._common import log_info


def _resolve_input_alias(act: Dict[str, Any]) -> Optional[str]:
    """
    Resolve input alias following Alkali activity patterns:
      - prefer act.df_key (debug-specific)
      - else act.input
      - else act.inputs[0]
    """
    alias = act.get("df_key") or act.get("input")
    if alias:
        return alias

    ins = act.get("inputs")
    if isinstance(ins, list) and ins:
        first = ins[0]
        return first if isinstance(first, str) and first.strip() else None

    return None


def _require_bool(act: Dict[str, Any], key: str, default: bool) -> bool:
    v = act.get(key, default)
    if not isinstance(v, bool):
        raise ValueError(f"debug.display_df: '{key}' must be boolean")
    return v


def _optional_int(act: Dict[str, Any], key: str, default: Optional[int]) -> Optional[int]:
    if key not in act:
        return default
    v = act.get(key)
    if v is None:
        return None
    if not isinstance(v, int):
        raise ValueError(f"debug.display_df: '{key}' must be integer or null")
    return v


def _get_display_fn() -> Optional[Any]:
    """
    Try to obtain a notebook display() function.
    Priority:
      1) builtins.display (Fabric notebook commonly exposes this)
      2) IPython.display.display (best-effort fallback)
    Returns:
      callable or None
    """
    if hasattr(builtins, "display"):
        return getattr(builtins, "display")

    try:
        from IPython.display import display as ipy_display  # type: ignore
        return ipy_display
    except Exception:
        return None


@register_activity("debug.display_df")
def debug_display_df(
    ctx: Dict[str, Any],
    act: Dict[str, Any],
    dfs: Dict[str, Any],
    pipeline: Dict[str, Any],
) -> None:
    """
    Debug-only activity: display an in-memory DataFrame/object in notebook output.

    Contract (v1.5.2):
      - Side-effect only (observability). MUST NOT mutate ctx/dfs/PC nodes.
      - MUST NOT affect control flow (unless require_exists=true is explicitly set).
      - If display() unavailable: MUST fall back safely (df.show / print) or skip.

    Supported fields:
      - df_key: string (preferred key into dfs)
      - input / inputs[0]: aliases for df_key (compat)
      - enabled: bool (default True)
      - require_exists: bool (default False) -> if True and key missing => fail-fast
      - require_notebook: bool (default False) -> if True and display() unavailable => skip (no fallback)
      - limit: int|null (default 20 for df.show fallback; display() may ignore)
      - truncate: bool (default False) -> applies to df.show fallback only
      - message: string (optional) -> prefix log / console context
    """

    logger = ctx["logger"]

    # Optional execution-level gating:
    # If execution.debug_mode exists and is false -> skip silently (recommended)
    execution = ctx.get("execution") or {}
    if isinstance(execution, dict) and "debug_mode" in execution:
        if not bool(execution.get("debug_mode")):
            log_info(logger, "activity: debug.display_df (skipped: debug_mode=false)", {
                "activity": act.get("activity_name") or act.get("activity_id"),
                "pipeline": pipeline.get("pipeline_name"),
            })
            return

    enabled = _require_bool(act, "enabled", True)
    if not enabled:
        log_info(logger, "activity: debug.display_df (skipped: enabled=false)", {
            "activity": act.get("activity_name") or act.get("activity_id"),
            "pipeline": pipeline.get("pipeline_name"),
        })
        return

    require_exists = _require_bool(act, "require_exists", False)
    require_notebook = _require_bool(act, "require_notebook", False)
    truncate = _require_bool(act, "truncate", False)
    limit = _optional_int(act, "limit", 20)

    msg = act.get("message")
    if msg is not None and not isinstance(msg, str):
        raise ValueError("debug.display_df: 'message' must be string if provided")

    in_alias = _resolve_input_alias(act)
    if not in_alias:
        # Debug activity is optional; missing input alias should not break execution
        log_info(logger, "activity: debug.display_df (skipped: missing df_key/input)", {
            "activity": act.get("activity_name") or act.get("activity_id"),
            "pipeline": pipeline.get("pipeline_name"),
            "hint": "Provide df_key or input (or inputs[0])",
        })
        return

    if in_alias not in dfs:
        if require_exists:
            raise KeyError(f"debug.display_df: '{in_alias}' not found in dfs")
        log_info(logger, "activity: debug.display_df (skipped: dfs key not found)", {
            "activity": act.get("activity_name") or act.get("activity_id"),
            "pipeline": pipeline.get("pipeline_name"),
            "input": in_alias,
        })
        return

    obj = dfs[in_alias]
    display_fn = _get_display_fn()

    # Log intent (same structured log style used by io activities)
    log_info(logger, "activity: debug.display_df", {
        "activity": act.get("activity_name") or act.get("activity_id"),
        "pipeline": pipeline.get("pipeline_name"),
        "input": in_alias,
        "obj_type": type(obj).__name__,
        "limit": limit,
        "require_notebook": require_notebook,
    })

    # Optional message to console (harmless)
    if msg:
        print(f"[debug.display_df] {msg}")

    # DataFrame handling
    if isinstance(obj, DataFrame):
        df = obj
        if isinstance(limit, int) and limit > 0:
            df = df.limit(limit)

        # Prefer notebook display() if available
        if display_fn is not None:
            try:
                display_fn(df)
                return
            except Exception as e:
                # If display exists but fails, only then fallback unless require_notebook
                log_info(logger, "debug.display_df: display(df) failed", {
                    "input": in_alias,
                    "error": str(e),
                })
                if require_notebook:
                    return

        # Fallback: df.show() (safe in headless runs)
        n = limit if isinstance(limit, int) and limit > 0 else 20
        df.show(n=n, truncate=truncate)
        return

    # Non-DataFrame handling
    if display_fn is not None:
        try:
            display_fn(obj)
            return
        except Exception as e:
            log_info(logger, "debug.display_df: display(obj) failed", {
                "input": in_alias,
                "obj_type": type(obj).__name__,
                "error": str(e),
            })
            if require_notebook:
                return

    # Fallback: print repr (safe in headless runs)
    print(obj)
