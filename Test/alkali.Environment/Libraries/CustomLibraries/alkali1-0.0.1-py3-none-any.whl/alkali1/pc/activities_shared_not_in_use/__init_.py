
"""
Shared, engine-agnostic PC activities.

These modules are intended to be imported and registered by engine
implementations only. They are not part of the public Alkali PC API.
"""

