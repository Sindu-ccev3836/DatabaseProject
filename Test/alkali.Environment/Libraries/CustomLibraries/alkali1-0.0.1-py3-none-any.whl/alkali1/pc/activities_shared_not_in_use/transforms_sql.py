# File: alkalietl/pc/activities/transforms_sql.py
from typing import Any, Dict
from pyspark.sql import DataFrame

from alkalietl.pc.registry import register_activity
from alkalietl.pc.activities._common import log_info


@register_activity("xf.sql")
def xf_sql(ctx: Dict[str, Any], act: Dict[str, Any], dfs: Dict[str, DataFrame], pipeline: Dict[str, Any]) -> None:
    """
    Execute Spark SQL transform.
    Fields:
      - input OR inputs[0]
      - output OR outputs[0]
      - logic (SQL string)
    """
    logger = ctx["logger"]
    spark = ctx["spark"]

    in_alias = act.get("input")
    if not in_alias:
        ins = act.get("inputs")
        if isinstance(ins, list) and ins:
            in_alias = ins[0]
    if not in_alias:
        raise ValueError("xf.sql requires input or inputs[0]")

    out_alias = act.get("output")
    if not out_alias:
        outs = act.get("outputs")
        if isinstance(outs, list) and outs:
            out_alias = outs[0]
    if not out_alias:
        raise ValueError("xf.sql requires output or outputs[0]")

    sql_text = act.get("logic")
    if not isinstance(sql_text, str) or not sql_text.strip():
        raise ValueError("xf.sql requires non-empty logic")

    dfs[in_alias].createOrReplaceTempView("input")
    df_out = spark.sql(sql_text)
    dfs[out_alias] = df_out

    log_info(logger, "activity: xf.sql", {
        "activity": act.get("activity_name") or act.get("activity_id"),
        "in": in_alias,
        "out": out_alias
    })