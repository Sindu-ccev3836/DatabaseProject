"""
Alkali PC execution package.

Public surface:
- run_pc: Execute a Pipeline Contract (PC) with deterministic engine resolution.

Internal modules (engines, activities) are intentionally not exposed here.
"""

from .runtime import run_pc
from .pc import build_param_pc, ParamPCBuildError

__all__ = ["run_pc", "build_param_pc", "ParamPCBuildError"]

# Optional: semantic version of the PC runtime layer
__pc_runtime_version__ = "1.8.0"