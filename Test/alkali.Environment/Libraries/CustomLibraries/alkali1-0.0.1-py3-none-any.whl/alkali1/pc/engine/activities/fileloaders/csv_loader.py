# ===========================================================================
# File Path : alkali1/pc/engine/activities/fileloaders/csv_loader.py
# Version   : v1.4.2 (PC-aligned schema migration + retry support)
# ===========================================================================
# -*- coding: utf-8 -*-

"""
CSV File Loader
"""

from __future__ import annotations
from typing import Dict, Any

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from alkali1.pc.engine.file_loader_registry import register_file_loader
from alkali1.io.lh import read_files, write_table


def _to_int_or_none(v: Any) -> int | None:
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None


def _build_loader_counts(result: Dict[str, Any]) -> Dict[str, int | None]:
    processed = (
        _to_int_or_none(result.get("record_count_processed"))
        or _to_int_or_none(result.get("rows_written"))
        or _to_int_or_none(result.get("written_row_count"))
        or _to_int_or_none(result.get("row_count"))
    )
    src_count = _to_int_or_none(result.get("src_record_count")) or processed
    failed = _to_int_or_none(result.get("failed_count"))
    if failed is None and processed is not None:
        failed = 0

    return {
        "src_record_count": src_count,
        "record_count_processed": processed,
        "failed_count": failed,
    }


def _append_src_file_col_last(df: DataFrame, col_name: str, file: str) -> DataFrame:
    col = col_name.strip()
    ordered = [c for c in df.columns if c != col] + [col]
    return df.withColumn(col, F.lit(file)).select(*ordered)

# ===========================================================================
# 🤖 AI CONTRACT — CSV LOADER (AUTHORITATIVE)
# ===========================================================================
#
# ROLE
# ----
# L0 execution unit for CSV ingestion.
#
# RESPONSIBILITIES
# ----------------
# - Load EXACTLY ONE CSV file per invocation
# - Accept ONLY relative Files/... paths
# - Read files via alkali1.io.lh.read_files (ID-based ABFSS)
# - Write tables via alkali1.io.lh.write_table (FQN-based)
# - Support OPTIONAL schema auto-migration when enabled via PC
# - Honor PC-provided retry and table-creation semantics
#
# NON-RESPONSIBILITIES
# --------------------
# - File discovery
# - Control table management
# - Orchestration / retries (beyond write_table retry)
#
# ===========================================================================

class CsvFileLoader:
    """
    CSV file loader implementation (single-file only).
    """

    def load(
        self,
        *,
        file: str,
        ctx: Dict[str, Any],
        params: Dict[str, Any],
        datastore: Dict[str, Any],
    ) -> Dict[str, Any]:

        spark = ctx["spark"]
        logger = ctx["logger"]
        datastores = ctx["datastores"]

        # ------------------------------------------------------------------
        # Resolve SOURCE datastore (files)
        # ------------------------------------------------------------------
        src_ws_id = datastore.get("ws_id")
        src_ws_name = datastore.get("ws_name")
        src_ds_id = datastore.get("ds_id")
        src_ds_name = datastore.get("ds_name")

        # ------------------------------------------------------------------
        # Resolve TARGET datastore (tables)
        # ------------------------------------------------------------------
        tgt_alias = params.get("tgt_ds")
        if not tgt_alias:
            raise RuntimeError("csv_loader requires params.tgt_ds")

        tgt_ds = datastores.get(tgt_alias)
        if not tgt_ds:
            raise RuntimeError(f"Unknown target datastore alias: {tgt_alias}")

        tgt_ws_id = tgt_ds.get("ws_id")
        tgt_ws_name = tgt_ds.get("ws_name")
        tgt_ds_id = tgt_ds.get("ds_id")
        tgt_ds_name = tgt_ds.get("ds_name")

        # ------------------------------------------------------------------
        # Read CSV file
        # ------------------------------------------------------------------
        read_options = {
            "header": params.get("src_with_header", "Y") == "Y",
            "delimiter": params.get("src_field_delimiter", ","),
            "quote": params.get("src_quote_char", '"'),
        }

        df: DataFrame = read_files(
            spark=spark,
            ws_id=src_ws_id,
            ws_name=src_ws_name,
            ds_id=src_ds_id,
            ds_name=src_ds_name,
            relative_path=file,
            fmt="csv",
            options=read_options,
            logger=logger,
        )

        tgt_src_file_col = params.get("tgt_src_file_col")
        if isinstance(tgt_src_file_col, str) and tgt_src_file_col.strip():
            df = _append_src_file_col_last(df, tgt_src_file_col, file)

        # ------------------------------------------------------------------
        # Target table parameters
        # ------------------------------------------------------------------
        tgt_schema = params.get("tgt_schema")
        tgt_table = params.get("tgt_table")
        tgt_mode = params.get("tgt_mode", "append")

        if not tgt_schema or not tgt_table:
            raise RuntimeError(
                "csv_loader requires params.tgt_schema and params.tgt_table"
            )

        # ------------------------------------------------------------------
        # Write behavior (PC-driven)
        # ------------------------------------------------------------------
        auto_create_table_f = bool(
            params.get("auto_create_table_f", True)
        )

        allow_schema_merge = bool(
            params.get("allow_schema_merge", False)
        )

        retry_number = int(
            params.get("retry_number", 0)
        )

        # ------------------------------------------------------------------
        # Schema history (required iff schema merge enabled)
        # ------------------------------------------------------------------
        schema_history_ds_alias = params.get("schema_history_ds")
        schema_history_schema = params.get("schema_history_schema")
        schema_history_table = params.get("schema_history_table")

        schema_history_ds = None

        if allow_schema_merge:
            if not (
                schema_history_ds_alias
                and schema_history_schema
                and schema_history_table
            ):
                raise RuntimeError(
                    "allow_schema_merge=True requires "
                    "schema_history_ds, schema_history_schema, "
                    "schema_history_table"
                )

            schema_history_ds = datastores.get(schema_history_ds_alias)
            if not schema_history_ds:
                raise RuntimeError(
                    f"Unknown schema_history_ds alias: {schema_history_ds_alias}"
                )

        # ------------------------------------------------------------------
        # Write table (Fabric Catalog FQN)
        # ------------------------------------------------------------------
        result = write_table(
            spark=spark,
            df=df,
            ws_id=tgt_ws_id,
            ws_name=tgt_ws_name,
            ds_id=tgt_ds_id,
            ds_name=tgt_ds_name,
            schema=tgt_schema,
            table=tgt_table,
            mode=tgt_mode,
            auto_create_table_f=auto_create_table_f,
            allow_schema_merge=allow_schema_merge,
            schema_history_ws_id=schema_history_ds.get("ws_id")
            if schema_history_ds else None,
            schema_history_ws_name=schema_history_ds.get("ws_name")
            if schema_history_ds else None,
            schema_history_ds_id=schema_history_ds.get("ds_id")
            if schema_history_ds else None,
            schema_history_ds_name=schema_history_ds.get("ds_name")
            if schema_history_ds else None,
            schema_history_schema=schema_history_schema,
            schema_history_table=schema_history_table,
            retry_number=retry_number,
            logger=logger,
        )

        counts = _build_loader_counts(result if isinstance(result, dict) else {})

        return {
            "rows_written": result.get("rows_written"),
            "src_record_count": counts.get("src_record_count"),
            "record_count_processed": counts.get("record_count_processed"),
            "failed_count": counts.get("failed_count"),
            "auto_create_table_f": auto_create_table_f,
            "allow_schema_merge": allow_schema_merge,
            "retry_number": retry_number,
        }


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

register_file_loader("csv", CsvFileLoader())