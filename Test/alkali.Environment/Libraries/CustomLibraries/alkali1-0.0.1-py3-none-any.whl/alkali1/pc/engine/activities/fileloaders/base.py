# ===========================================================================
# File Path : alkali1/pc/engine/activities/fileloaders/base.py
# File Name : base.py
# Version   : v1.1.0 (Aligned with Alkali L0 loader runtime contract)
# ===========================================================================
# -*- coding: utf-8 -*-

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional
from pyspark.sql import DataFrame


class FileLoader(ABC):
    """
    Contract for Alkali L0 file loader plug-ins.

    L0 loader responsibilities (MUST):
    - Load EXACTLY ONE file per invocation (the orchestrator handles discovery)
    - Use ctx["spark"] for Spark access
    - Use ctx["logger"] for logging (if present)
    - Read source file(s) using Alkali IO helpers (e.g., alkali1.io.lh.read_files)
    - Perform the loader-specific ingestion logic
    - Return a dict result (metadata) that can be recorded by L1 control table logic

    L0 loader non-responsibilities (MUST NOT):
    - Discover files (L1 responsibility)
    - Manage control tables (L1 responsibility)
    - Implement workflow orchestration

    Return contract:
    - Return a dict with metadata fields such as:
        {"rows_written": int, ...}
    - Optionally include "df" for debugging/inspection:
        {"df": DataFrame, "rows_written": int, ...}
      (Do not rely on "df" for downstream orchestration unless explicitly designed.)
    """

    @abstractmethod
    def load(
        self,
        *,
        file: str,
        ctx: Dict[str, Any],
        params: Dict[str, Any],
        datastore: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Load exactly one file.

        Args:
            file: Relative path under Files/..., e.g. "Files/landing/a.csv"
            ctx: Execution context (must contain spark; may contain logger, datastores, etc.)
            params: Step params (PC-normalized)
            datastore: Source datastore identity dict (ws_id, ds_id, etc.)

        Returns:
            Dict[str, Any]: loader result metadata (and optionally "df").
        """
        raise NotImplementedError
