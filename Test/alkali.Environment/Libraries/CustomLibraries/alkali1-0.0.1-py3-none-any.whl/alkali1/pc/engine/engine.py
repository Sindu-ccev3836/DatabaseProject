# -*- coding: utf-8 -*-
"""
Alkali PC Engine (Single-Engine, Multi-Pipeline Execution)
"""

# ===========================================================================
# 🤖 AI CONTRACT — ALKALI PC ENGINE (AUTHORITATIVE)
# ===========================================================================
# Version : v1.2.0 (PATCH: route pc pipeline_name + pipeline/activity sequence meta)
#
# Existing (v1.1.9)
# -----------------
# - PC step may specify "debug_row_limit": <int>
# - Engine stores it in ctx["_engine"]["debug_row_limit"]
# - Engine excludes debug_row_limit from activity params (reserved metadata)
# - Debug layer uses this value to override per-output df preview row limit
#
# NEW (v1.2.0)
# ------------
# - Engine prefers pipeline["pipeline_name"] over pipeline["name"] (legacy)
# - Engine writes to ctx["_engine"]:
#     - pc_pipeline_name : str
#     - pc_pipeline_seq  : int (1-based)
#     - pc_activity_seq  : int (1-based within pipeline)
# - These are consumed by debug.capture_output(...) and notebook display_debug()
#   to show correct Pipeline Name and sort deterministically.
# ===========================================================================

from __future__ import annotations

import importlib
import json
import pkgutil
from concurrent.futures import ThreadPoolExecutor
from typing import Any, Dict, List

from pyspark.sql import SparkSession

from .activity_registry import get_activity, get_activity_spec, registry_specs, freeze_registry
from .file_loader_registry import freeze_file_loader_registry

ENGINE_VERSION = "v1.3.0"

INTERNAL_ACTIVITIES_PKG = ".activities"
INTERNAL_FILELOADERS_PKG = ".activities.fileloaders"

ENGINE_NATIVE_ACTIVITIES = {"debug.stop"}


def _augment_result_with_registration_metadata(result: Any, *, spec: Any) -> Any:
    """
    Add immutable registration provenance to activity result payloads.
    This is additive-only and does not modify existing activity contracts.
    """
    if not isinstance(result, dict) or not isinstance(spec, object):
        return result

    res_payload = result.get("result")
    if not isinstance(res_payload, dict):
        return result

    enriched = dict(res_payload)
    enriched.setdefault("registered_activity_type", getattr(spec, "registration_type", "unknown"))
    enriched.setdefault("registered_activity_kind", getattr(spec, "kind", "other"))
    enriched.setdefault("registered_activity_code_hash_algo", getattr(spec, "code_hash_algo", ""))
    enriched.setdefault("registered_activity_code_hash", getattr(spec, "code_hash", ""))
    enriched.setdefault("registered_activity_module", getattr(spec, "module", ""))
    enriched.setdefault("registered_activity_source", getattr(spec, "source_path", ""))

    out = dict(result)
    out["result"] = enriched
    return out


def _log(logger, level: str, msg: str) -> None:
    if logger:
        fn = getattr(logger, level.lower(), None)
        if callable(fn):
            fn(str(msg))
            return
    print(str(msg))


def _normalize_datastores(raw: Any) -> Dict[str, Dict[str, Any]]:
    if not raw:
        return {}
    if isinstance(raw, dict):
        out: Dict[str, Dict[str, Any]] = {}
        for alias, cfg in raw.items():
            if not isinstance(alias, str) or not alias.strip():
                continue
            alias = alias.strip()
            if cfg is None:
                cfg = {}
            if not isinstance(cfg, dict):
                continue
            if "ds_alias" not in cfg:
                cfg = dict(cfg)
                cfg["ds_alias"] = alias
            out[alias] = cfg
        return out
    if isinstance(raw, list):
        out: Dict[str, Dict[str, Any]] = {}
        for ds in raw:
            if isinstance(ds, dict) and ds.get("ds_alias"):
                alias = str(ds["ds_alias"]).strip()
                if alias:
                    if "ds_alias" not in ds:
                        ds = dict(ds)
                        ds["ds_alias"] = alias
                    out[alias] = ds
        return out
    return {}


def _autoload_pkg(pkg_name: str) -> None:
    pkg = importlib.import_module(pkg_name)
    if not hasattr(pkg, "__path__"):
        return
    for _, name, _ in pkgutil.iter_modules(pkg.__path__, pkg.__name__ + "."):
        importlib.import_module(name)


def _autoload_activities() -> None:
    _autoload_pkg(__package__ + INTERNAL_ACTIVITIES_PKG)


def _autoload_fileloaders() -> None:
    _autoload_pkg(__package__ + INTERNAL_FILELOADERS_PKG)


def _resolve_output_ref(ref: str, ctx: Dict[str, Any]) -> Any:
    if not isinstance(ref, str) or not ref.strip():
        return ref
    outputs = ctx.get("outputs") or {}
    if not isinstance(outputs, dict):
        return ref
    key = ref.strip()
    if key in outputs and isinstance(outputs[key], dict):
        od = outputs[key]
        if "df" in od:
            return od["df"]
        if "result" in od:
            return od["result"]
        return od
    if "." in key:
        out_name, channel = key.split(".", 1)
        if out_name in outputs and isinstance(outputs[out_name], dict):
            od = outputs[out_name]
            if channel in od:
                return od[channel]
    return ref


def _normalize_activity_params(step: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    params: Dict[str, Any] = {}

    # PATCH v1.1.9: add debug_row_limit to reserved metadata keys
    reserved = {
        "activity_type",
        "activity_name",
        "name",
        "description",
        "params",
        "output",
        "debug_row_limit",   # <-- PATCH
    }

    for k, v in step.items():
        if k not in reserved:
            params[k] = v

    if isinstance(step.get("params"), dict):
        params.update(step["params"])

    outputs = ctx.get("outputs") or {}
    for k, v in list(params.items()):
        if isinstance(v, str) and v.strip():
            token = v.strip()
            if (token in outputs) or ("." in token and token.split(".", 1)[0] in outputs):
                params[k] = _resolve_output_ref(token, ctx)

    return params


def _extract_pipelines(pc: Dict[str, Any]) -> List[Dict[str, Any]]:
    if "pipelines" in pc:
        return pc["pipelines"]
    if "pipeline" in pc:
        return [pc["pipeline"]]
    raise RuntimeError("PC must define pipeline or pipelines")


def _extract_steps(pipeline: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not pipeline:
        return []
    if isinstance(pipeline.get("steps"), list):
        return pipeline["steps"]
    if isinstance(pipeline.get("activities"), list):
        return pipeline["activities"]
    return []


def _resolve_parallel_pipelines_limit(pc: Dict[str, Any]) -> int:
    raw = pc.get("parallel_pipelines_limit", 0)
    try:
        limit = int(raw)
    except Exception:
        return 0
    return limit if limit > 0 else 0


def _invoke_activity(activity: Any, *, spark: SparkSession, ctx: Dict[str, Any], params: Dict[str, Any], logger) -> Any:
    if hasattr(activity, "run") and callable(getattr(activity, "run")):
        return activity.run(spark=spark, ctx=ctx, params=params, logger=logger)
    if callable(activity):
        return activity(spark=spark, ctx=ctx, params=params, logger=logger)
    raise RuntimeError("ENGINE_ERROR: Registered activity is neither callable nor has .run(...)")


def _store_output(ctx: Dict[str, Any], output_name: str, activity_result: Any) -> None:
    if not output_name:
        return
    outputs = ctx.setdefault("outputs", {})
    if not isinstance(outputs, dict):
        ctx["outputs"] = {}
        outputs = ctx["outputs"]

    if activity_result is None:
        outputs[output_name] = {"result": None}
        return

    if isinstance(activity_result, dict):
        outputs[output_name] = activity_result
        return

    try:
        from pyspark.sql import DataFrame
        if isinstance(activity_result, DataFrame):
            outputs[output_name] = {"df": activity_result}
            return
    except Exception:
        pass

    outputs[output_name] = {"result": activity_result}


def _maybe_debug_capture(*, spark: SparkSession, ctx: Dict[str, Any], output_name: str, out: Any, logger=None) -> None:
    try:
        env = ctx.get("env") or {}
        execution = env.get("execution") or {}
        if not isinstance(execution, dict) or not execution.get("debug_mode"):
            return
    except Exception:
        return

    try:
        from . import debug as _dbg
    except Exception as e:
        _log(logger, "warning", f"[engine] debug auto-capture skipped: cannot import alkali1.pc.engine.debug ({e})")
        return

    dbg_ctx = {
        "execution": (ctx.get("env") or {}).get("execution") or {},
        "outputs": ctx.get("outputs") or {},
        "env": ctx.get("env") or {},
        "_engine": ctx.get("_engine") or {},
    }

    try:
        _dbg.capture_output(
            spark=spark,
            ctx=dbg_ctx,
            activity_name=output_name,  # output base key
            out=out,
            logger=logger,
        )
    except Exception as e:
        _log(logger, "warning", f"[engine] debug auto-capture failed for '{output_name}': {e}")


def _run_single_pipeline(
    *,
    spark: SparkSession,
    pipeline: Dict[str, Any],
    p_index: int,
    env_param: Dict[str, Any],
    logger=None,
) -> Dict[str, Any]:
    # ---- PATCH v1.2.0: prefer PC schema pipeline_name, fallback legacy name ----
    p_seq = p_index + 1  # 1-based pipeline sequence
    pipeline_name = (
        pipeline.get("pipeline_name")   # NEW PC schema
        or pipeline.get("name")         # legacy schema
        or f"pipeline_{p_seq}"          # default now 1-based (no pipeline_0)
    )
    steps = _extract_steps(pipeline)

    _log(logger, "info", f"[{pipeline_name}] started")

    ctx: Dict[str, Any] = {
        "env": env_param,
        "pipeline": pipeline,
        "outputs": {},
        "_engine": {
            "engine_version": ENGINE_VERSION,
            "pipeline_index": p_index,        # keep old 0-based index
            "pipeline_seq": p_seq,            # NEW: 1-based seq
            "pipeline_name": pipeline_name,   # keep existing key
            "pc_pipeline_name": pipeline_name,  # NEW: debug expects this (or pipeline_name)
            "pc_pipeline_seq": p_seq,            # NEW: ordering for debug display
            "stopped": False,
            "stop_activity_type": None,
            "stop_reason": None,
            "pc_activity_name": None,
            "pc_activity_seq": None,          # NEW: ordering within pipeline
            "debug_row_limit": None,          # PATCH v1.1.9 default
        },
    }

    for s_index, step in enumerate(steps):
        activity_type = (step.get("activity_type") or "").strip()
        if not activity_type:
            raise RuntimeError(f"ENGINE_ERROR: Missing activity_type at pipeline='{pipeline_name}' step_index={s_index}")

        # ---- Engine metadata ----
        s_seq = s_index + 1  # 1-based activity sequence
        ctx["_engine"]["step_index"] = s_index
        ctx["_engine"]["step_seq"] = s_seq              # optional convenience
        ctx["_engine"]["activity_type"] = activity_type
        ctx["_engine"]["pc_activity_seq"] = s_seq       # NEW: ordering for debug display

        pc_activity_name = step.get("activity_name")
        ctx["_engine"]["pc_activity_name"] = pc_activity_name.strip() if isinstance(pc_activity_name, str) and pc_activity_name.strip() else None

        # PATCH v1.1.9: capture per-step debug_row_limit (int) if present
        drl = step.get("debug_row_limit")
        ctx["_engine"]["debug_row_limit"] = int(drl) if isinstance(drl, (int, float)) and int(drl) > 0 else None

        if activity_type in ENGINE_NATIVE_ACTIVITIES:
            ctx["_engine"]["stopped"] = True
            ctx["_engine"]["stop_activity_type"] = activity_type
            ctx["_engine"]["stop_reason"] = step.get("description") or activity_type
            _log(logger, "info", f"[engine] debug.stop encountered pipeline='{pipeline_name}' step_index={s_index}. Halting.")
            break

        activity = get_activity(activity_type)
        spec = get_activity_spec(activity_type)
        if activity is None:
            registered = sorted(list(registry_specs().keys()))
            raise RuntimeError(
                f"ENGINE_ERROR: Activity not registered: {activity_type}\n"
                f"- pipeline: {pipeline_name}\n"
                f"- step_index: {s_index}\n"
                f"- registered(sample up to 50): {registered[:50]}"
            )

        ctx["_engine"]["registered_activity_type"] = (
            spec.registration_type if spec is not None else "unknown"
        )
        ctx["_engine"]["registered_activity_kind"] = (
            spec.kind if spec is not None else "other"
        )
        ctx["_engine"]["registered_activity_code_hash_algo"] = (
            spec.code_hash_algo if spec is not None else ""
        )
        ctx["_engine"]["registered_activity_code_hash"] = (
            spec.code_hash if spec is not None else ""
        )
        ctx["_engine"]["registered_activity_module"] = (
            spec.module if spec is not None else ""
        )
        ctx["_engine"]["registered_activity_source"] = (
            spec.source_path if spec is not None else ""
        )

        params = _normalize_activity_params(step, ctx)

        activity_name = (
            step.get("activity_name").strip()
            if isinstance(step.get("activity_name"), str) and step.get("activity_name").strip()
            else activity_type
        )

        _log(logger, "info", f"[{pipeline_name}].[{activity_name}] started")
        result = _invoke_activity(activity, spark=spark, ctx=ctx, params=params, logger=logger)
        result = _augment_result_with_registration_metadata(result, spec=spec)
        _log(logger, "info", f"[{pipeline_name}].[{activity_name}] completed")

        output_name = step.get("output")
        if isinstance(output_name, str) and output_name.strip():
            out_name = output_name.strip()
            _store_output(ctx, out_name, result)
            _maybe_debug_capture(spark=spark, ctx=ctx, output_name=out_name, out=result, logger=logger)

    _log(logger, "info", f"[{pipeline_name}] completed")

    return {"pipeline_name": pipeline_name, "ctx": ctx}


def pc_engine(*, spark: SparkSession, pc_str: str, logger=None, env_param: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(pc_str, str) or not pc_str.strip():
        raise RuntimeError("ENGINE_ERROR: pc_str must be a non-empty JSON string")
    if not isinstance(env_param, dict):
        raise RuntimeError("ENGINE_ERROR: env_param must be a dict")

    pc = json.loads(pc_str)
    if not isinstance(pc, dict):
        raise RuntimeError("ENGINE_ERROR: pc_str JSON must parse to an object/dict")

    _autoload_activities()
    _autoload_fileloaders()
    freeze_registry()
    freeze_file_loader_registry()

    env_param = dict(env_param)
    env_param["datastores"] = _normalize_datastores(env_param.get("datastores"))

    master_ctx: Dict[str, Any] = {
        "engine_version": ENGINE_VERSION,
        "pc_kind": pc.get("pc_kind"),
        "pc_version": pc.get("pc_version"),
        "env": env_param,
        "pipelines": {},
        "outputs": {},
        "_engine": {},
    }

    pipelines = _extract_pipelines(pc)
    parallel_limit = _resolve_parallel_pipelines_limit(pc)
    effective_workers = min(parallel_limit, len(pipelines)) if parallel_limit > 0 else 0
    mode = "parallel" if effective_workers > 1 else "sequential"
    _log(
        logger,
        "info",
        f"[engine] Starting PC execution: pipelines={len(pipelines)} version={ENGINE_VERSION} mode={mode} parallel_pipelines_limit={parallel_limit}",
    )

    results: List[Dict[str, Any]] = []

    # Default behavior remains sequential when parallel_pipelines_limit is missing/0/1.
    if effective_workers <= 1:
        for p_index, pipeline in enumerate(pipelines):
            results.append(
                _run_single_pipeline(
                    spark=spark,
                    pipeline=pipeline,
                    p_index=p_index,
                    env_param=env_param,
                    logger=logger,
                )
            )
    else:
        _log(
            logger,
            "info",
            f"[engine] Parallel pipelines started: count={len(pipelines)} workers={effective_workers}",
        )
        with ThreadPoolExecutor(max_workers=effective_workers) as executor:
            futures = [
                executor.submit(
                    _run_single_pipeline,
                    spark=spark,
                    pipeline=pipeline,
                    p_index=p_index,
                    env_param=env_param,
                    logger=logger,
                )
                for p_index, pipeline in enumerate(pipelines)
            ]

            # Read futures in pipeline order for deterministic output merge behavior.
            for i, fut in enumerate(futures):
                try:
                    results.append(fut.result())
                except Exception:
                    for pending in futures[i + 1:]:
                        pending.cancel()
                    raise

    for r in results:
        pipeline_name = r["pipeline_name"]
        ctx = r["ctx"]
        master_ctx["pipelines"][pipeline_name] = ctx
        master_ctx["outputs"] = ctx.get("outputs", {})

    return master_ctx
