# -*- coding: utf-8 -*-
"""
alkali1.pc.engine.debug

Central debug utilities (Notebook-session scoped):
- DF_REGISTRY + metadata (subset DF only)
- RESULT_REGISTRY (JSON-like meta)
- result_df registration (KV DF: name, value)
- Engine hook: capture_output(spark, ctx, activity_name, out, logger)

v1.0.3 adds mapping:
- ACTIVITY_NAME_BY_OUTPUT[output_name] = pc_activity_name
so notebook helper can print correct Activity Name from PC.

v1.0.5 adds pipeline/activity ordering metadata:
- PIPELINE_NAME_BY_OUTPUT[output_base] = pc_pipeline_name
- PIPELINE_SEQ_BY_OUTPUT[output_base]  = pc_pipeline_seq
- ACTIVITY_SEQ_BY_OUTPUT[output_base]  = pc_activity_seq
so notebook helper can sort by (pipeline_seq, activity_seq).

v1.0.6 adds pipeline-scoped output keys in capture_output:
- scoped output base format: "<pipeline_name>::<output_base>"
- prevents key collisions when parallel pipelines reuse the same output name
"""

# ===========================================================================
# 🤖 AI CONTRACT — ALKALI ENGINE DEBUG MODULE (AUTHORITATIVE)
# ===========================================================================
# Version : v1.0.6
#
# REGISTRIES
# ----------
# - DF_REGISTRY[name]     : Spark DataFrame (subset only)
# - DF_DIMENSIONS[name]   : (total_rows, total_cols) of ORIGINAL DF
# - DF_DISPLAY_ROWS[name] : n_rows used for subset
# - RESULT_REGISTRY[name] : JSON-like payload (dict/list/scalar)
# - ACTIVITY_NAME_BY_OUTPUT[output_base]  : PC activity_name string
# - PIPELINE_NAME_BY_OUTPUT[output_base]  : PC pipeline_name string
# - PIPELINE_SEQ_BY_OUTPUT[output_base]   : pipeline sequence number (int)
# - ACTIVITY_SEQ_BY_OUTPUT[output_base]   : activity sequence number within pipeline (int)
#
# CANONICAL NAMING
# ----------------
# - Data preview DF key:  "<output_base>.df"
# - Result KV DF key:     "<output_base>.result_df.df"
# - JSON result key:      "<output_base>.result"
#
# ENGINE HOOK
# -----------
# capture_output(...) MUST no-op unless ctx["execution"]["debug_mode"] is True.
# Reads ctx["execution"]["debug_rows"] (default 50).
#
# v1.0.4
# ------
# - If ctx["_engine"]["debug_row_limit"] is a positive integer, it overrides
#   ctx["execution"]["debug_rows"] for the DATA preview dataframe (<output_base>.df).
# - result_df (KV metadata DF) continues to use ctx["execution"]["debug_rows"]
#   by default (typically small), unless you explicitly change it.
#
# NEW (v1.0.5)
# ------------
# capture_output stores ordering meta if present:
# - ctx["_engine"]["pc_pipeline_name"] : pipeline name
# - ctx["_engine"]["pc_pipeline_seq"]  : pipeline sequence number
# - ctx["_engine"]["pc_activity_seq"]  : activity sequence number
#
# NEW (v1.0.6)
# ------------
# capture_output namespaces output base by pipeline when available:
# - scoped_output_base = "<pipeline_name>::<output_base>"
# This avoids registry collisions for parallel PCs where multiple pipelines
# emit the same output name (e.g., "meta", "result", "bronze_df").
#
# IMPORTANT:
# ----------
# The engine passes:
# - activity_name argument == output_base (e.g., "attendees_meta")
# - ctx["_engine"]["pc_activity_name"] == PC activity_name (e.g., "fetch_attendees")
# - ctx["_engine"]["debug_row_limit"]  == optional per-step override
# capture_output MUST store mapping so display helper can show the true activity name.
# ===========================================================================

from __future__ import annotations

import json
from typing import Any, Dict, Tuple

from pyspark.sql import DataFrame, SparkSession

# -----------------------------------------------------------------------------
# Registries (Notebook-session scoped)
# -----------------------------------------------------------------------------
DF_REGISTRY: Dict[str, DataFrame] = {}
DF_DIMENSIONS: Dict[str, Tuple[int, int]] = {}   # (total_rows, total_cols)
DF_DISPLAY_ROWS: Dict[str, int] = {}             # n_rows

RESULT_REGISTRY: Dict[str, Any] = {}             # name -> JSON-like payload

# output_base -> PC activity_name
ACTIVITY_NAME_BY_OUTPUT: Dict[str, str] = {}

# NEW (v1.0.5): ordering + pipeline metadata (all keyed by output_base)
PIPELINE_NAME_BY_OUTPUT: Dict[str, str] = {}
PIPELINE_SEQ_BY_OUTPUT: Dict[str, int] = {}
ACTIVITY_SEQ_BY_OUTPUT: Dict[str, int] = {}


# -----------------------------------------------------------------------------
# Utilities
# -----------------------------------------------------------------------------
def _json_safe(v: Any) -> str:
    try:
        return json.dumps(v, default=str, ensure_ascii=False)
    except Exception:
        return str(v)


def _is_spark_df(obj: Any) -> bool:
    return isinstance(obj, DataFrame)


def _canonical_df_name(name: str) -> str:
    return name if name.endswith(".df") else f"{name}.df"


def _canonical_result_df_name(output_base: str) -> str:
    base = output_base[:-3] if output_base.endswith(".df") else output_base
    return f"{base}.result_df.df"


def _coerce_positive_int(v: Any) -> int | None:
    """
    Best-effort: return positive int if v looks like one, else None.
    Accepts int or numeric strings.
    """
    if isinstance(v, bool):
        return None
    if isinstance(v, int):
        return v if v > 0 else None
    if isinstance(v, float):
        iv = int(v)
        return iv if iv > 0 else None
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        try:
            iv = int(s)
            return iv if iv > 0 else None
        except Exception:
            return None
    return None


def _coerce_int(v: Any) -> int | None:
    """Best-effort: int coercion for seq values; returns None on failure."""
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, int):
        return int(v)
    if isinstance(v, float):
        return int(v)
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        try:
            return int(s)
        except Exception:
            return None
    return None


def _scoped_output_base(output_base: str, eng: Dict[str, Any]) -> str:
    """
    Build a pipeline-scoped output base to avoid key collisions across pipelines.
    Falls back to raw output_base if pipeline name is unavailable.
    """
    base = (output_base or "").strip()
    if not base:
        return base

    pipe_name = eng.get("pc_pipeline_name") or eng.get("pipeline_name")
    if isinstance(pipe_name, str) and pipe_name.strip():
        return f"{pipe_name.strip()}::{base}"
    return base


# -----------------------------------------------------------------------------
# DF Registry API (kw-only contract: total_rows/total_cols/display_rows)
# -----------------------------------------------------------------------------
def register_df(
    name: str,
    display_df: DataFrame,
    *,
    total_rows: int,
    total_cols: int,
    display_rows: int,
) -> None:
    if not name or not isinstance(name, str):
        raise ValueError("register_df: name must be a non-empty string")
    if not _is_spark_df(display_df):
        raise ValueError("register_df: display_df must be a Spark DataFrame")

    key = _canonical_df_name(name)
    DF_REGISTRY[key] = display_df
    DF_DIMENSIONS[key] = (int(total_rows), int(total_cols))
    DF_DISPLAY_ROWS[key] = int(display_rows)


def list_dfs() -> list[str]:
    return sorted(DF_REGISTRY.keys())


def clear_registry() -> None:
    DF_REGISTRY.clear()
    DF_DIMENSIONS.clear()
    DF_DISPLAY_ROWS.clear()
    RESULT_REGISTRY.clear()
    ACTIVITY_NAME_BY_OUTPUT.clear()

    # NEW (v1.0.5)
    PIPELINE_NAME_BY_OUTPUT.clear()
    PIPELINE_SEQ_BY_OUTPUT.clear()
    ACTIVITY_SEQ_BY_OUTPUT.clear()


# -----------------------------------------------------------------------------
# Result Registry API
# -----------------------------------------------------------------------------
def register_result(name: str, result: Any) -> None:
    if not name or not isinstance(name, str):
        raise ValueError("register_result: name must be a non-empty string")
    RESULT_REGISTRY[name] = result


def get_result(name: str, default: Any = None) -> Any:
    return RESULT_REGISTRY.get(name, default)


# -----------------------------------------------------------------------------
# Optional: explicit meta registration API (can be used by engine if desired)
# -----------------------------------------------------------------------------
def register_pipeline_meta(
    output_base: str,
    *,
    pipeline_name: str | None = None,
    pipeline_seq: int | None = None,
) -> None:
    if not output_base or not isinstance(output_base, str):
        raise ValueError("register_pipeline_meta: output_base must be a non-empty string")
    base = output_base.strip()

    if isinstance(pipeline_name, str) and pipeline_name.strip():
        PIPELINE_NAME_BY_OUTPUT[base] = pipeline_name.strip()

    if pipeline_seq is not None:
        PIPELINE_SEQ_BY_OUTPUT[base] = int(pipeline_seq)


def register_activity_seq(output_base: str, seq: int | None) -> None:
    if not output_base or not isinstance(output_base, str):
        raise ValueError("register_activity_seq: output_base must be a non-empty string")
    if seq is None:
        return
    ACTIVITY_SEQ_BY_OUTPUT[output_base.strip()] = int(seq)


# -----------------------------------------------------------------------------
# result_df (KV DF) creation + registration
# -----------------------------------------------------------------------------
def result_to_kv_df(spark: SparkSession, result_obj: Any) -> DataFrame:
    """
    Convert JSON-like result payload into Spark DF with schema:
      - name:  string
      - value: string (JSON-safe representation)
    """
    if result_obj is None:
        rows = []
    elif isinstance(result_obj, dict):
        rows = [
            (str(k), _json_safe(v) if isinstance(v, (dict, list, tuple)) else str(v))
            for k, v in result_obj.items()
        ]
    else:
        rows = [("value", _json_safe(result_obj))]

    return spark.createDataFrame(rows, ["name", "value"])


def register_result_df(
    *,
    spark: SparkSession,
    output_base: str,
    result_obj: Any,
    display_rows: int,
) -> None:
    kv_df = result_to_kv_df(spark, result_obj)
    total_rows = kv_df.count()
    subset = kv_df.limit(display_rows)

    register_df(
        name=_canonical_result_df_name(output_base),
        display_df=subset,
        total_rows=total_rows,
        total_cols=2,
        display_rows=min(display_rows, total_rows),
    )


# -----------------------------------------------------------------------------
# Engine hook
# -----------------------------------------------------------------------------
def capture_output(
    *,
    spark: SparkSession,
    ctx: Dict[str, Any],
    activity_name: str,   # NOTE: this is output_base (e.g., attendees_meta)
    out: Any,
    logger: Any = None,
) -> None:
    exec_cfg = (ctx or {}).get("execution") or {}
    if not isinstance(exec_cfg, dict) or not exec_cfg.get("debug_mode"):
        return

    # Global default row limit
    debug_rows = _coerce_positive_int(exec_cfg.get("debug_rows")) or 50

    # Engine meta
    eng = (ctx or {}).get("_engine") or {}

    raw_output_base = (activity_name or "").strip()
    output_base = _scoped_output_base(raw_output_base, eng)

    # v1.0.3: wire PC activity_name mapping (scoped output_base -> pc activity_name)
    pc_act = eng.get("pc_activity_name")
    if isinstance(pc_act, str) and pc_act.strip():
        ACTIVITY_NAME_BY_OUTPUT[output_base] = pc_act.strip()

    # v1.0.5: pipeline + ordering metadata
    pc_pipe_name = eng.get("pc_pipeline_name") or eng.get("pipeline_name")
    if isinstance(pc_pipe_name, str) and pc_pipe_name.strip():
        PIPELINE_NAME_BY_OUTPUT[output_base] = pc_pipe_name.strip()

    pc_pipe_seq = _coerce_int(eng.get("pc_pipeline_seq") or eng.get("pipeline_seq"))
    if pc_pipe_seq is not None:
        PIPELINE_SEQ_BY_OUTPUT[output_base] = pc_pipe_seq

    pc_act_seq = _coerce_int(eng.get("pc_activity_seq") or eng.get("activity_seq") or eng.get("seq"))
    if pc_act_seq is not None:
        ACTIVITY_SEQ_BY_OUTPUT[output_base] = pc_act_seq

    # v1.0.4: per-step override row limit for DATA DF preview (<output_base>.df)
    step_row_limit = _coerce_positive_int(eng.get("debug_row_limit"))
    df_row_limit = step_row_limit or debug_rows

    # Unwrap outputs
    df_obj = None
    result_payload = None

    if isinstance(out, dict):
        if "df" in out and _is_spark_df(out.get("df")):
            df_obj = out.get("df")
        if "result" in out:
            result_payload = out.get("result")
        else:
            # If dict doesn't have "result", treat whole dict as result payload
            result_payload = out
    else:
        if hasattr(out, "df") and _is_spark_df(getattr(out, "df")):
            df_obj = getattr(out, "df")
        if hasattr(out, "result"):
            result_payload = getattr(out, "result")
        if df_obj is None and _is_spark_df(out):
            df_obj = out

    # DF capture (uses per-step df_row_limit)
    if df_obj is not None:
        total_rows = df_obj.count()
        total_cols = len(df_obj.columns)
        register_df(
            name=f"{output_base}.df",
            display_df=df_obj.limit(df_row_limit),
            total_rows=total_rows,
            total_cols=total_cols,
            display_rows=min(df_row_limit, total_rows),
        )

    # Result capture + result_df (default uses global debug_rows)
    if result_payload is not None:
        register_result(f"{output_base}.result", result_payload)

        # If you ever want the per-step limit to also affect result_df,
        # change display_rows=df_row_limit below. For now keep metadata small + consistent.
        register_result_df(
            spark=spark,
            output_base=output_base,
            result_obj=result_payload,
            display_rows=debug_rows,
        )
