from __future__ import annotations

import os
from typing import Any, Dict


def resolve_secret_from_reference(ref: Dict[str, Any]) -> str:
    provider = (ref.get("provider") or "").strip().lower()
    if provider != "env":
        raise RuntimeError(
            "AUTH_CONFIG_ERROR: unsupported client_secret_from.provider "
            f"'{provider}'. Supported: env"
        )

    name = (ref.get("name") or "").strip()
    if not name:
        raise RuntimeError("AUTH_CONFIG_ERROR: client_secret_from.name is required")

    value = os.getenv(name)
    if value is None or str(value).strip() == "":
        raise RuntimeError(
            "AUTH_CONFIG_ERROR: environment variable for client secret "
            f"'{name}' is missing or empty"
        )
    return str(value)


def resolve_secret_from_akv(value_from: Dict[str, Any]) -> str:
    provider = (value_from.get("provider") or "").strip().lower()
    if provider != "azure_key_vault":
        raise RuntimeError(
            "AUTH_CONFIG_ERROR: unsupported auth.value_from.provider "
            f"'{provider}'. Supported: azure_key_vault"
        )

    kv_uri = (value_from.get("kv_uri") or "").strip()
    secret_name = (value_from.get("secret_name") or "").strip()
    if not kv_uri:
        raise RuntimeError("AUTH_CONFIG_ERROR: auth.value_from.kv_uri is required")
    if not secret_name:
        raise RuntimeError("AUTH_CONFIG_ERROR: auth.value_from.secret_name is required")

    cred_cfg = value_from.get("credential") or {}
    mode = (cred_cfg.get("mode") or "managed_identity").strip().lower()

    try:
        from azure.identity import ClientSecretCredential, ManagedIdentityCredential
        from azure.keyvault.secrets import SecretClient
    except Exception as e:
        raise RuntimeError(
            "AKV_DEPENDENCY_ERROR: azure-identity and azure-keyvault-secrets are required"
        ) from e

    if mode == "managed_identity":
        credential = ManagedIdentityCredential()
    elif mode == "spn_secret":
        tenant_id = (cred_cfg.get("tenant_id") or "").strip()
        client_id = (cred_cfg.get("client_id") or "").strip()
        client_secret_from = cred_cfg.get("client_secret_from") or {}

        if not tenant_id:
            raise RuntimeError("AUTH_CONFIG_ERROR: credential.tenant_id is required for spn_secret")
        if not client_id:
            raise RuntimeError("AUTH_CONFIG_ERROR: credential.client_id is required for spn_secret")
        if not isinstance(client_secret_from, dict):
            raise RuntimeError("AUTH_CONFIG_ERROR: credential.client_secret_from must be an object")

        client_secret = resolve_secret_from_reference(client_secret_from)
        credential = ClientSecretCredential(
            tenant_id=tenant_id,
            client_id=client_id,
            client_secret=client_secret,
        )
    else:
        raise RuntimeError(
            "AUTH_CONFIG_ERROR: unsupported credential.mode "
            f"'{mode}'. Supported: managed_identity, spn_secret"
        )

    try:
        secret_client = SecretClient(vault_url=kv_uri, credential=credential)
        secret_bundle = secret_client.get_secret(secret_name)
        value = secret_bundle.value
    except Exception as e:
        raise RuntimeError(
            "AKV_SECRET_RESOLUTION_ERROR: unable to resolve secret "
            f"'{secret_name}' from '{kv_uri}' ({type(e).__name__}: {e})"
        ) from e

    if value is None or str(value).strip() == "":
        raise RuntimeError(
            "AKV_SECRET_RESOLUTION_ERROR: resolved secret is empty "
            f"for '{secret_name}'"
        )

    return str(value)
