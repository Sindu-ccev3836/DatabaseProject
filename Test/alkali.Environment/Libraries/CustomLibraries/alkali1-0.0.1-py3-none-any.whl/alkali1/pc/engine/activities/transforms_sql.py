# File: alkali1/pc/engine/activities/transforms_sql.py
# -*- coding: utf-8 -*-

"""
xf.sql

Spark SQL transformation activity.

Fields (in ctx["act"]):
- input OR inputs[0]   : name of input DataFrame in ctx["dfs"]
- output OR outputs[0]: name of output DataFrame to publish to ctx["dfs"]
- logic               : SQL string

Characteristics:
- Alkali1 single-engine compatible
- No IO side effects
- Deterministic SQL execution
- Uses engine-owned activity registration
"""

from __future__ import annotations

from typing import Any, Dict
from pyspark.sql import DataFrame

from alkali1.pc.engine.activity_registry import register_activity


# ---------------------------------------------------------------------------
# Activity implementation
# ---------------------------------------------------------------------------

def xf_sql(ctx: Dict[str, Any]) -> None:
    """
    Execute a Spark SQL transformation.
    """
    spark = ctx["spark"]
    logger = ctx.get("logger")
    act = ctx.get("act") or {}
    dfs: Dict[str, DataFrame] = ctx.get("dfs") or {}

    # ------------------------------------------------------------
    # Resolve input / output
    # ------------------------------------------------------------
    inp = act.get("input") or (act.get("inputs") or [None])[0]
    out = act.get("output") or (act.get("outputs") or [None])[0]

    if not inp or inp not in dfs:
        raise RuntimeError("xf.sql requires 'input' referencing a dfs key")

    if not out:
        raise RuntimeError("xf.sql requires 'output'")

    df_in = dfs[inp]
    if not isinstance(df_in, DataFrame):
        raise RuntimeError("xf.sql input must be a DataFrame")

    # ------------------------------------------------------------
    # Resolve SQL logic
    # ------------------------------------------------------------
    logic = act.get("logic") or act.get("sql")
    if not isinstance(logic, str) or not logic.strip():
        raise RuntimeError("xf.sql requires non-empty 'logic' (SQL string)")

    # ------------------------------------------------------------
    # Register temp view & execute SQL
    # ------------------------------------------------------------
    view_name = inp
    df_in.createOrReplaceTempView(view_name)

    if logger:
        logger.info(f"xf.sql: executing SQL using view '{view_name}'")

    df_out = spark.sql(logic)

    # ------------------------------------------------------------
    # Publish result
    # ------------------------------------------------------------
    dfs[out] = df_out

    if logger:
        logger.info(f"xf.sql: published df '{out}'")


# ---------------------------------------------------------------------------
# ✅ Engine-owned registration
# ---------------------------------------------------------------------------

register_activity(
    name="xf.sql",
    fn=xf_sql,
    kind="transform",
    notes="Execute Spark SQL transformation using dfs as temp views",
)