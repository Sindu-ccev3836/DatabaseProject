# File: alkali1/pc/engine/activities/io_http_api.py
# -*- coding: utf-8 -*-
"""
===============================================================================
ALKALI AI ACTIVITY CONTRACT
===============================================================================

Activity Name
-------------
io.http_api_to_file

Hosting Model
-------------
BUILT-IN (Engine-owned, library packed)

Execution Contract
------------------
fn(spark=..., ctx=..., params=..., logger=..., **_ignored) -> {df, result}

Physical IO Authority
---------------------
ALL physical file I/O is delegated to alkali1.io.lh
(NO direct mssparkutils.fs access allowed in activities)

===============================================================================
"""

from __future__ import annotations

import json
import time
import random
from typing import Any, Dict, Optional

import requests
from pyspark.sql import DataFrame

from alkali1.pc.engine.activity_registry import register_activity
from alkali1.pc.engine.auth.secret_resolver import resolve_secret_from_akv
from alkali1.io import lh


# ---------------------------------------------------------------------------
# MaxSafety ctx normalization (Playbook v1.0.2)
# ---------------------------------------------------------------------------
def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    ctx = ctx or {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _success_result(**kwargs) -> Dict[str, Any]:
    out = {"status": "SUCCEEDED"}
    out.update(kwargs)
    return out


def _failed_result(exc: Exception, **kwargs) -> Dict[str, Any]:
    out = {
        "status": "FAILED",
        "error_message": str(exc),
        "error_type": type(exc).__name__,
    }
    out.update(kwargs)
    return out


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def _to_relative_files_path(p: str) -> str:
    s = (p or "").strip().replace("\\", "/")
    if s.startswith("/"):
        s = s[1:]
    if s.lower().startswith("files/"):
        return "Files/" + s[6:]
    if s.lower().startswith("tables/"):
        return "Tables/" + s[7:]
    return "Files/" + s


def _mask_secret(value: str, keep: int = 4) -> str:
    if value is None:
        return None
    v = str(value)
    return v[:keep] + "*" * max(0, len(v) - keep)


def _json_dumps(obj, pretty: bool = True) -> str:
    return json.dumps(obj, indent=2 if pretty else None, ensure_ascii=False, default=str)


# ---------------------------------------------------------------------------
# Datastore resolution (CANONICAL – matches io_datastore.py)
# ---------------------------------------------------------------------------
def _get_datastore_container(ctx: Dict[str, Any]):
    ds_container = ctx.get("datastores")
    if ds_container:
        return ds_container
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None


def _resolve_tgt_ds_alias(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Resolve tgt_ds_alias using Alkali canonical rules.
    Supports:
    - ctx["datastores"] OR ctx["env"]["datastores"]
    - dict keyed by alias OR legacy list form
    """
    p = ctx.get("params") or {}

    tgt_ds_alias = (
        p.get("tgt_ds_alias")
        or p.get("tgt_ds")
        or ctx.get("tgt_ds_alias")
        or ctx.get("tgt_ds")
    )

    tgt_ds_alias = (tgt_ds_alias or "").strip()
    if not tgt_ds_alias:
        raise RuntimeError("PC_VALIDATION_ERROR: missing tgt_ds_alias")

    ds_container = _get_datastore_container(ctx)
    if not ds_container:
        raise RuntimeError("PC_VALIDATION_ERROR: no datastores found in ctx")

    # NEW runtime form: dict keyed by alias
    if isinstance(ds_container, dict):
        ident = ds_container.get(tgt_ds_alias)

    # LEGACY runtime form: list of dicts with ds_alias
    elif isinstance(ds_container, list):
        ident = next(
            (d for d in ds_container if d.get("ds_alias") == tgt_ds_alias),
            None,
        )
    else:
        ident = None

    if not isinstance(ident, dict):
        raise RuntimeError(
            f"PC_VALIDATION_ERROR: tgt_ds_alias '{tgt_ds_alias}' not found in datastores"
        )

    ident = dict(ident)
    ident["ds_alias"] = tgt_ds_alias
    return ident


# ---------------------------------------------------------------------------
# Built-in Activity
# ---------------------------------------------------------------------------
def io_http_api_to_file(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    logger = ctx.get("logger")
    p = ctx.get("params") or {}

    try:
        # -------------------------------------------------------------------
        # Resolve target datastore (Lakehouse identity)
        # -------------------------------------------------------------------
        tgt_ident = _resolve_tgt_ds_alias(ctx)
        tgt_ds_alias = tgt_ident["ds_alias"]

        ws_id = tgt_ident.get("workspace", {}).get("ws_id")
        ds_id = tgt_ident.get("datastore", {}).get("ds_id")

        if not ws_id or not ds_id:
            raise RuntimeError(
                f"PC_VALIDATION_ERROR: invalid identity for tgt_ds_alias '{tgt_ds_alias}'"
            )

        # -------------------------------------------------------------------
        # Target file paths
        # -------------------------------------------------------------------
        tgt_file_path = p.get("tgt_file_path")
        if not tgt_file_path:
            raise RuntimeError("PC_VALIDATION_ERROR: missing tgt_file_path")

        file_path = _to_relative_files_path(tgt_file_path)
        meta_path = file_path + ".meta.json"

        # -------------------------------------------------------------------
        # HTTP parameters
        # -------------------------------------------------------------------
        url = p["url"]
        method = (p.get("method") or "GET").upper()
        headers = dict(p.get("headers") or {})
        query = dict(p.get("query") or {})

        json_body = p.get("json")
        raw_body = p.get("body")
        form = p.get("form")

        timeout_sec = float(p.get("timeout_sec", 30))
        retries = int(p.get("retries", 2))
        backoff_base = float(p.get("backoff_base_sec", 1.0))
        backoff_jitter = float(p.get("backoff_jitter_sec", 0.3))
        retry_on_status = set(p.get("retry_on_status") or [429, 500, 502, 503, 504])

        pretty = bool(p.get("pretty", True))
        fail_on_non_2xx = bool(p.get("fail_on_non_2xx", True))

        # -------------------------------------------------------------------
        # API Key Auth
        # -------------------------------------------------------------------
        auth = p.get("auth") or {}
        if auth.get("type") == "api_key":
            ak_in = (auth.get("in") or "header").lower()
            ak_key = auth.get("key")
            if not ak_key:
                raise RuntimeError("AUTH_CONFIG_ERROR: auth.key is required when auth.type=api_key")

            ak_val = None
            value_from = auth.get("value_from")
            if isinstance(value_from, dict):
                ak_val = resolve_secret_from_akv(value_from)
            elif "value" in auth:
                ak_val = auth.get("value")

            if ak_val is None:
                raise RuntimeError(
                    "AUTH_CONFIG_ERROR: auth.value or auth.value_from is required "
                    "when auth.type=api_key"
                )

            if ak_key and ak_val is not None:
                if ak_in == "header":
                    headers[ak_key] = ak_val
                elif ak_in in ("query", "params"):
                    query[ak_key] = ak_val
                else:
                    raise RuntimeError(f"Unsupported auth.in '{ak_in}'")

        safe_headers = dict(headers)
        if auth.get("type") == "api_key" and auth.get("in", "header").lower() == "header":
            k = auth.get("key")
            if k in safe_headers:
                safe_headers[k] = _mask_secret(safe_headers[k])

        # -------------------------------------------------------------------
        # Execute with retry
        # -------------------------------------------------------------------
        last_err = None
        for attempt in range(1, retries + 1):
            try:
                start = time.time()

                req_kwargs = {
                    "method": method,
                    "url": url,
                    "headers": headers,
                    "params": query,
                    "timeout": timeout_sec,
                }

                if json_body is not None:
                    req_kwargs["json"] = json_body
                elif form is not None:
                    req_kwargs["data"] = form
                elif raw_body is not None:
                    req_kwargs["data"] = raw_body

                resp = requests.request(**req_kwargs)
                elapsed_ms = int((time.time() - start) * 1000)

                ct = resp.headers.get("Content-Type", "")
                is_json = "application/json" in ct.lower()
                payload = _json_dumps(resp.json(), pretty=pretty) if is_json else resp.text

                # -------------------------------------------------------------------
                # Physical file I/O via alkali1.io.lh
                # -------------------------------------------------------------------
                lh.write_file_text(
                    ws_id=ws_id,
                    ds_id=ds_id,
                    relative_path=file_path,
                    content=payload,
                    overwrite=True,
                    retry_number=retries,
                    logger=logger,
                )

                meta = {
                    "request": {
                        "method": method,
                        "url": url,
                        "headers": safe_headers,
                        "query": query,
                        "timeout_sec": timeout_sec,
                    },
                    "response": {
                        "status_code": resp.status_code,
                        "reason": resp.reason,
                        "elapsed_ms": elapsed_ms,
                        "content_type": ct,
                        "is_json": is_json,
                    },
                    "target": {
                        "ds_alias": tgt_ds_alias,
                        "ds_type": tgt_ident.get("ds_type"),
                        "workspace": tgt_ident.get("workspace"),
                        "datastore": tgt_ident.get("datastore"),
                    },
                    "output": {
                        "output_file": file_path,
                        "meta_file": meta_path,
                        "attempt": attempt,
                    },
                }

                lh.write_file_text(
                    ws_id=ws_id,
                    ds_id=ds_id,
                    relative_path=meta_path,
                    content=_json_dumps(meta),
                    overwrite=True,
                    retry_number=retries,
                    logger=logger,
                )

                if fail_on_non_2xx and not (200 <= resp.status_code < 300):
                    raise RuntimeError(f"HTTP {resp.status_code} {resp.reason}")

                return {
                    "df": None,
                    "result": _success_result(
                        status_code=resp.status_code,
                        tgt_ds_alias=tgt_ds_alias,
                        output_file=file_path,
                    ),
                }

            except Exception as e:
                last_err = e
                status = getattr(getattr(e, "response", None), "status_code", None)
                retryable = status in retry_on_status if status is not None else True

                if attempt < retries and retryable:
                    sleep = backoff_base * (2 ** (attempt - 1)) + random.uniform(0, backoff_jitter)
                    time.sleep(sleep)
                else:
                    break

        raise last_err

    except Exception as e:
        return {"df": None, "result": _failed_result(e)}


# ---------------------------------------------------------------------------
# Import-time registration (BUILT-IN)
# ---------------------------------------------------------------------------
register_activity(
    name="io.http_api_to_file",
    fn=io_http_api_to_file,
    kind="io",
    notes="HTTP API → file (builtin, canonical datastore resolution, lh-backed FILES IO)",
)
