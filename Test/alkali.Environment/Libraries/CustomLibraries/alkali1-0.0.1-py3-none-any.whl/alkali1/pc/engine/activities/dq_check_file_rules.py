# -*- coding: utf-8 -*-
# ===========================================================================
# File Path : alkali1/pc/engine/activities/dq_check_file_rules.py
# Version   : v1.0.0
# ===========================================================================

"""
Built-in activity: dq.check_file_rules

Purpose
-------
Evaluate file-level DQ rules on Lakehouse Files paths.

Current supported expectations
-----------------------------
- expectation: "file_exists"
- expectation: "file_count_between"
- expectation: "file_name_regex"
- expectation: "extension_in_set"
- expectation: "size_bytes_between"
- expectation: "max_file_age_minutes"
- expectation: "no_duplicate_file_names"

Output Contract v1.0.0
----------------------
Returns:
{
  "df": <DataFrame | None>,
  "result": {"status": "SUCCEEDED"|"FAILED", ...}
}
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Tuple

from notebookutils import mssparkutils
from pyspark.sql import DataFrame, Row
from pyspark.sql.types import (
    BooleanType,
    LongType,
    StringType,
    StructField,
    StructType,
)

from alkali1.pc.engine.activity_registry import register_activity


ACTIVITY_NAME: str = "dq.check_file_rules"
SUPPORTED_EXPECTATIONS = {
    "file_exists",
    "file_count_between",
    "file_name_regex",
    "extension_in_set",
    "size_bytes_between",
    "max_file_age_minutes",
    "no_duplicate_file_names",
}

DQ_FILE_RESULT_SCHEMA = StructType(
    [
        StructField("rule_id", StringType(), True),
        StructField("expectation", StringType(), True),
        StructField("severity", StringType(), True),
        StructField("path", StringType(), True),
        StructField("success", BooleanType(), True),
        StructField("checked_file_count", LongType(), True),
        StructField("failed_file_count", LongType(), True),
        StructField("observed_value", StringType(), True),
        StructField("message", StringType(), True),
    ]
)


def _log_debug(logger: Any, message: str) -> None:
    fn = getattr(logger, "debug", None) if logger is not None else None
    if callable(fn):
        fn(str(message))


def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    """
    Max-safe ctx normalization for engine-style calls.
    """
    ctx = ctx or {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _resolve_param(ctx: Dict[str, Any], key: str, default=None):
    p = ctx.get("params") or {}
    if isinstance(p, dict) and key in p:
        return p.get(key)
    return ctx.get(key, default)


def _as_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "f", "no", "n", "off"}:
            return False
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid boolean value: {v}")


def _as_int(v: Any, field_name: str) -> int:
    try:
        return int(v)
    except Exception:
        raise RuntimeError(f"PC_VALIDATION_ERROR: {field_name} must be an integer")


def _pick_first(d: Dict[str, Any], *keys: str):
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return None


def _get_datastore_container(ctx: Dict[str, Any]) -> Any:
    ds = ctx.get("datastores")
    if ds is not None:
        return ds
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None


def _resolve_datastore(ctx: Dict[str, Any], ds_alias: str) -> Dict[str, Any]:
    ds_alias = (ds_alias or "").strip()
    if not ds_alias:
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_ds")

    container = _get_datastore_container(ctx)
    if container is None:
        raise RuntimeError("PC_VALIDATION_ERROR: ctx missing datastores (or env.datastores)")

    if isinstance(container, dict):
        ds = container.get(ds_alias)
        if isinstance(ds, dict):
            if "ds_alias" not in ds:
                ds = dict(ds)
                ds["ds_alias"] = ds_alias
            return ds
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    if isinstance(container, list):
        for item in container:
            if not isinstance(item, dict):
                continue
            alias = (item.get("ds_alias") or item.get("alias") or "").strip()
            if alias == ds_alias:
                return item
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    raise RuntimeError("PC_VALIDATION_ERROR: unsupported datastores container shape")


def _datastore_identity(ds: Dict[str, Any]) -> Dict[str, Any]:
    ws = ds.get("workspace") if isinstance(ds.get("workspace"), dict) else {}
    dso = ds.get("datastore") if isinstance(ds.get("datastore"), dict) else {}

    ws_id = _pick_first(ws, "ws_id", "id") or ds.get("ws_id")
    ws_name = _pick_first(ws, "ws_name", "name") or ds.get("ws_name")
    ds_id = _pick_first(dso, "ds_id", "id") or ds.get("ds_id")
    ds_name = _pick_first(dso, "ds_name", "name") or ds.get("ds_name")

    return {
        "ws_id": ws_id,
        "ws_name": ws_name,
        "ds_id": ds_id,
        "ds_name": ds_name,
    }


def _to_relative_files_path(p: str) -> str:
    s = (p or "").replace("\\", "/")
    if s.lower().startswith("path:"):
        s = s[5:]
    s = s.lstrip("/")
    if s.startswith("Files/"):
        return s
    if s.lower().startswith("files/"):
        return "Files/" + s.split("/", 1)[1]
    return "Files/" + s


def _build_files_abfss_path(ws_id: str, ds_id: str, relative_path: str) -> str:
    rp = (relative_path or "").lstrip("/").replace("\\", "/")
    return f"abfss://{ws_id}@onelake.dfs.fabric.microsoft.com/{ds_id}/{rp}"


def _resolve_source_path(ctx: Dict[str, Any]) -> str:
    src_path = _resolve_param(ctx, "src_path")
    if src_path is None:
        src_path = _resolve_param(ctx, "folder_path")
    if src_path is None:
        src_path = _resolve_param(ctx, "object")

    if not isinstance(src_path, str) or not src_path.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_path (or folder_path/object)")

    return src_path.strip()


def _extract_epoch_millis(entry: Any) -> Optional[int]:
    candidates = [
        getattr(entry, "modifyTime", None),
        getattr(entry, "modificationTime", None),
        getattr(entry, "lastModified", None),
        getattr(entry, "lastModifiedTime", None),
        getattr(entry, "mtime", None),
    ]

    for c in candidates:
        if c is None:
            continue
        if isinstance(c, (int, float)):
            n = int(c)
            if n <= 0:
                continue
            # If seconds were returned, normalize to ms.
            if n < 10_000_000_000:
                n *= 1000
            return n
        if isinstance(c, str):
            s = c.strip()
            if not s:
                continue
            try:
                n = int(float(s))
                if n < 10_000_000_000:
                    n *= 1000
                return n
            except Exception:
                pass
            try:
                dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
                return int(dt.timestamp() * 1000)
            except Exception:
                pass
    return None


def _list_files(root_path: str, recursive: bool) -> List[Dict[str, Any]]:
    fs = mssparkutils.fs
    out: List[Dict[str, Any]] = []
    stack: List[str] = [root_path]

    while stack:
        current = stack.pop()
        for entry in fs.ls(current):
            is_dir = bool(getattr(entry, "isDir", False))
            if is_dir:
                if recursive:
                    stack.append(getattr(entry, "path", ""))
                continue

            out.append(
                {
                    "name": str(getattr(entry, "name", "") or ""),
                    "path": str(getattr(entry, "path", "") or ""),
                    "size_bytes": int(getattr(entry, "size", 0) or 0),
                    "modified_epoch_ms": _extract_epoch_millis(entry),
                }
            )

    return out


def _normalize_extensions(values: List[str]) -> List[str]:
    out: List[str] = []
    for v in values:
        if not isinstance(v, str):
            continue
        x = v.strip().lower()
        if not x:
            continue
        if not x.startswith("."):
            x = "." + x
        out.append(x)
    return sorted(set(out))


def _file_extension(name: str) -> str:
    i = name.rfind(".")
    if i <= 0:
        return ""
    return name[i:].lower()


def _validate_rules(rules: Any) -> List[Dict[str, Any]]:
    if not isinstance(rules, list) or not rules:
        raise RuntimeError("PC_VALIDATION_ERROR: rules must be a non-empty array")

    normalized: List[Dict[str, Any]] = []
    for idx, rule in enumerate(rules):
        if not isinstance(rule, dict):
            raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}] must be an object")

        rule_id = rule.get("rule_id")
        expectation = str(rule.get("expectation") or "").strip().lower()
        severity = str(rule.get("severity") or "blocking").strip().lower()

        if not isinstance(rule_id, str) or not rule_id.strip():
            raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].rule_id is required")
        if expectation not in SUPPORTED_EXPECTATIONS:
            raise RuntimeError(
                "PC_VALIDATION_ERROR: rules[{}].expectation '{}' is unsupported; supported={}"
                .format(idx, expectation, sorted(SUPPORTED_EXPECTATIONS))
            )
        if severity not in {"blocking", "warning"}:
            raise RuntimeError(
                f"PC_VALIDATION_ERROR: rules[{idx}].severity must be 'blocking' or 'warning'"
            )

        min_count = rule.get("min_count")
        max_count = rule.get("max_count")
        if expectation in {"file_exists", "file_count_between"}:
            if min_count is None and expectation == "file_exists":
                min_count = 1
            if min_count is not None:
                min_count = _as_int(min_count, f"rules[{idx}].min_count")
                if min_count < 0:
                    raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].min_count must be >= 0")
            if max_count is not None:
                max_count = _as_int(max_count, f"rules[{idx}].max_count")
                if max_count < 0:
                    raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].max_count must be >= 0")
            if min_count is not None and max_count is not None and min_count > max_count:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].min_count cannot exceed max_count"
                )

        regex = rule.get("regex")
        if expectation == "file_name_regex":
            if not isinstance(regex, str) or not regex.strip():
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].regex must be a non-empty string"
                )
            regex = regex.strip()
            try:
                re.compile(regex)
            except Exception as exc:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].regex is invalid: {exc}"
                )

        extensions = rule.get("extensions")
        if expectation == "extension_in_set":
            if not isinstance(extensions, list) or not extensions:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].extensions must be a non-empty array"
                )
            extensions = _normalize_extensions(extensions)
            if not extensions:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].extensions must contain non-empty values"
                )

        min_size_bytes = rule.get("min_size_bytes")
        max_size_bytes = rule.get("max_size_bytes")
        if expectation == "size_bytes_between":
            if min_size_bytes is None and max_size_bytes is None:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}] requires min_size_bytes or max_size_bytes"
                )
            if min_size_bytes is not None:
                min_size_bytes = _as_int(min_size_bytes, f"rules[{idx}].min_size_bytes")
                if min_size_bytes < 0:
                    raise RuntimeError(
                        f"PC_VALIDATION_ERROR: rules[{idx}].min_size_bytes must be >= 0"
                    )
            if max_size_bytes is not None:
                max_size_bytes = _as_int(max_size_bytes, f"rules[{idx}].max_size_bytes")
                if max_size_bytes < 0:
                    raise RuntimeError(
                        f"PC_VALIDATION_ERROR: rules[{idx}].max_size_bytes must be >= 0"
                    )
            if min_size_bytes is not None and max_size_bytes is not None and min_size_bytes > max_size_bytes:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].min_size_bytes cannot exceed max_size_bytes"
                )

        max_age_minutes = rule.get("max_age_minutes")
        if expectation == "max_file_age_minutes":
            if max_age_minutes is None:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].max_age_minutes is required"
                )
            max_age_minutes = _as_int(max_age_minutes, f"rules[{idx}].max_age_minutes")
            if max_age_minutes < 0:
                raise RuntimeError(
                    f"PC_VALIDATION_ERROR: rules[{idx}].max_age_minutes must be >= 0"
                )

        normalized.append(
            {
                "rule_id": rule_id.strip(),
                "expectation": expectation,
                "severity": severity,
                "path": rule.get("path"),
                "recursive": _as_bool(rule.get("recursive", False), default=False),
                "min_count": min_count,
                "max_count": max_count,
                "regex": regex,
                "extensions": extensions,
                "min_size_bytes": min_size_bytes,
                "max_size_bytes": max_size_bytes,
                "max_age_minutes": max_age_minutes,
                "ignore_case": _as_bool(rule.get("ignore_case", True), default=True),
            }
        )

    return normalized


def _evaluate_file_rule(files: List[Dict[str, Any]], rule: Dict[str, Any]) -> Dict[str, Any]:
    expectation = rule["expectation"]
    now_epoch_ms = int(datetime.now(timezone.utc).timestamp() * 1000)

    failure_details: List[Dict[str, Any]] = []

    if expectation == "file_exists":
        min_count = int(rule.get("min_count") or 1)
        success = len(files) >= min_count
        observed = {"file_count": len(files), "required_min_count": min_count}
        if not success:
            failure_details.append({"reason": "file_count_below_min"})

    elif expectation == "file_count_between":
        min_count = rule.get("min_count")
        max_count = rule.get("max_count")
        file_count = len(files)

        success = True
        if min_count is not None and file_count < int(min_count):
            success = False
        if max_count is not None and file_count > int(max_count):
            success = False

        observed = {
            "file_count": file_count,
            "min_count": min_count,
            "max_count": max_count,
        }
        if not success:
            failure_details.append({"reason": "file_count_out_of_range"})

    elif expectation == "file_name_regex":
        pattern = re.compile(str(rule.get("regex") or ""))
        for f in files:
            name = f.get("name") or ""
            if not pattern.match(name):
                failure_details.append({"name": name, "reason": "regex_mismatch"})
        success = len(failure_details) == 0
        observed = {
            "regex": rule.get("regex"),
            "file_count": len(files),
        }

    elif expectation == "extension_in_set":
        allowed = set(rule.get("extensions") or [])
        for f in files:
            name = f.get("name") or ""
            ext = _file_extension(name)
            if ext not in allowed:
                failure_details.append({"name": name, "extension": ext, "reason": "extension_not_allowed"})
        success = len(failure_details) == 0
        observed = {
            "allowed_extensions": sorted(allowed),
            "file_count": len(files),
        }

    elif expectation == "size_bytes_between":
        min_size_bytes = rule.get("min_size_bytes")
        max_size_bytes = rule.get("max_size_bytes")
        for f in files:
            size = int(f.get("size_bytes") or 0)
            if min_size_bytes is not None and size < int(min_size_bytes):
                failure_details.append({"name": f.get("name"), "size_bytes": size, "reason": "below_min_size"})
                continue
            if max_size_bytes is not None and size > int(max_size_bytes):
                failure_details.append({"name": f.get("name"), "size_bytes": size, "reason": "above_max_size"})
        success = len(failure_details) == 0
        observed = {
            "min_size_bytes": min_size_bytes,
            "max_size_bytes": max_size_bytes,
            "file_count": len(files),
        }

    elif expectation == "max_file_age_minutes":
        max_age_minutes = int(rule.get("max_age_minutes"))
        max_age_ms = max_age_minutes * 60 * 1000
        for f in files:
            modified_epoch_ms = f.get("modified_epoch_ms")
            if modified_epoch_ms is None:
                failure_details.append({"name": f.get("name"), "reason": "missing_modified_time"})
                continue
            age_ms = now_epoch_ms - int(modified_epoch_ms)
            if age_ms > max_age_ms:
                failure_details.append(
                    {
                        "name": f.get("name"),
                        "age_minutes": round(age_ms / 60000.0, 3),
                        "reason": "age_exceeds_threshold",
                    }
                )
        success = len(failure_details) == 0
        observed = {
            "max_age_minutes": max_age_minutes,
            "file_count": len(files),
        }

    elif expectation == "no_duplicate_file_names":
        ignore_case = bool(rule.get("ignore_case", True))
        seen: Dict[str, int] = {}
        for f in files:
            name = str(f.get("name") or "")
            key = name.lower() if ignore_case else name
            seen[key] = seen.get(key, 0) + 1
        dup_keys = [k for k, count in seen.items() if count > 1]
        for key in dup_keys:
            failure_details.append({"name_key": key, "reason": "duplicate_name"})
        success = len(failure_details) == 0
        observed = {
            "duplicate_name_count": len(dup_keys),
            "ignore_case": ignore_case,
            "file_count": len(files),
        }

    else:
        raise RuntimeError(f"PC_VALIDATION_ERROR: unsupported expectation dispatch='{expectation}'")

    return {
        "success": bool(success),
        "checked_file_count": len(files),
        "failed_file_count": len(failure_details),
        "observed_value": observed,
        "message": None if success else f"{len(failure_details)} file(s) failed",
        "failures": failure_details,
    }


def dq_check_file_rules(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Evaluate file-level DQ rules on a Files folder using Output Contract v1.0.0.
    """
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    spark = ctx.get("spark")
    if spark is None:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "activity_type": ACTIVITY_NAME,
                "error_type": "ENGINE_ERROR",
                "error_message": "spark not provided",
            },
        }

    _log_debug(ctx.get("logger"), f"{ACTIVITY_NAME}: start")

    try:
        src_ds = _resolve_param(ctx, "src_ds")
        if not isinstance(src_ds, str) or not src_ds.strip():
            raise RuntimeError("PC_VALIDATION_ERROR: missing src_ds")

        src_path = _resolve_source_path(ctx)
        default_recursive = _as_bool(_resolve_param(ctx, "recursive", False), default=False)
        fail_on_blocking = _as_bool(_resolve_param(ctx, "fail_on_blocking", True), default=True)

        ds = _resolve_datastore(ctx, src_ds)
        ident = _datastore_identity(ds)
        ws_id = ident.get("ws_id")
        ds_id = ident.get("ds_id")
        if not ws_id or not ds_id:
            raise RuntimeError(f"PC_VALIDATION_ERROR: datastore '{src_ds}' missing ws_id/ds_id")

        default_abfss = _build_files_abfss_path(ws_id, ds_id, _to_relative_files_path(src_path))
        rules = _validate_rules(_resolve_param(ctx, "rules"))

        _log_debug(
            ctx.get("logger"),
            f"{ACTIVITY_NAME}: validated rules count={len(rules)} fail_on_blocking={fail_on_blocking}",
        )

        rows: List[Row] = []
        dq_passed_rules: List[str] = []
        dq_failed_rules: List[str] = []
        blocking_failures: List[str] = []

        for rule in rules:
            rule_path_raw = rule.get("path")
            rule_path = src_path if not isinstance(rule_path_raw, str) or not rule_path_raw.strip() else rule_path_raw.strip()
            rule_recursive = bool(rule.get("recursive", default_recursive))
            rule_abfss = _build_files_abfss_path(ws_id, ds_id, _to_relative_files_path(rule_path))

            _log_debug(
                ctx.get("logger"),
                (
                    f"{ACTIVITY_NAME}: evaluating rule_id={rule['rule_id']} "
                    f"expectation={rule['expectation']} path={rule_path} recursive={rule_recursive}"
                ),
            )

            files = _list_files(rule_abfss, rule_recursive)
            eval_result = _evaluate_file_rule(files, rule)
            passed = bool(eval_result["success"])

            if passed:
                dq_passed_rules.append(rule["rule_id"])
            else:
                dq_failed_rules.append(rule["rule_id"])
                if rule["severity"] == "blocking":
                    blocking_failures.append(rule["rule_id"])

            observed_payload = {
                "observed": eval_result.get("observed_value"),
                "sample_failures": (eval_result.get("failures") or [])[:20],
            }

            rows.append(
                Row(
                    rule_id=rule["rule_id"],
                    expectation=rule["expectation"],
                    severity=rule["severity"],
                    path=rule_path,
                    success=passed,
                    checked_file_count=int(eval_result["checked_file_count"]),
                    failed_file_count=int(eval_result["failed_file_count"]),
                    observed_value=json.dumps(observed_payload, default=str),
                    message=eval_result.get("message"),
                )
            )

            _log_debug(
                ctx.get("logger"),
                (
                    f"{ACTIVITY_NAME}: rule_id={rule['rule_id']} success={passed} "
                    f"checked={eval_result['checked_file_count']} failed={eval_result['failed_file_count']}"
                ),
            )

        status = "FAILED" if (fail_on_blocking and blocking_failures) else "SUCCEEDED"
        out_df = spark.createDataFrame(rows, schema=DQ_FILE_RESULT_SCHEMA)

        _log_debug(
            ctx.get("logger"),
            (
                f"{ACTIVITY_NAME}: completed status={status} "
                f"passed={len(dq_passed_rules)} failed={len(dq_failed_rules)} "
                f"blocking_failures={len(blocking_failures)}"
            ),
        )

        return {
            "df": out_df,
            "result": {
                "status": status,
                "activity_type": ACTIVITY_NAME,
                "src_ds": src_ds.strip(),
                "src_path": src_path,
                "src_abfss": default_abfss,
                "identity": ident,
                "total_rules": len(rules),
                "dq_passed_rules": dq_passed_rules,
                "dq_failed_rules": dq_failed_rules,
                "blocking_failures": blocking_failures,
                "fail_on_blocking": fail_on_blocking,
            },
        }

    except Exception as exc:
        _log_debug(
            ctx.get("logger"),
            f"{ACTIVITY_NAME}: failed error_type={type(exc).__name__} error_message={exc}",
        )
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "activity_type": ACTIVITY_NAME,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            },
        }


register_activity(
    name=ACTIVITY_NAME,
    fn=dq_check_file_rules,
    kind="quality",
    notes=(
        "Evaluate file DQ rules on Lakehouse Files "
        "(supports file_exists, file_count_between, file_name_regex, "
        "extension_in_set, size_bytes_between, max_file_age_minutes, "
        "no_duplicate_file_names)"
    ),
)
