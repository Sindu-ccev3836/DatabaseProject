# -*- coding: utf-8 -*-

"""
Built-in activity: xf.append_bronze_aduit_columns

Appends bronze audit columns to an input DataFrame:
- loadg_dtm (timestamp)
- snapshot_dt (date)
- pipeline_run_id (string)

Defaults:
- loadg_dtm: current system timestamp
- snapshot_dt: current system date
- pipeline_run_id: "NA"
"""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Dict, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from alkali1.pc.engine.activity_registry import register_activity


ACTIVITY_NAME = "xf.append_bronze_aduit_columns"


def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    ctx = ctx or {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _resolve_param(ctx: Dict[str, Any], key: str, default=None):
    p = ctx.get("params") or {}
    if isinstance(p, dict) and key in p:
        return p.get(key)
    return ctx.get(key, default)


def _coerce_timestamp(v: Any) -> Optional[datetime]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day)
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        try:
            return datetime.fromisoformat(s.replace("Z", "+00:00"))
        except Exception:
            pass
        for fmt in (
            "%Y-%m-%d %H:%M:%S.%f",
            "%Y-%m-%d %H:%M:%S",
            "%Y/%m/%d %H:%M:%S.%f",
            "%Y/%m/%d %H:%M:%S",
            "%Y-%m-%d",
        ):
            try:
                return datetime.strptime(s, fmt)
            except Exception:
                continue
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid loadg_dtm: {v}")


def _coerce_date(v: Any) -> Optional[date]:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    if isinstance(v, str):
        s = v.strip()
        if not s:
            return None
        try:
            return date.fromisoformat(s)
        except Exception:
            ts = _coerce_timestamp(s)
            return ts.date() if ts is not None else None
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid snapshot_dt: {v}")


def _resolve_src_df(ctx: Dict[str, Any], src_df_ref: Any) -> DataFrame:
    if isinstance(src_df_ref, DataFrame):
        return src_df_ref

    if isinstance(src_df_ref, dict) and isinstance(src_df_ref.get("df"), DataFrame):
        return src_df_ref["df"]

    if isinstance(src_df_ref, str) and src_df_ref.strip():
        ref = src_df_ref.strip()
        outputs = ctx.get("outputs") or {}
        if isinstance(outputs, dict):
            if "." in ref:
                name, channel = ref.split(".", 1)
                od = outputs.get(name)
                if isinstance(od, dict) and isinstance(od.get(channel), DataFrame):
                    return od[channel]
            od = outputs.get(ref)
            if isinstance(od, dict) and isinstance(od.get("df"), DataFrame):
                return od["df"]

    if isinstance(ctx.get("df"), DataFrame):
        return ctx["df"]
    if isinstance(ctx.get("src_df"), DataFrame):
        return ctx["src_df"]

    raise RuntimeError("PC_VALIDATION_ERROR: cannot resolve src df; provide params.src_df or ctx['df']")


def _resolve_runtime_pipeline_run_id(ctx: Dict[str, Any]) -> str:
    # Preferred runtime shapes
    execution = ctx.get("execution")
    if isinstance(execution, dict):
        v = execution.get("pipeline_run_id")
        if v is not None and str(v).strip():
            return str(v).strip()

    runtime = ctx.get("runtime")
    if isinstance(runtime, dict):
        ex = runtime.get("execution")
        if isinstance(ex, dict):
            v = ex.get("pipeline_run_id")
            if v is not None and str(v).strip():
                return str(v).strip()

    env = ctx.get("env")
    if isinstance(env, dict):
        ex = env.get("execution")
        if isinstance(ex, dict):
            v = ex.get("pipeline_run_id")
            if v is not None and str(v).strip():
                return str(v).strip()

    return "NA"


def xf_append_bronze_aduit_columns(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Append bronze audit columns to src DataFrame and return Output Contract v1.0.0.
    """
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    p = ctx.get("params") or {}

    try:
        src_df_ref = _resolve_param(ctx, "src_df", None)
        src_df = _resolve_src_df(ctx, src_df_ref if src_df_ref is not None else ctx.get("df"))

        loadg_dtm = _coerce_timestamp(_resolve_param(ctx, "loadg_dtm", None)) or datetime.now()
        snapshot_dt = _coerce_date(_resolve_param(ctx, "snapshot_dt", None)) or date.today()

        pipeline_run_id = _resolve_runtime_pipeline_run_id(ctx)

        out_df = (
            src_df
            .withColumn("loadg_dtm", F.lit(loadg_dtm).cast("timestamp"))
            .withColumn("snapshot_dt", F.lit(snapshot_dt).cast("date"))
            .withColumn("pipeline_run_id", F.lit(pipeline_run_id).cast("string"))
        )

        # Keep appended audit columns at the right end deterministically.
        appended_cols = ["loadg_dtm", "snapshot_dt", "pipeline_run_id"]
        base_cols = [c for c in out_df.columns if c not in appended_cols]
        out_df = out_df.select(*(base_cols + appended_cols))

        if logger:
            logger.info(f"{ACTIVITY_NAME}: appended columns={appended_cols}")

        return {
            "df": out_df,
            "result": {
                "status": "SUCCEEDED",
                "appended_columns": appended_cols,
                "loadg_dtm": str(loadg_dtm),
                "snapshot_dt": str(snapshot_dt),
                "pipeline_run_id": pipeline_run_id,
                "input_row_count": None,
            },
        }
    except Exception as e:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "error_message": str(e),
                "error_type": type(e).__name__,
            },
        }


register_activity(
    name=ACTIVITY_NAME,
    fn=xf_append_bronze_aduit_columns,
    kind="transform",
    notes="Append bronze audit columns loadg_dtm/snapshot_dt/pipeline_run_id to src df",
)
