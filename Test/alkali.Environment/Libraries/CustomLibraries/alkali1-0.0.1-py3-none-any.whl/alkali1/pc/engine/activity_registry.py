# File: alkali1/pc/engine/activity_registry.py
# -*- coding: utf-8 -*-

"""
Alkali Engine Activity Registry (v3.0.0)

Purpose:
- Deterministic registration and lookup of activities by name
- Engine-owned, single-registry model
- Immutable after freeze
- NO dependency on activity_api (single-engine Alkali1)

Key guarantees:
- One canonical registry
- Explicit registration
- Alias support
- Safe freeze semantics
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import inspect
import os
from typing import Callable, Dict, Mapping, Optional


# ---------------------------------------------------------------------------
# Activity metadata (engine-owned)
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ActivitySpec:
    """
    Immutable activity specification.
    """
    name: str
    fn: Callable
    kind: str = "other"   # e.g. "io", "transform", "control"
    notes: str = ""
    registration_type: str = "unknown"  # built_in | local | custom | unknown
    code_hash_algo: str = ""
    code_hash_scope: str = "function_plus_helpers"  # function | function_plus_helpers
    code_hash: str = ""
    module: str = ""
    source_path: str = ""


def _normalize_path(path: str) -> str:
    return (path or "").replace("\\", "/").lower()


def _infer_registration_type(*, fn: Callable, module: str, source_path: str) -> str:
    m = (module or "").strip().lower()
    p = _normalize_path(source_path)

    if m == "__main__" or p.endswith(".ipynb"):
        return "local"

    if ".pc.engine.activities" in m:
        return "built_in"

    if "/pc/engine/activities/" in p:
        return "built_in"

    if m:
        return "custom"

    return "unknown"


def _function_identity(fn: Callable) -> str:
    return f"{getattr(fn, '__module__', '')}:{getattr(fn, '__qualname__', getattr(fn, '__name__', ''))}"


def _safe_get_function_source(fn: Callable) -> str:
    try:
        return inspect.getsource(fn)
    except Exception:
        return ""


def _collect_same_module_helpers(fn: Callable) -> Dict[str, Callable]:
    """
    Collect helper functions referenced by `fn` from the same module.
    Traversal is recursive via code name references and cycle-safe.
    """
    module = getattr(fn, "__module__", "")
    seen: set[str] = set()
    helpers: Dict[str, Callable] = {}

    def visit(cur: Callable) -> None:
        cur_key = _function_identity(cur)
        if cur_key in seen:
            return
        seen.add(cur_key)

        names = getattr(getattr(cur, "__code__", None), "co_names", ()) or ()
        g = getattr(cur, "__globals__", {}) or {}
        for name in names:
            obj = g.get(name)
            if not inspect.isfunction(obj):
                continue
            if obj is fn:
                continue
            if getattr(obj, "__module__", "") != module:
                continue

            ident = _function_identity(obj)
            if ident not in helpers:
                helpers[ident] = obj
            visit(obj)

    visit(fn)
    return helpers


def _compute_code_hash(*, fn: Callable, algo: str, scope: str) -> str:
    a = (algo or "sha256").strip().lower()
    if a not in {"sha256", "md5"}:
        raise ValueError("code_hash_algo must be one of: sha256, md5")

    s = (scope or "function").strip().lower()
    if s not in {"function", "function_plus_helpers"}:
        raise ValueError("code_hash_scope must be one of: function, function_plus_helpers")

    chunks = []

    main_src = _safe_get_function_source(fn)
    if main_src:
        chunks.append(("function", _function_identity(fn), main_src))
    else:
        chunks.append(("function", _function_identity(fn), _function_identity(fn)))

    if s == "function_plus_helpers":
        helper_map = _collect_same_module_helpers(fn)
        for ident in sorted(helper_map.keys()):
            helper_fn = helper_map[ident]
            helper_src = _safe_get_function_source(helper_fn)
            chunks.append(("helper", ident, helper_src or ident))

    material = "\n\n".join(
        f"[{kind}] {ident}\n{src}" for kind, ident, src in chunks
    )

    h = hashlib.new(a)
    h.update(material.encode("utf-8"))
    return h.hexdigest()


# ---------------------------------------------------------------------------
# ✅ Canonical registry storage (SINGLE SOURCE OF TRUTH)
# ---------------------------------------------------------------------------

_ACTIVITY_REGISTRY: Dict[str, ActivitySpec] = {}
_ACTIVITY_ALIASES: Dict[str, str] = {}
_FROZEN: bool = False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _assert_not_frozen() -> None:
    if _FROZEN:
        raise RuntimeError(
            "ACTIVITY_REGISTRY_FROZEN: no further activity registration allowed"
        )


def resolve_name(name: str) -> str:
    """
    Resolve an activity name via registered aliases.
    """
    if not isinstance(name, str):
        return ""
    key = name.strip()
    return _ACTIVITY_ALIASES.get(key, key)


# ---------------------------------------------------------------------------
# Registration API (ENGINE-OWNED)
# ---------------------------------------------------------------------------

def register_activity(
    name: str,
    fn: Callable,
    *,
    kind: str = "other",
    notes: str = "",
    registration_type: Optional[str] = None,
    code_hash_algo: str = "sha256",
    code_hash_scope: str = "function_plus_helpers",
) -> None:
    """
    Register an activity callable.

    Must be called during engine initialization
    (before freeze_registry()).
    """
    _assert_not_frozen()

    if not name or not callable(fn):
        raise ValueError("activity name must be non-empty and fn must be callable")

    key = name.strip()
    if key in _ACTIVITY_REGISTRY:
        raise RuntimeError(f"ACTIVITY_ALREADY_REGISTERED: {key}")

    module = getattr(fn, "__module__", "") or ""
    try:
        src = inspect.getsourcefile(fn) or inspect.getfile(fn) or ""
    except Exception:
        src = ""

    reg_type = (registration_type or "").strip().lower()
    if not reg_type:
        reg_type = _infer_registration_type(fn=fn, module=module, source_path=src)

    if reg_type not in {"built_in", "local", "custom", "unknown"}:
        raise ValueError(
            "registration_type must be one of: built_in, local, custom, unknown"
        )

    hash_scope = (code_hash_scope or "function_plus_helpers").strip().lower()
    if hash_scope not in {"function", "function_plus_helpers"}:
        raise ValueError("code_hash_scope must be one of: function, function_plus_helpers")

    code_hash = _compute_code_hash(fn=fn, algo=code_hash_algo, scope=hash_scope)

    _ACTIVITY_REGISTRY[key] = ActivitySpec(
        name=key,
        fn=fn,
        kind=kind,
        notes=notes,
        registration_type=reg_type,
        code_hash_algo=code_hash_algo.strip().lower(),
        code_hash_scope=hash_scope,
        code_hash=code_hash,
        module=module,
        source_path=os.path.normpath(src) if src else "",
    )


def register_alias(alias: str, canonical: str) -> None:
    """
    Register a non-breaking alias → canonical activity mapping.
    """
    _assert_not_frozen()

    if not alias or not canonical:
        raise ValueError("alias and canonical must be non-empty strings")

    _ACTIVITY_ALIASES[alias.strip()] = canonical.strip()


# ---------------------------------------------------------------------------
# Lookup API (engine runtime)
# ---------------------------------------------------------------------------

def get_activity(name: str) -> Optional[Callable]:
    """
    Return the callable for an activity name, or None.
    Alias-aware.
    """
    canon = resolve_name(name)
    spec = _ACTIVITY_REGISTRY.get(canon)
    return spec.fn if spec else None


def get_activity_spec(name: str) -> Optional[ActivitySpec]:
    """
    Return ActivitySpec for an activity name, or None.
    Alias-aware.
    """
    canon = resolve_name(name)
    return _ACTIVITY_REGISTRY.get(canon)


def registry_specs() -> Mapping[str, ActivitySpec]:
    """
    Read-only snapshot of all registered activities.
    """
    return dict(_ACTIVITY_REGISTRY)


# ---------------------------------------------------------------------------
# Registry lifecycle
# ---------------------------------------------------------------------------

def freeze_registry() -> None:
    """
    Freeze the registry to prevent further mutation.
    Must be called before execution begins.
    """
    global _FROZEN
    _FROZEN = True


def is_frozen() -> bool:
    return _FROZEN


# ---------------------------------------------------------------------------
# Governance helpers
# ---------------------------------------------------------------------------

def is_control_activity(name: str) -> bool:
    """
    Return True if the activity is a control activity.
    """
    spec = get_activity_spec(name)
    if spec:
        return spec.kind == "control"
    return resolve_name(name).lower().startswith("control.")