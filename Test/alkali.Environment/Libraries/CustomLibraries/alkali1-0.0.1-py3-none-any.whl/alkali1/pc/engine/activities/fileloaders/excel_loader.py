# excel_loader.py
from pyspark.sql import SparkSession, DataFrame
from .base import FileLoader
from alkali1.pc.engine.file_loader_registry import register_file_loader


class ExcelLoader(FileLoader):

    @property
    def capability(self) -> str:
        return "excel.v2"

    def load(self, spark: SparkSession, activity: dict) -> DataFrame:
        sheet_name = activity.get("sheet_name", "Sheet1")
        with_header = activity.get("with_header", "Y") == "Y"
        hash_alg = activity.get("hash_algorithm", "md5")

        if not sheet_name or not isinstance(sheet_name, str):
            raise ValueError("sheet_name must be a non-empty string")

        # Observational only
        activity["_loader_param"] = {
            "sheet_name": sheet_name,
            "with_header": with_header,
            "hash_algorithm": hash_alg
        }

        # Pass resolved value back for observation only
        activity["_resolved_sheet_name"] = sheet_name

        return (
            spark.read
            .format("com.crealytics.spark.excel")
            .option("header", with_header)
            .option("sheetName", sheet_name)
            .load(activity["current_file_path"])
        )


register_file_loader("excel", ExcelLoader)