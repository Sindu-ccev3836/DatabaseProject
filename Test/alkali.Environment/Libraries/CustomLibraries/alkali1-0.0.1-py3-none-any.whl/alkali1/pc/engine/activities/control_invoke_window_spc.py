# File: alkali1/pc/engine/activities/control_invoke_window_spc.py
# -*- coding: utf-8 -*-

"""
control.invoke_window_spc

Control activity:
- Takes inline SPC + sources + window_detection config
- Computes FINAL window_set before executing first window
- Validates SPC governance constraints
- Iterates windows and logs invocation intent per window

NOTE:
Actual SPC execution is intentionally NOT performed here.
This activity is responsible only for validation, planning, and logging.
"""

from __future__ import annotations

import json
import re
import hashlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from alkali1.pc.engine.activity_registry import register_activity


# ----------------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------------

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log(logger, level: str, msg: str, extra: Optional[Dict[str, Any]] = None) -> None:
    payload = msg if extra is None else f"{msg} {json.dumps(extra, default=str)}"
    if logger:
        fn = getattr(logger, level.lower(), None)
        if callable(fn):
            fn(payload)
            return
    print(payload)


# ----------------------------------------------------------------------
# SPC identity helpers
# ----------------------------------------------------------------------

def _canonicalize_json(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _canonicalize_json(obj[k]) for k in sorted(obj.keys())}
    if isinstance(obj, list):
        return [_canonicalize_json(x) for x in obj]
    return obj


def _compute_spc_hash(spc_obj: dict) -> str:
    canonical_obj = _canonicalize_json(spc_obj)
    canonical_str = json.dumps(
        canonical_obj,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()


def _derive_spc_id(spc_obj: dict, spc_hash: str) -> str:
    meta = spc_obj.get("pc_metadata")
    if isinstance(meta, dict):
        name = meta.get("name")
        if isinstance(name, str) and name.strip():
            return name.strip()

    pipes = spc_obj.get("pipelines")
    if isinstance(pipes, list) and pipes and isinstance(pipes[0], dict):
        pn = pipes[0].get("pipeline_name")
        if isinstance(pn, str) and pn.strip():
            return pn.strip()

    return f"spc_{spc_hash[:12]}"


# ----------------------------------------------------------------------
# Window detection helpers (deterministic)
# ----------------------------------------------------------------------

def _parse_window_size(size: str) -> int:
    s = (size or "").strip().lower()
    m = re.match(r"^(\d+)\s*([smhd])$", s)
    if not m:
        raise RuntimeError(
            "WINDOW_DETECTION_ERROR: window_size must match <n>[s|m|h|d]"
        )
    n = int(m.group(1))
    mult = {"s": 1, "m": 60, "h": 3600, "d": 86400}[m.group(2)]
    return n * mult


def _to_epoch_seconds(ts_str: str) -> int:
    if isinstance(ts_str, str) and ts_str.strip().isdigit():
        return int(ts_str.strip())
    dt = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
    return int(dt.timestamp())


def _epoch_to_iso(ts: int) -> str:
    return (
        datetime.fromtimestamp(ts, tz=timezone.utc)
        .isoformat()
        .replace("+00:00", "Z")
    )


def _floor_epoch(ts: int, window_sec: int) -> int:
    return (ts // window_sec) * window_sec


def _detect_windows(
    sources: List[dict],
    cfg: dict,
) -> List[dict]:
    """
    Deterministic window detection.
    This is a minimal, governance-safe implementation.
    """
    if not isinstance(cfg, dict):
        raise RuntimeError(
            "WINDOW_DETECTION_ERROR: window_detection must be an object"
        )

    window_size = _parse_window_size(cfg.get("window_size"))
    start = _to_epoch_seconds(cfg.get("start"))
    end = _to_epoch_seconds(cfg.get("end"))

    windows: List[dict] = []
    cur = _floor_epoch(start, window_size)

    while cur < end:
        nxt = cur + window_size
        windows.append(
            {
                "id": f"{cur}-{nxt}",
                "start": _epoch_to_iso(cur),
                "end": _epoch_to_iso(min(nxt, end)),
            }
        )
        cur = nxt

    return windows


def _apply_iteration_controls(
    window_set: List[dict],
    iteration: dict,
) -> List[dict]:
    iteration = iteration if isinstance(iteration, dict) else {}
    order = (iteration.get("order") or "asc").lower()
    max_windows = iteration.get("max_windows")

    window_set = sorted(
        window_set,
        key=lambda w: (w.get("start") or "", w.get("id") or ""),
    )

    if order == "desc":
        window_set = list(reversed(window_set))

    if isinstance(max_windows, int) and max_windows >= 0:
        window_set = window_set[:max_windows]

    return window_set


# ----------------------------------------------------------------------
# Activity implementation
# ----------------------------------------------------------------------

def control_invoke_window_spc(ctx: Dict[str, Any]) -> None:
    """
    Validate and plan SPC window invocation.
    """
    logger = ctx.get("logger")
    act = ctx.get("act") or {}

    params = act.get("params") or {}
    spc_obj = params.get("spc")
    sources = params.get("sources") or []
    window_cfg = params.get("window_detection")
    iteration_cfg = params.get("iteration")

    if not isinstance(spc_obj, dict):
        raise RuntimeError(
            "control.invoke_window_spc requires params.spc (object)"
        )

    # ------------------------------------------------------------
    # SPC identity
    # ------------------------------------------------------------
    spc_hash = _compute_spc_hash(spc_obj)
    spc_id = _derive_spc_id(spc_obj, spc_hash)

    _log(
        logger,
        "info",
        f"control.invoke_window_spc: SPC '{spc_id}' "
        f"(hash={spc_hash})",
    )

    # ------------------------------------------------------------
    # Detect windows
    # ------------------------------------------------------------
    window_set = _detect_windows(sources, window_cfg)
    window_set = _apply_iteration_controls(window_set, iteration_cfg)

    _log(
        logger,
        "info",
        f"control.invoke_window_spc: {len(window_set)} windows planned",
    )

    # ------------------------------------------------------------
    # Iterate windows (LOG ONLY)
    # ------------------------------------------------------------
    for idx, w in enumerate(window_set):
        _log(
            logger,
            "info",
            f"control.invoke_window_spc: planning window {idx + 1}/{len(window_set)}",
            extra={
                "spc_id": spc_id,
                "spc_hash": spc_hash,
                "window": w,
                "ts_utc": _utc_now_iso(),
            },
        )

    # NOTE:
    # SPC execution is intentionally not performed here.


# ----------------------------------------------------------------------
# ✅ Engine-owned registration
# ----------------------------------------------------------------------

register_activity(
    name="control.invoke_window_spc",
    fn=control_invoke_window_spc,
    kind="control",
    notes="Compute and validate SPC windows and log invocation intent",
)
