# ===========================================================================
# File Path : alkali1/pc/engine/activities/io_load_file_folder.py
# File Name : io_load_file_folder.py
# Version   : v2.4.4 (PATCH: deterministic coercion + resilient per-file execution)
# ===========================================================================
# -*- coding: utf-8 -*-

"""
io.load_file_folder — L1 Ingestion Orchestrator (BUILT-IN)

What this activity does
-----------------------
- Discovers files under a Fabric Lakehouse Files folder
- Uses a control table to record STARTED/SUCCEEDED/FAILED for each file
- Dispatches exactly ONE L0 file loader per file (e.g., "csv" -> CsvFileLoader)

Why this patch (v2.4.3)
-----------------------
Your PC step uses params.src_folder_path (not params.folder_path), and your L0 loader
(CsvFileLoader) expects ctx["datastores"] with FLAT identity keys:
  ws_id, ws_name, ds_id, ds_name
but the engine/env often provides nested shape:
  ds["workspace"]["ws_name"], ds["datastore"]["ds_name"]
This patch:
1) Accepts src_folder_path as synonym for folder_path
2) Ensures ctx["datastores"] exists AND flattens each datastore entry for loader compatibility

Playbook v1.0.2 compliance
--------------------------
- Engine kw-call signature: fn(spark=..., ctx=..., params=..., logger=..., **_ignored)
- Max-safe params handling: NEVER use ctx.setdefault("params", ...)
- Output Contract v1.0.0: returns {"df": <DataFrame|None>, "result": {...}}
"""

from __future__ import annotations

from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import json

from pyspark.sql import Row, DataFrame
from pyspark.sql.types import StructType, StructField, StringType, LongType, IntegerType

from alkali1.pc.engine.activity_registry import register_activity
from alkali1.pc.engine.file_loader_registry import get_file_loader
from alkali1.io.lh import folder_ls
from alkali1.io.fileloadctrl import (
    insert_started,
    insert_succeeded,
    insert_failed,
    get_latest_status_map,
    find_zombies,
)

# =============================================================================
# Module metadata
# =============================================================================
FILE_NAME: str = "io_load_file_folder.py"
FILE_PATH: str = "alkali1/pc/engine/activities/io_load_file_folder.py"
MODULE_VERSION: str = "v2.4.4"

ACTIVITY_NAME: str = "io.load_file_folder"
DESCRIPTION: str = "L1 ingestion orchestrator: discover files, enforce control table, dispatch L0 loader per file."

# =============================================================================
# Output DF schema (per-file execution report)
# =============================================================================
_REPORT_SCHEMA = StructType([
    StructField("src_path", StringType(), True),
    StructField("file", StringType(), True),            # relative Files/... path
    StructField("status", StringType(), True),          # SUCCEEDED / FAILED / SKIPPED
    StructField("rows_written", LongType(), True),
    StructField("attempt", IntegerType(), True),
    StructField("loader_return", StringType(), True),
    StructField("error_type", StringType(), True),
    StructField("error_message", StringType(), True),
])


# =============================================================================
# Helpers
# =============================================================================
def _now() -> datetime:
    return datetime.utcnow()


def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    """
    Max-safe ctx normalization (Playbook v1.0.2):
    - NEVER use setdefault for params.
    - Ensure ctx["params"] is deterministic for this call.
    """
    ctx = ctx or {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _resolve_param(ctx: Dict[str, Any], key: str, default=None):
    """
    Params-first resolution with falsy preservation.
    """
    p = ctx.get("params") or {}
    if isinstance(p, dict) and key in p:
        return p.get(key)
    return ctx.get(key, default)


def _as_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "f", "no", "n", "off"}:
            return False
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid boolean value: {v}")


def _as_int(
    v: Any,
    default: int = 0,
    *,
    min_value: Optional[int] = None,
    max_value: Optional[int] = None,
) -> int:
    if v is None:
        out = default
    else:
        try:
            out = int(v)
        except Exception:
            raise RuntimeError(f"PC_VALIDATION_ERROR: invalid integer value: {v}")

    if min_value is not None and out < min_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: integer below minimum: {out}")
    if max_value is not None and out > max_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: integer above maximum: {out}")
    return out


def _as_float(
    v: Any,
    default: float = 0.0,
    *,
    min_value: Optional[float] = None,
    max_value: Optional[float] = None,
) -> float:
    if v is None:
        out = default
    else:
        try:
            out = float(v)
        except Exception:
            raise RuntimeError(f"PC_VALIDATION_ERROR: invalid float value: {v}")

    if min_value is not None and out < min_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: float below minimum: {out}")
    if max_value is not None and out > max_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: float above maximum: {out}")
    return out


def _flatten_one_ds(alias: str, ds: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure datastore dict has FLAT identity fields:
      ws_id, ws_name, ds_id, ds_name, ds_type, ds_alias
    while keeping nested 'workspace' and 'datastore' blocks.
    """
    ws = ds.get("workspace") if isinstance(ds.get("workspace"), dict) else {}
    dso = ds.get("datastore") if isinstance(ds.get("datastore"), dict) else {}

    flat = dict(ds)  # shallow copy
    flat["ds_alias"] = flat.get("ds_alias") or alias

    # Flat identity fields (prefer existing flat keys; else derive from nested)
    flat["ws_id"] = flat.get("ws_id") or ws.get("ws_id")
    flat["ws_name"] = flat.get("ws_name") or ws.get("ws_name")
    flat["ds_id"] = flat.get("ds_id") or dso.get("ds_id")
    flat["ds_name"] = flat.get("ds_name") or dso.get("ds_name")
    flat["ds_type"] = flat.get("ds_type") or ds.get("ds_type")

    # Preserve nested blocks
    flat["workspace"] = ws or flat.get("workspace")
    flat["datastore"] = dso or flat.get("datastore")

    return flat


def _ensure_datastores_in_ctx(ctx: Dict[str, Any]) -> Dict[str, Any]:
    """
    Ensure ctx["datastores"] exists as dict keyed by alias AND flatten each datastore
    so L0 loaders (e.g., CsvFileLoader) can safely read:
      ds.get("ws_name"), ds.get("ds_name")  (no None -> .replace crashes)
    """
    # Locate container
    raw = ctx.get("datastores")
    if not isinstance(raw, dict):
        env = ctx.get("env") or {}
        env_ds = env.get("datastores") if isinstance(env, dict) else None
        raw = env_ds if isinstance(env_ds, dict) else {}

    # Flatten dict entries
    flat_map: Dict[str, Any] = {}
    for alias, ds in (raw or {}).items():
        if isinstance(ds, dict):
            flat_map[str(alias)] = _flatten_one_ds(str(alias), ds)

    # Bind to top-level (NO setdefault)
    ctx["datastores"] = flat_map
    return flat_map


def _get_datastore_container(ctx: Dict[str, Any]) -> Any:
    """
    Supports ctx["datastores"] or ctx["env"]["datastores"].
    """
    ds = ctx.get("datastores")
    if ds is not None:
        return ds
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None


def _resolve_datastore(ctx: Dict[str, Any], alias: str) -> Dict[str, Any]:
    """
    Resolve datastore by alias; supports dict keyed by alias or legacy list.
    """
    alias = (alias or "").strip()
    if not alias:
        raise RuntimeError("PC_VALIDATION_ERROR: missing datastore alias")

    container = _get_datastore_container(ctx)
    if container is None:
        raise RuntimeError("PC_VALIDATION_ERROR: ctx has no datastores")

    if isinstance(container, dict):
        ds = container.get(alias)
        if isinstance(ds, dict):
            # Ensure this entry is flattened as well
            return _flatten_one_ds(alias, ds)
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{alias}'")

    if isinstance(container, list):
        for ds in container:
            if isinstance(ds, dict) and ds.get("ds_alias") == alias:
                return _flatten_one_ds(alias, ds)

    raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{alias}'")


def _ds_identity(ds: Dict[str, Any]) -> Dict[str, Any]:
    """
    Normalize ds identity for IO helpers (flat keys expected downstream).
    """
    alias = ds.get("ds_alias") or ""
    return _flatten_one_ds(str(alias), ds)


def _abfss_to_files(abfss_path: str) -> str:
    """
    Convert ABFSS path containing /Files/... into relative Files/... path.
    """
    s = str(abfss_path or "")
    idx = s.find("/Files/")
    if idx < 0:
        raise RuntimeError(f"PC_VALIDATION_ERROR: invalid Files ABFSS path: {s}")
    return "Files/" + s[idx + len("/Files/"):]


def _normalize_folder_path(folder: str) -> str:
    """
    Normalize folder input into a relative 'Files/<...>' folder for lh.folder_ls.
    Accepts '/Files/..', 'Files/..', 'path:/Files/..', or 'landing/csv' (-> Files/landing/csv).
    """
    s = (folder or "").replace("\\", "/").strip()
    if s.lower().startswith("path:"):
        s = s[5:]
    s = s.lstrip("/")

    if s.startswith("Files/"):
        return s
    if s.lower().startswith("files/"):
        return "Files/" + s.split("/", 1)[1]
    return "Files/" + s


def _matches_file_format(file_path: str, file_format: str) -> bool:
    """
    Return True when a file path matches the requested logical file format.
    Unknown formats are treated as pass-through to avoid accidental drops.
    """
    p = str(file_path or "").strip().lower()
    fmt = str(file_format or "").strip().lower().lstrip(".")

    if not p or not fmt:
        return True

    ext_map = {
        "csv": [".csv"],
        "json": [".json"],
        "xml": [".xml"],
        "parquet": [".parquet"],
        "avro": [".avro"],
        "orc": [".orc"],
        "txt": [".txt"],
        "text": [".txt", ".text"],
        "tsv": [".tsv"],
    }

    exts = ext_map.get(fmt)
    if not exts:
        return True
    return any(p.endswith(ext) for ext in exts)


def _to_int_or_none(v: Any) -> Optional[int]:
    if v is None:
        return None
    try:
        return int(v)
    except Exception:
        return None


def _normalize_loader_result(loader_result: Any) -> Dict[str, Any]:
    """
    Ensure common count fields exist for control-table writes.
    Supports loaders that only return rows_written.
    """
    out: Dict[str, Any] = dict(loader_result) if isinstance(loader_result, dict) else {}

    # Processed row count fallback chain
    processed = (
        _to_int_or_none(out.get("record_count_processed"))
        or _to_int_or_none(out.get("rows_written"))
        or _to_int_or_none(out.get("written_row_count"))
        or _to_int_or_none(out.get("row_count"))
        or _to_int_or_none(out.get("rows_processed"))
    )

    # Source row count fallback chain
    src_count = (
        _to_int_or_none(out.get("src_record_count"))
        or _to_int_or_none(out.get("source_record_count"))
        or _to_int_or_none(out.get("input_record_count"))
        or _to_int_or_none(out.get("rows_read"))
        or processed
    )

    # Failed count fallback chain
    failed = (
        _to_int_or_none(out.get("failed_count"))
        or _to_int_or_none(out.get("error_count"))
        or _to_int_or_none(out.get("rejected_count"))
    )
    if failed is None and processed is not None:
        failed = 0

    if src_count is not None and out.get("src_record_count") is None:
        out["src_record_count"] = src_count
    if processed is not None and out.get("record_count_processed") is None:
        out["record_count_processed"] = processed
    if failed is not None and out.get("failed_count") is None:
        out["failed_count"] = failed

    return out


def _invoke_loader_with_retry(
    *,
    loader,
    file: str,
    ctx: Dict[str, Any],
    params: Dict[str, Any],
    datastore: Dict[str, Any],
    logger,
    l1_retry_number: int,
    l1_retry_sleep_sec: float,
) -> Tuple[Optional[Dict[str, Any]], Optional[Exception], int]:
    """
    Invoke loader with simple L1 retry; returns (result, error, attempt_count).
    """
    attempt = 0
    while True:
        attempt += 1
        try:
            res = loader.load(file=file, ctx=ctx, params=params, datastore=datastore)
            return res, None, attempt
        except Exception as e:
            if attempt > l1_retry_number:
                return None, e, attempt
            if logger:
                logger.warning(f"{ACTIVITY_NAME}: retrying file='{file}' attempt={attempt} error='{e}'")
            time.sleep(l1_retry_sleep_sec)


# =============================================================================
# Activity implementation
# =============================================================================
def io_load_file_folder(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Built-in activity: io.load_file_folder

    Output Contract v1.0.0:
      {"df": <DataFrame|None>, "result": {...}}
    """
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    spark = ctx.get("spark")
    logger = ctx.get("logger")
    p = ctx.get("params") or {}

    if spark is None:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "error_type": "ENGINE_ERROR",
                "error_message": "spark not provided",
            },
        }

    try:
        # Ensure ctx["datastores"] exists AND is flattened for loader compatibility
        datastores = _ensure_datastores_in_ctx(ctx)
        if not isinstance(datastores, dict) or not datastores:
            raise RuntimeError("PC_VALIDATION_ERROR: ctx has no datastores for loader execution")

        # Required: source datastore alias (step-level in your PC)
        src_ds_alias = _resolve_param(ctx, "src_ds") or _resolve_param(ctx, "ds_alias") or _resolve_param(ctx, "ds")
        if not src_ds_alias:
            raise RuntimeError("PC_VALIDATION_ERROR: io.load_file_folder requires src_ds (or ds_alias/ds)")

        # Folder path: accept synonyms used by your PC
        folder_path = (
            _resolve_param(ctx, "folder_path")
            or _resolve_param(ctx, "src_folder_path")  # <-- your PC uses this
            or _resolve_param(ctx, "src_folder")       # optional synonym
            or _resolve_param(ctx, "object")
        )
        if not folder_path:
            raise RuntimeError(
                "PC_VALIDATION_ERROR: io.load_file_folder requires folder_path "
                "(or src_folder_path / object)"
            )

        # File format: your PC uses step-level src_file_format
        file_format = (
            _resolve_param(ctx, "file_format")
            or _resolve_param(ctx, "src_file_format")
            or _resolve_param(ctx, "format")
        )
        if not file_format:
            raise RuntimeError("PC_VALIDATION_ERROR: io.load_file_folder requires file_format (or src_file_format)")
        file_format = str(file_format).strip().lower()

        tgt_src_file_col = _resolve_param(ctx, "tgt_src_file_col")
        if tgt_src_file_col is not None:
            if not isinstance(tgt_src_file_col, str) or not tgt_src_file_col.strip():
                raise RuntimeError("PC_VALIDATION_ERROR: tgt_src_file_col must be a non-empty string when provided")
            tgt_src_file_col = tgt_src_file_col.strip()

        # Control table location (step-level in your PC)
        ctrl_ds_alias = _resolve_param(ctx, "ctrl_ds") or _resolve_param(ctx, "control_ds") or _resolve_param(ctx, "fileloadctrl_ds")
        ctrl_schema = _resolve_param(ctx, "ctrl_schema", "dbo") or "dbo"
        ctrl_table = _resolve_param(ctx, "ctrl_table", "file_load_ctrl") or "file_load_ctrl"
        if not ctrl_ds_alias:
            raise RuntimeError("PC_VALIDATION_ERROR: io.load_file_folder requires ctrl_ds (control table datastore alias)")

        # Concurrency / behavior (your PC uses parallel_limit)
        parallelism = _as_int(
            _resolve_param(ctx, "parallelism", None) or _resolve_param(ctx, "parallel_limit", None),
            default=0,
            min_value=0,
        )
        reload_succeeded_f = _as_bool(_resolve_param(ctx, "reload_succeeded_f", False), default=False)
        l1_retry_number = _as_int(_resolve_param(ctx, "l1_retry_number", 0), default=0, min_value=0)
        l1_retry_sleep_sec = _as_float(_resolve_param(ctx, "l1_retry_sleep_sec", 0.5), default=0.5, min_value=0.0)

        zombie_gap_raw = _resolve_param(ctx, "zombie_gap_min")
        zombie_gap_min = _as_int(zombie_gap_raw, min_value=1) if zombie_gap_raw is not None else None

        # Resolve datastores (flattened)
        src_ds = _resolve_datastore(ctx, str(src_ds_alias))
        ctrl_ds = _resolve_datastore(ctx, str(ctrl_ds_alias))
        src_ident = _ds_identity(src_ds)
        ctrl_ident = _ds_identity(ctrl_ds)

        if not src_ident.get("ws_id") or not src_ident.get("ds_id"):
            raise RuntimeError(f"PC_VALIDATION_ERROR: src_ds '{src_ds_alias}' missing ws_id/ds_id")
        if not ctrl_ident.get("ws_id") or not ctrl_ident.get("ds_id"):
            raise RuntimeError(f"PC_VALIDATION_ERROR: ctrl_ds '{ctrl_ds_alias}' missing ws_id/ds_id")

        # Optional zombie scan
        if zombie_gap_min is not None:
            try:
                zombies = find_zombies(
                    spark=spark,
                    ctrl_ds=ctrl_ident,
                    ctrl_schema=ctrl_schema,
                    ctrl_table=ctrl_table,
                    min_gap_min=zombie_gap_min,
                    logger=logger,
                )
                if logger and zombies:
                    logger.warning(f"{ACTIVITY_NAME}: zombies detected count={len(zombies)} min_gap_min={zombie_gap_min}")
            except Exception as e:
                if logger:
                    logger.warning(f"{ACTIVITY_NAME}: zombie scan failed (ignored): {e}")

        # Discover files
        rel_folder = _normalize_folder_path(str(folder_path))
        if logger:
            logger.info(
                f"{ACTIVITY_NAME}: listing folder='{rel_folder}' "
                f"(src_ds={src_ds_alias}, ws_id={src_ident.get('ws_id')}, ds_id={src_ident.get('ds_id')}, format={file_format})"
            )

        entries = folder_ls(
            ws_id=src_ident.get("ws_id"),
            ws_name=src_ident.get("ws_name"),
            ds_id=src_ident.get("ds_id"),
            ds_name=src_ident.get("ds_name"),
            relative_folder=rel_folder,
            logger=logger,
        )

        files_all: List[str] = []
        for e in (entries or []):
            if not isinstance(e, dict):
                continue
            path = e.get("path")
            if not path:
                continue
            try:
                files_all.append(_abfss_to_files(str(path)))
            except Exception:
                s = str(path).replace("\\", "/").lstrip("/")
                if s.lower().startswith("files/"):
                    s = "Files/" + s.split("/", 1)[1]
                if s.startswith("Files/"):
                    files_all.append(s)

        files = [f for f in files_all if _matches_file_format(f, file_format)]
        filtered_out_count = len(files_all) - len(files)
        if logger and filtered_out_count > 0:
            logger.info(
                f"{ACTIVITY_NAME}: filtered out {filtered_out_count} file(s) not matching format='{file_format}'"
            )

        # Latest status map (skip logic)
        latest_map = {}
        if files:
            try:
                latest_map = get_latest_status_map(
                    spark=spark,
                    ctrl_ds=ctrl_ident,
                    ctrl_schema=ctrl_schema,
                    ctrl_table=ctrl_table,
                    src_paths=files,
                    logger=logger,
                ) or {}
            except Exception as e:
                if logger:
                    logger.warning(f"{ACTIVITY_NAME}: get_latest_status_map failed (ignored): {e}")

        loader = get_file_loader(file_format)
        if loader is None:
            raise RuntimeError(f"PC_VALIDATION_ERROR: no file loader registered for format '{file_format}'")

        def _process_one(file_path: str) -> Row:
            try:
                last = latest_map.get(file_path) if isinstance(latest_map, dict) else None
                last_status = last.get("load_status") if isinstance(last, dict) else None

                if (last_status == "SUCCEEDED") and (not reload_succeeded_f):
                    return Row(
                        src_path=file_path,
                        file=file_path,
                        status="SKIPPED",
                        rows_written=None,
                        attempt=0,
                        loader_return=None,
                        error_type=None,
                        error_message=None,
                    )

                insert_started(
                    spark=spark,
                    ctrl_ds=ctrl_ident,
                    ctrl_schema=ctrl_schema,
                    ctrl_table=ctrl_table,
                    row={"src_path": file_path, "loader": str(file_format)},
                    logger=logger,
                )

                loader_result, err, attempt = _invoke_loader_with_retry(
                    loader=loader,
                    file=file_path,
                    ctx=ctx,            # includes flattened ctx["datastores"]
                    params={
                        **p,
                        **({"tgt_src_file_col": tgt_src_file_col} if tgt_src_file_col else {}),
                    },
                    datastore=src_ident,
                    logger=logger,
                    l1_retry_number=l1_retry_number,
                    l1_retry_sleep_sec=l1_retry_sleep_sec,
                )

                if err is None:
                    normalized_loader_result = _normalize_loader_result(loader_result)

                    insert_succeeded(
                        spark=spark,
                        ctrl_ds=ctrl_ident,
                        ctrl_schema=ctrl_schema,
                        ctrl_table=ctrl_table,
                        row={"src_path": file_path, "loader": str(file_format)},
                        loader_result=normalized_loader_result,
                        logger=logger,
                    )

                    rows_written = None
                    loader_return = None
                    if isinstance(normalized_loader_result, dict):
                        for k in ("rows_written", "written_row_count", "row_count"):
                            if normalized_loader_result.get(k) is not None:
                                try:
                                    rows_written = int(normalized_loader_result.get(k))
                                except Exception:
                                    rows_written = None
                                break
                        try:
                            loader_return = json.dumps(normalized_loader_result, default=str, ensure_ascii=False)
                        except Exception:
                            loader_return = str(normalized_loader_result)
                    elif normalized_loader_result is not None:
                        loader_return = str(normalized_loader_result)

                    return Row(
                        src_path=file_path,
                        file=file_path,
                        status="SUCCEEDED",
                        rows_written=rows_written,
                        attempt=int(attempt),
                        loader_return=loader_return,
                        error_type=None,
                        error_message=None,
                    )

                insert_failed(
                    spark=spark,
                    ctrl_ds=ctrl_ident,
                    ctrl_schema=ctrl_schema,
                    ctrl_table=ctrl_table,
                    row={"src_path": file_path, "loader": str(file_format)},
                    error=str(err),
                    logger=logger,
                )
                return Row(
                    src_path=file_path,
                    file=file_path,
                    status="FAILED",
                    rows_written=None,
                    attempt=int(attempt),
                    loader_return=None,
                    error_type=type(err).__name__,
                    error_message=str(err),
                )
            except Exception as e:
                # Keep batch resilient: one unexpected file-level error should not abort all files.
                try:
                    insert_failed(
                        spark=spark,
                        ctrl_ds=ctrl_ident,
                        ctrl_schema=ctrl_schema,
                        ctrl_table=ctrl_table,
                        row={"src_path": file_path, "loader": str(file_format)},
                        error=str(e),
                        logger=logger,
                    )
                except Exception:
                    pass

                return Row(
                    src_path=file_path,
                    file=file_path,
                    status="FAILED",
                    rows_written=None,
                    attempt=0,
                    loader_return=None,
                    error_type=type(e).__name__,
                    error_message=str(e),
                )

        # Execute
        rows: List[Row] = []
        if not files:
            df0 = spark.createDataFrame([], schema=_REPORT_SCHEMA)
            return {
                "df": df0,
                "result": {
                    "status": "SUCCEEDED",
                    "file_count": 0,
                    "succeeded": 0,
                    "failed": 0,
                    "skipped": 0,
                    "parallelism": parallelism,
                    "src_ds": str(src_ds_alias),
                    "ctrl_ds": str(ctrl_ds_alias),
                    "src_folder_path": str(folder_path),
                    "file_format": str(file_format),
                },
            }

        if parallelism <= 1:
            for f in files:
                rows.append(_process_one(f))
        else:
            with ThreadPoolExecutor(max_workers=parallelism) as ex:
                futures = [ex.submit(_process_one, f) for f in files]
                for fut in as_completed(futures):
                    rows.append(fut.result())

        df: DataFrame = spark.createDataFrame(rows, schema=_REPORT_SCHEMA)

        succeeded = sum(1 for r in rows if getattr(r, "status", None) == "SUCCEEDED")
        failed = sum(1 for r in rows if getattr(r, "status", None) == "FAILED")
        skipped = sum(1 for r in rows if getattr(r, "status", None) == "SKIPPED")
        overall_status = "SUCCEEDED" if failed == 0 else "FAILED"

        loader_result_example = None
        for r in rows:
            if getattr(r, "status", None) == "SUCCEEDED" and getattr(r, "loader_return", None):
                loader_result_example = getattr(r, "loader_return")
                break

        return {
            "df": df,
            "result": {
                "status": overall_status,
                "file_count": len(files),
                "succeeded": succeeded,
                "failed": failed,
                "skipped": skipped,
                "parallelism": parallelism,
                "src_ds": str(src_ds_alias),
                "ctrl_ds": str(ctrl_ds_alias),
                "src_folder_path": str(folder_path),
                "file_format": str(file_format),
                "tgt_src_file_col": tgt_src_file_col,
                "loader_result_example": loader_result_example,
            },
        }

    except Exception as e:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "error_message": str(e),
                "error_type": type(e).__name__,
            },
        }


# =============================================================================
# Registration (ENGINE REQUIRED, import-time; notebook-safe re-import)
# =============================================================================
register_activity(
    name=ACTIVITY_NAME,
    fn=io_load_file_folder,
    kind="io",
    notes=DESCRIPTION,
)
