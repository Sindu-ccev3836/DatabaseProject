# -*- coding: utf-8 -*-
# ===========================================================================
# File Path : alkali1/pc/engine/activities/io_file.py
# Version   : v1.0.2 (MAX-SAFE ctx normalization + deterministic coercion)
# ===========================================================================

"""
===============================================================================
ALKALI BUILT-IN ACTIVITY AI CONTRACT — IO FILE (ENGINE-ACCURATE)
===============================================================================

This module implements a BUILT-IN Alkali IO activity.

-------------------------------------------------------------------------------
ENGINE NORMALIZATION TRUTH (READ THIS)
-------------------------------------------------------------------------------
The Alkali engine invokes activities as:
  fn(spark=..., ctx=..., params=..., logger=...)

The engine MAY normalize authoring-time fields into ctx["params"].

CRITICAL ENGINE COMPATIBILITY RULE
----------------------------------
Activities MUST NOT use ctx.setdefault("params", params) because ctx is shared
across steps within a pipeline. Using setdefault causes stale params from a
previous step (e.g., debug.display_result) to leak into subsequent activities,
making behavior depend on step order.

Therefore, activities MUST overwrite:
  ctx["params"] = params
  ctx["spark"]  = spark
  ctx["logger"] = logger
when those are provided.

(This patch fixes the exact setdefault bug present in the prior io_file.py.) [1](https://nusu-my.sharepoint.com/personal/ccezr_nus_edu_sg/Documents/Microsoft%20Copilot%20Chat%20Files/io_file.py)

-------------------------------------------------------------------------------
OUTPUT CONTRACT (v1.0.0)
-------------------------------------------------------------------------------
All activities MUST return:
{
  "df": <Spark DataFrame | None>,
  "result": {
     "status": "SUCCEEDED" | "FAILED",
     ...
  }
}

-------------------------------------------------------------------------------
ACTIVITY: io.append_file_timestamp
-------------------------------------------------------------------------------
Purpose
-------
Append a timestamp suffix (yyyyMMddHHmmss) to file names in a folder.

Inputs (params)
---------------
- ds_alias: str (required)
- folder_path OR object: str (required) e.g. "/Files/test/csv"
- recursive: bool (accepted; current logic remains NON-recursive)
- overwrite: bool (default False)
- dry_run: bool (default False)
- utc_offset_hours: int (default 0)

Behavior (preserved)
--------------------
- List the folder (NON-recursive) via mssparkutils.fs.ls(abfss_path)
- Skip directories and files already having suffix _YYYYMMDDHHMMSS
- Compute suffix at now(UTC) + utc_offset_hours
- Rename via fs.mv; if overwrite and dst exists -> fs.rm(dst) first
- Return DataFrame of ("before appending ts", "afer appending ts")

===============================================================================
"""

from __future__ import annotations

import re
from datetime import datetime, timezone, timedelta
from typing import Any, Dict, Optional, List, Tuple

from pyspark.sql import DataFrame
from pyspark.sql.types import StructType, StructField, StringType
from notebookutils import mssparkutils

from alkali1.pc.engine.activity_registry import register_activity


# =============================================================================
# Schema
# =============================================================================

_APPEND_TS_SCHEMA = StructType([
    StructField("before appending ts", StringType(), True),
    StructField("afer appending ts", StringType(), True),
])

_SUFFIX_RE = re.compile(r"_(\d{14})$")


# =============================================================================
# Engine-call compatibility helpers
# =============================================================================

def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    """
    Max-safety ctx normalization for engine-style calls.

    Precedence for params:
      1) incoming params kwarg (if not None)
      2) ctx["act"]["params"] when available
      3) existing ctx["params"] if it is already a dict
      4) {}
    """
    if ctx is None:
        ctx = {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _as_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "f", "no", "n", "off"}:
            return False
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid boolean value: {v}")


def _as_int(
    v: Any,
    default: int = 0,
    *,
    min_value: Optional[int] = None,
    max_value: Optional[int] = None,
) -> int:
    if v is None:
        out = default
    else:
        try:
            out = int(v)
        except Exception:
            raise RuntimeError(f"PC_VALIDATION_ERROR: invalid integer value: {v}")

    if min_value is not None and out < min_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: integer below minimum: {out}")
    if max_value is not None and out > max_value:
        raise RuntimeError(f"PC_VALIDATION_ERROR: integer above maximum: {out}")
    return out


def _resolve_param(ctx: Dict[str, Any], key: str, default=None):
    """
    Resolve parameter from ctx["params"] first, then ctx top-level.
    Preserves falsy values.
    """
    p = ctx.get("params") or {}
    if isinstance(p, dict) and key in p:
        return p.get(key)
    return ctx.get(key, default)


# =============================================================================
# Datastore resolution (supports dict keyed by alias; tolerates legacy list)
# =============================================================================

def _get_datastore_container(ctx: Dict[str, Any]) -> Any:
    ds_container = ctx.get("datastores")
    if ds_container:
        return ds_container
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None


def _resolve_datastore(ctx: Dict[str, Any], ds_alias: str) -> Dict[str, Any]:
    ds_alias = (ds_alias or "").strip()
    if not ds_alias:
        raise RuntimeError("PC_VALIDATION_ERROR: missing ds_alias")

    container = _get_datastore_container(ctx)
    if container is None:
        raise RuntimeError("PC_VALIDATION_ERROR: ctx missing datastores (or env.datastores)")

    # New: dict keyed by alias
    if isinstance(container, dict):
        ds = container.get(ds_alias)
        if isinstance(ds, dict):
            return ds
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    # Tolerate legacy: list of dicts
    if isinstance(container, list):
        for item in container:
            if not isinstance(item, dict):
                continue
            if (item.get("ds_alias") or item.get("alias") or "").strip() == ds_alias:
                return item
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    raise RuntimeError("PC_VALIDATION_ERROR: unsupported datastores container shape")


def _pick_first(d: Dict[str, Any], *keys: str):
    for k in keys:
        if k in d and d.get(k) is not None:
            return d.get(k)
    return None


def _datastore_identity(ds: Dict[str, Any]) -> Dict[str, Any]:
    """
    Returns {"ws_id","ws_name","ds_id","ds_name","ds_type"}.
    Supports nested and flat shapes.
    """
    ws = ds.get("workspace") if isinstance(ds.get("workspace"), dict) else {}
    dso = ds.get("datastore") if isinstance(ds.get("datastore"), dict) else {}

    ws_id = _pick_first(ws, "ws_id", "id") or ds.get("ws_id")
    ws_name = _pick_first(ws, "ws_name", "name") or ds.get("ws_name")

    ds_id = _pick_first(dso, "ds_id", "id") or ds.get("ds_id")
    ds_name = _pick_first(dso, "ds_name", "name") or ds.get("ds_name")

    ds_type = (
        _pick_first(dso, "ds_type", "type")
        or ds.get("ds_type")
        or ds.get("type")
        or ds.get("datastore_type")
    )

    return {
        "ws_id": ws_id,
        "ws_name": ws_name,
        "ds_id": ds_id,
        "ds_name": ds_name,
        "ds_type": ds_type,
    }


# =============================================================================
# Activity-specific helpers (logic preserved)
# =============================================================================

def _get_ds_alias(ctx: Dict[str, Any]) -> str:
    """
    Resolve ds_alias from params first; tolerate common synonyms.
    """
    act = ctx.get("act") or {}
    params = ctx.get("params") or {}

    ds_alias = (
        (params.get("ds_alias") if isinstance(params, dict) else None)
        or act.get("ds_alias")
        or act.get("datastore")
        or act.get("data_layer")
        or (params.get("datastore") if isinstance(params, dict) else None)
        or (params.get("data_layer") if isinstance(params, dict) else None)
    )

    if not isinstance(ds_alias, str) or not ds_alias.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing ds_alias")

    return ds_alias.strip()


def _get_folder_path(ctx: Dict[str, Any]) -> str:
    """
    Resolve folder path from params.folder_path OR params.object OR act.object.
    """
    act = ctx.get("act") or {}
    params = ctx.get("params") or {}

    folder_path = None
    if isinstance(params, dict):
        folder_path = params.get("folder_path") or params.get("object")
    if not folder_path:
        folder_path = act.get("object")

    if not isinstance(folder_path, str) or not folder_path.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing folder_path (or object)")

    return folder_path.strip()


def _to_relative_files_path(p: str) -> str:
    """
    Normalize input to 'Files/<...>' relative path.
    Accepts:
      - "/Files/..", "Files/..", "path:/Files/.."
    """
    s = (p or "").replace("\\", "/")
    if s.lower().startswith("path:"):
        s = s[5:]
    s = s.lstrip("/")
    if s.startswith("Files/"):
        return s
    if s.lower().startswith("files/"):
        return "Files/" + s.split("/", 1)[1]
    return "Files/" + s


def _build_files_abfss_path(ws_id: str, ds_id: str, relative_path: str) -> str:
    """
    Build OneLake ID-based ABFSS path:
      abfss://<ws_id>@onelake.dfs.fabric.microsoft.com/<ds_id>/<relative_path>
    """
    rp = (relative_path or "").lstrip("/").replace("\\", "/")
    return f"abfss://{ws_id}@onelake.dfs.fabric.microsoft.com/{ds_id}/{rp}"


def _split_name_ext(n: str) -> Tuple[str, str]:
    i = n.rfind(".")
    return (n, "") if i <= 0 else (n[:i], n[i:])


def _already_has_suffix(filename: str) -> bool:
    base, _ = _split_name_ext(filename)
    return bool(_SUFFIX_RE.search(base))


def _rename_file(src_path: str, dst_path: str, *, overwrite: bool) -> None:
    fs = mssparkutils.fs
    if overwrite and fs.exists(dst_path):
        fs.rm(dst_path)
    fs.mv(src_path, dst_path)


# =============================================================================
# Built-in activity: io.append_file_timestamp
# =============================================================================

def io_append_file_timestamp(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Append a timestamp suffix to files in a folder (NON-recursive listing).
    Returns Output Contract v1.0.0: {"df": ..., "result": ...}.
    """
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    spark = ctx.get("spark")
    logger = ctx.get("logger")

    if spark is None:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "error_type": "ENGINE_ERROR",
                "error_message": "spark not provided to io.append_file_timestamp",
            },
        }

    try:
        ds_alias = _get_ds_alias(ctx)
        ds = _resolve_datastore(ctx, ds_alias)
        ident = _datastore_identity(ds)

        ws_id = ident.get("ws_id")
        ds_id = ident.get("ds_id")
        if not ws_id or not ds_id:
            raise RuntimeError(f"PC_VALIDATION_ERROR: datastore '{ds_alias}' missing ws_id/ds_id")

        folder_path = _get_folder_path(ctx)
        folder_abfss = _build_files_abfss_path(ws_id, ds_id, _to_relative_files_path(folder_path))

        overwrite = _as_bool(_resolve_param(ctx, "overwrite", False), default=False)
        dry_run = _as_bool(_resolve_param(ctx, "dry_run", False), default=False)
        utc_offset = _as_int(_resolve_param(ctx, "utc_offset_hours", 0), default=0)
        recursive = _as_bool(_resolve_param(ctx, "recursive", False), default=False)  # accepted; unchanged behavior

        rows: List[Tuple[str, str]] = []

        for e in mssparkutils.fs.ls(folder_abfss):
            if getattr(e, "isDir", False) or _already_has_suffix(getattr(e, "name", "")):
                continue

            ts = datetime.now(timezone.utc) + timedelta(hours=utc_offset)
            suffix = ts.strftime("%Y%m%d%H%M%S")

            base, ext = _split_name_ext(e.name)
            dst = f"{e.path.rsplit('/', 1)[0]}/{base}_{suffix}{ext}"
            after_name = f"{base}_{suffix}{ext}"

            if not dry_run:
                _rename_file(e.path, dst, overwrite=overwrite)

            rows.append((e.name, after_name))

        df: DataFrame = spark.createDataFrame(rows, _APPEND_TS_SCHEMA) if rows else spark.createDataFrame([], _APPEND_TS_SCHEMA)

        return {
            "df": df,
            "result": {
                "status": "SUCCEEDED",
                "ds_alias": ds_alias,
                "identity": ident,
                "folder_path": folder_path,
                "folder_abfss": folder_abfss,
                "recursive": recursive,
                "overwrite": overwrite,
                "dry_run": dry_run,
                "utc_offset_hours": utc_offset,
                "renamed_count": len(rows),
            },
        }

    except Exception as e:
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "error_message": str(e),
                "error_type": type(e).__name__,
            },
        }


# =============================================================================
# Registration (ENGINE REQUIRED)
# =============================================================================

register_activity(
    name="io.append_file_timestamp",
    fn=io_append_file_timestamp,
    kind="io",
    notes="Append timestamp suffix to files in Fabric Lakehouse Files (PATCH: overwrite ctx['params'] to avoid stale params bleed)",
)
