# alkalipc/pc/engines/engine_v1_0_0/activities/__init__.py
"""
Activity autoloader for engine_v1_0_0.

Importing this package MUST register all activities belonging
to this engine via @register_activity decorators.

This file is intentionally import-side-effect driven.
"""

import pkgutil
import importlib

# Automatically import all modules under this package
# so that @register_activity decorators execute.
for module_info in pkgutil.iter_modules(__path__):
    module_name = module_info.name
    importlib.import_module(f"{__name__}.{module_name}")