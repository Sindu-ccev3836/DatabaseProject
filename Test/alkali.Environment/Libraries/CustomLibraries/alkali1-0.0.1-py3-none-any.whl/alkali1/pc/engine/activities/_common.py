# File: alkali1/pc/engine/activities/_common.py
# -*- coding: utf-8 -*-

"""
Common helpers for Alkali1 activities.

Scope:
- Identity inheritance helpers
- Window filtering helpers
- Files path normalization

IMPORTANT:
- NO logging helpers here
- NO Lakehouse IO
- NO side effects
- Logging MUST use alkali1.common.logger directly
"""

from __future__ import annotations

import datetime as _dt
from typing import Any, Dict, Optional, Tuple

from pyspark.sql import DataFrame
from pyspark.sql import functions as F


# ---------------------------------------------------------------------------
# Identity inheritance helpers
# ---------------------------------------------------------------------------

_SRC_KEYS = [
    "src_ws_name",
    "src_ws_id",
    "src_ds_type",
    "src_ds_name",
    "src_ds_id",
]

_TGT_KEYS = [
    "tgt_ws_name",
    "tgt_ws_id",
    "tgt_ds_type",
    "tgt_ds_name",
    "tgt_ds_id",
]


def _coalesce(*vals):
    for v in vals:
        if v is not None:
            return v
    return None


def inherit_identity(
    *,
    direction: str,  # "src" | "tgt"
    batch_defaults: Dict[str, Any],
    pipeline_overrides: Dict[str, Any],
    activity_overrides: Dict[str, Any],
    target_overrides: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """
    Resolution precedence:
    Activity → Target → Pipeline → Batch defaults
    """
    keys = _SRC_KEYS if direction == "src" else _TGT_KEYS
    out: Dict[str, Any] = {}

    for k in keys:
        out[k] = _coalesce(
            (activity_overrides or {}).get(k),
            (target_overrides or {}).get(k) if target_overrides else None,
            (pipeline_overrides or {}).get(k),
            (batch_defaults or {}).get(k),
        )

    return out


def require_identity(identity: Dict[str, Any], direction: str) -> None:
    """
    Enforce minimal identity requirements.
    """
    ws_id = identity.get(f"{direction}_ws_id")
    ds_id = identity.get(f"{direction}_ds_id")

    if not ws_id or not ds_id:
        raise RuntimeError(
            f"IDENTITY_ERROR: {direction} ws_id and ds_id are required"
        )


# ---------------------------------------------------------------------------
# Window filter helpers
# ---------------------------------------------------------------------------

def _parse_iso_value(v: Any) -> Tuple[str, Any]:
    """
    Parse ISO-like values into typed Python values.
    Returns (type, value).
    """
    if v is None:
        return ("string", None)

    if isinstance(v, _dt.datetime):
        return ("timestamp", v)

    if isinstance(v, _dt.date):
        return ("date", v)

    if not isinstance(v, str):
        return ("string", v)

    s = v.strip()

    # Try timestamp
    try:
        if "T" in s or ":" in s:
            s2 = s.replace("Z", "+00:00")
            return ("timestamp", _dt.datetime.fromisoformat(s2))
    except Exception:
        pass

    # Try date
    try:
        if len(s) >= 10 and s[4] == "-" and s[7] == "-":
            return ("date", _dt.date.fromisoformat(s[:10]))
    except Exception:
        pass

    return ("string", s)


def apply_window_filter(
    df: DataFrame,
    window: Optional[Dict[str, Any]],
) -> DataFrame:
    """
    Apply window filters to a DataFrame.
    """
    if not window:
        return df

    filters = window.get("filter_columns") or []

    for f in filters:
        col_name = f.get("column_name")
        start_value = f.get("start_value")
        end_value = f.get("end_value")

        if not col_name:
            continue

        _, start_val = _parse_iso_value(start_value)
        _, end_val = _parse_iso_value(end_value)

        if start_val is not None:
            df = df.filter(F.col(col_name) >= start_val)
        if end_val is not None:
            df = df.filter(F.col(col_name) < end_val)

    return df


# ---------------------------------------------------------------------------
# Files path normalization (Lakehouse Files only)
# ---------------------------------------------------------------------------

def normalize_files_relative_path(p: str) -> str:
    """
    Normalize a relative Files path (no leading Files/).
    """
    s = (p or "").strip()
    if not s:
        return s

    s = s.replace("\\", "/")

    if s.startswith("/"):
        s = s[1:]

    if s.lower().startswith("files/"):
        s = s[6:]

    return s
