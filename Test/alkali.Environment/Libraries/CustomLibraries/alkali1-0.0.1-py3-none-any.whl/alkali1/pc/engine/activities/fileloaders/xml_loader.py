# ===========================================================================
# File Path : alkali1/pc/engine/activities/fileloaders/xml_loader.py
# Version   : v1.0.0
# ===========================================================================
# -*- coding: utf-8 -*-

"""
XML File Loader
"""

from __future__ import annotations

from typing import Dict, Any

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from alkali1.pc.engine.file_loader_registry import register_file_loader
from alkali1.io.lh import read_files, write_table


def _log_debug(logger: Any, msg: str) -> None:
	fn = getattr(logger, "debug", None) if logger is not None else None
	if callable(fn):
		fn(msg)


def _to_int_or_none(v: Any) -> int | None:
	if v is None:
		return None
	try:
		return int(v)
	except Exception:
		return None


def _build_loader_counts(result: Dict[str, Any]) -> Dict[str, int | None]:
	processed = (
		_to_int_or_none(result.get("record_count_processed"))
		or _to_int_or_none(result.get("rows_written"))
		or _to_int_or_none(result.get("written_row_count"))
		or _to_int_or_none(result.get("row_count"))
	)
	src_count = _to_int_or_none(result.get("src_record_count")) or processed
	failed = _to_int_or_none(result.get("failed_count"))
	if failed is None and processed is not None:
		failed = 0

	return {
		"src_record_count": src_count,
		"record_count_processed": processed,
		"failed_count": failed,
	}


def _append_src_file_col_last(df: DataFrame, col_name: str, file: str) -> DataFrame:
	col = col_name.strip()
	ordered = [c for c in df.columns if c != col] + [col]
	return df.withColumn(col, F.lit(file)).select(*ordered)


def _as_bool(v: Any, default: bool = False) -> bool:
	if v is None:
		return default
	if isinstance(v, bool):
		return v
	if isinstance(v, (int, float)):
		return bool(v)
	if isinstance(v, str):
		s = v.strip().lower()
		if s in {"1", "true", "t", "yes", "y", "on"}:
			return True
		if s in {"0", "false", "f", "no", "n", "off"}:
			return False
	raise RuntimeError(f"PC_VALIDATION_ERROR: invalid boolean value: {v}")


def _as_int(v: Any, default: int = 0, *, min_value: int | None = None) -> int:
	if v is None:
		out = default
	else:
		try:
			out = int(v)
		except Exception:
			raise RuntimeError(f"PC_VALIDATION_ERROR: invalid integer value: {v}")

	if min_value is not None and out < min_value:
		raise RuntimeError(f"PC_VALIDATION_ERROR: integer below minimum: {out}")
	return out


def _resolve_row_tag(params: Dict[str, Any]) -> str:
	"""
	Resolve rowTag for spark-xml.
	Accepts:
	- params.row_tag / params.src_row_tag (preferred)
	- params.rowTag / params.src_rowTag (compat)
	- params.row_tag_path / params.rowTagPath
	- params.src_row_tag_path / params.src_rowTagPath
	  (all path forms use the last path segment)
	"""
	row_tag = (
		params.get("row_tag")
		or params.get("src_row_tag")
		or params.get("rowTag")
		or params.get("src_rowTag")
	)
	if isinstance(row_tag, str) and row_tag.strip():
		return row_tag.strip()

	row_tag_path = (
		params.get("row_tag_path")
		or params.get("src_row_tag_path")
		or params.get("rowTagPath")
		or params.get("src_rowTagPath")
	)
	if isinstance(row_tag_path, str) and row_tag_path.strip():
		leaf = row_tag_path.strip().strip("/").split("/")[-1].strip()
		if leaf:
			return leaf

	raise RuntimeError(
		"PC_VALIDATION_ERROR: xml_loader requires params.row_tag "
		"or params.row_tag_path"
	)


class XmlFileLoader:
	"""
	XML file loader implementation (single-file only).
	"""

	def load(
		self,
		*,
		file: str,
		ctx: Dict[str, Any],
		params: Dict[str, Any],
		datastore: Dict[str, Any],
	) -> Dict[str, Any]:

		spark = ctx["spark"]
		logger = ctx["logger"]
		datastores = ctx["datastores"]
		_log_debug(logger, f"xml_loader.load started file='{file}'")

		# ------------------------------------------------------------------
		# Resolve SOURCE datastore (files)
		# ------------------------------------------------------------------
		src_ws_id = datastore.get("ws_id")
		src_ws_name = datastore.get("ws_name")
		src_ds_id = datastore.get("ds_id")
		src_ds_name = datastore.get("ds_name")

		# ------------------------------------------------------------------
		# Resolve TARGET datastore (tables)
		# ------------------------------------------------------------------
		tgt_alias = params.get("tgt_ds")
		if not tgt_alias:
			raise RuntimeError("xml_loader requires params.tgt_ds")

		tgt_ds = datastores.get(tgt_alias)
		if not tgt_ds:
			raise RuntimeError(f"Unknown target datastore alias: {tgt_alias}")

		tgt_ws_id = tgt_ds.get("ws_id")
		tgt_ws_name = tgt_ds.get("ws_name")
		tgt_ds_id = tgt_ds.get("ds_id")
		tgt_ds_name = tgt_ds.get("ds_name")

		# ------------------------------------------------------------------
		# Read XML file
		# ------------------------------------------------------------------
		row_tag = _resolve_row_tag(params)
		_log_debug(logger, f"xml_loader resolved row_tag='{row_tag}'")

		read_options = {
			"rowTag": row_tag,
			"inferSchema": _as_bool(params.get("src_infer_schema", True), default=True),
			"ignoreNamespace": _as_bool(params.get("src_ignore_namespace", False), default=False),
			"attributePrefix": params.get("src_attribute_prefix", "_"),
			"valueTag": params.get("src_value_tag", "_VALUE"),
			"treatEmptyValuesAsNulls": _as_bool(params.get("src_treat_empty_as_null", True), default=True),
		}

		# Optional passthrough dictionary for extra spark-xml options
		extra_xml_options = params.get("src_xml_options")
		if isinstance(extra_xml_options, dict):
			read_options.update(extra_xml_options)
		_log_debug(logger, f"xml_loader read_options={read_options}")

		df: DataFrame = read_files(
			spark=spark,
			ws_id=src_ws_id,
			ws_name=src_ws_name,
			ds_id=src_ds_id,
			ds_name=src_ds_name,
			relative_path=file,
			fmt="xml",
			options=read_options,
			logger=logger,
		)
		_log_debug(logger, "xml_loader read_files completed")

		tgt_src_file_col = params.get("tgt_src_file_col")
		if isinstance(tgt_src_file_col, str) and tgt_src_file_col.strip():
			df = _append_src_file_col_last(df, tgt_src_file_col, file)
			_log_debug(logger, f"xml_loader appended source file column='{tgt_src_file_col.strip()}'")

		# ------------------------------------------------------------------
		# Target table parameters
		# ------------------------------------------------------------------
		tgt_schema = params.get("tgt_schema")
		tgt_table = params.get("tgt_table")
		tgt_mode = params.get("tgt_mode", "append")

		if not tgt_schema or not tgt_table:
			raise RuntimeError(
				"xml_loader requires params.tgt_schema and params.tgt_table"
			)

		# ------------------------------------------------------------------
		# Write behavior (PC-driven)
		# ------------------------------------------------------------------
		auto_create_table_f = _as_bool(
			params.get("auto_create_table_f", True),
			default=True,
		)

		allow_schema_merge = _as_bool(
			params.get("allow_schema_merge", False),
			default=False,
		)

		retry_number = _as_int(
			params.get("retry_number", 0),
			default=0,
			min_value=0,
		)

		# ------------------------------------------------------------------
		# Schema history (required iff schema merge enabled)
		# ------------------------------------------------------------------
		schema_history_ds_alias = params.get("schema_history_ds")
		schema_history_schema = params.get("schema_history_schema")
		schema_history_table = params.get("schema_history_table")

		schema_history_ds = None

		if allow_schema_merge:
			if not (
				schema_history_ds_alias
				and schema_history_schema
				and schema_history_table
			):
				raise RuntimeError(
					"allow_schema_merge=True requires "
					"schema_history_ds, schema_history_schema, "
					"schema_history_table"
				)

			schema_history_ds = datastores.get(schema_history_ds_alias)
			if not schema_history_ds:
				raise RuntimeError(
					f"Unknown schema_history_ds alias: {schema_history_ds_alias}"
				)

		# ------------------------------------------------------------------
		# Write table (Fabric Catalog FQN)
		# ------------------------------------------------------------------
		result = write_table(
			spark=spark,
			df=df,
			ws_id=tgt_ws_id,
			ws_name=tgt_ws_name,
			ds_id=tgt_ds_id,
			ds_name=tgt_ds_name,
			schema=tgt_schema,
			table=tgt_table,
			mode=tgt_mode,
			auto_create_table_f=auto_create_table_f,
			allow_schema_merge=allow_schema_merge,
			schema_history_ws_id=schema_history_ds.get("ws_id")
			if schema_history_ds else None,
			schema_history_ws_name=schema_history_ds.get("ws_name")
			if schema_history_ds else None,
			schema_history_ds_id=schema_history_ds.get("ds_id")
			if schema_history_ds else None,
			schema_history_ds_name=schema_history_ds.get("ds_name")
			if schema_history_ds else None,
			schema_history_schema=schema_history_schema,
			schema_history_table=schema_history_table,
			retry_number=retry_number,
			logger=logger,
		)
		_log_debug(logger, f"xml_loader write_table completed result={result}")
		counts = _build_loader_counts(result if isinstance(result, dict) else {})
		_log_debug(logger, f"xml_loader derived counts={counts}")

		return {
			"rows_written": result.get("rows_written"),
			"src_record_count": counts.get("src_record_count"),
			"record_count_processed": counts.get("record_count_processed"),
			"failed_count": counts.get("failed_count"),
			"row_tag": row_tag,
			"auto_create_table_f": auto_create_table_f,
			"allow_schema_merge": allow_schema_merge,
			"retry_number": retry_number,
		}


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------

register_file_loader("xml", XmlFileLoader())
