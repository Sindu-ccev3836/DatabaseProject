# -*- coding: utf-8 -*-
# ===========================================================================
# File Path : alkali1/pc/engine/activities/io_datastore.py
# Version   : v1.3.3 (PATCH: io.read_table supports src_schema/src_table)
# ===========================================================================

"""
Datastore IO activities for Alkali (Fabric Lakehouse / Warehouse).
"""

# ===========================================================================
# 🤖 AI CONTRACT — IO DATASTORE ACTIVITIES (AUTHORITATIVE)
# ===========================================================================
# Version : v1.3.3
# Aligned with:
# - Alkali Activity Output Contract v1.0.0
# - alkali1.io.lh (Fabric FQN enforcement + physical table IO)
#
# ROLE
# ----
# IO datastore activities provide Spark-based access to Fabric Lakehouse /
# Warehouse objects using Alkali IO helpers.
#
# MUST:
# - Use alkali1.io.lh for ALL table IO
# - Resolve datastores via ctx["datastores"] OR ctx["env"]["datastores"]
# - Support datastore container shapes:
#   (a) dict keyed by datastore alias (NEW runtime_param_dict form)
#   (b) list of datastore dicts containing ds_alias (legacy)
# - Support datastore identity shapes:
#   (a) nested:
#       ds["workspace"] = {"ws_id": "...", "ws_name": "..."}
#       ds["datastore"] = {"ds_id": "...", "ds_name": "..."}
#   (b) flat:
#       ds["ws_id"], ds["ws_name"], ds["ds_id"], ds["ds_name"]
# - Accept engine calling convention:
#     activity(spark=..., ctx=..., params=..., logger=...)
#   and tolerate legacy:
#     activity(ctx)
# - Return Output Contract v1.0.0 objects:
#     {"df": <DataFrame|None>, "result": {...}}
#
# ACTIVITY CONTRACTS
# ------------------
# 1) io.read_table
#   Inputs (datastore):
#     ds / src_ds / datastore / ds_alias / tgt_ds
#   Inputs (object):
#     EITHER:
#       object = "schema.table"                     (legacy)
#     OR:
#       src_schema = "schema", src_table = "table"  (new PC form)
#     Also accepted synonyms:
#       schema/table or tgt_schema/tgt_table
#   Behavior:
#     Resolve datastore from ctx["datastores"], resolve schema/table,
#     call alkali1.io.lh.read_table(...)
#   Output:
#     {"df": DataFrame|None, "result": {"status":"SUCCEEDED|FAILED", ...}}
#
# 2) io.write_df
#   Inputs:
#     src_df, tgt_ds, tgt_schema, tgt_table, mode, ...
#   Behavior:
#     Resolve identities from ctx["datastores"], call alkali1.io.lh.write_table(...)
#   Output:
#     {"df": None, "result": {"status":"SUCCEEDED|FAILED", ...}}
# ===========================================================================

from __future__ import annotations

import inspect
import json
from typing import Any, Dict, Optional, Tuple

from pyspark.sql import DataFrame

from alkali1.pc.engine.activity_registry import register_activity
from alkali1.io.lh import read_table, write_table


# -----------------------------------------------------------------------------
# Logging helpers (single-string logging; avoids AlkaliLogger extra/format issues)
# -----------------------------------------------------------------------------
def _json_safe(v: Any) -> str:
    try:
        return json.dumps(v, default=str, ensure_ascii=False)
    except Exception:
        return str(v)

def _log_debug(logger, msg: str, **fields: Any) -> None:
    if not logger:
        return
    if fields:
        logger.debug(f"{msg} | {_json_safe(fields)}")
    else:
        logger.debug(str(msg))


def _log_exception(logger, msg: str, **fields: Any) -> None:
    """
    Robust exception logger:
    - Uses logger.exception if available
    - Falls back to logger.error
    - Always logs a SINGLE STRING argument (AlkaliLogger-safe)
    """
    if not logger:
        return

    payload = f"{msg}"
    if fields:
        payload = f"{msg} | {_json_safe(fields)}"

    # Prefer .exception (std logging), else fallback to .error
    fn = getattr(logger, "exception", None)
    if callable(fn):
        fn(str(payload))
        return

    fn = getattr(logger, "error", None)
    if callable(fn):
        fn(str(payload))
        return

    # last resort
    try:
        print(str(payload))
    except Exception:
        pass



# -----------------------------------------------------------------------------
# Engine-call compatibility: build a working ctx
# -----------------------------------------------------------------------------
def _coerce_ctx(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    """
    Engine calls activities like:
      fn(spark=..., ctx=..., params=..., logger=...)
    Legacy may call:
      fn(ctx)
    """
    if ctx is None:
        ctx = {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger
    if params is not None:
        ctx["params"] = params

    # ensure env exists
    env = ctx.get("env")
    if env is None:
        ctx["env"] = {}
    elif not isinstance(env, dict):
        ctx["env"] = {"value": env}

    # mirror datastores from env if needed
    if "datastores" not in ctx:
        env = ctx.get("env") or {}
        if isinstance(env, dict) and isinstance(env.get("datastores"), (dict, list)):
            ctx["datastores"] = env.get("datastores")

    return ctx


# -----------------------------------------------------------------------------
# Parameter helpers
# -----------------------------------------------------------------------------
def _resolve_param(ctx: Dict[str, Any], key: str) -> Any:
    """
    Resolve parameter from ctx["params"] first, then ctx top-level.
    Preserve falsy values (False/0/"").
    """
    params = ctx.get("params") or {}
    if isinstance(params, dict) and key in params:
        return params.get(key)
    return ctx.get(key)

def _pick_first(d: Dict[str, Any], *keys: str) -> Any:
    for k in keys:
        if k in d and d.get(k) is not None:
            return d.get(k)
    return None


# -----------------------------------------------------------------------------
# Datastore resolution (supports NEW nested dict form + legacy list form)
# -----------------------------------------------------------------------------
def _get_datastore_container(ctx: Dict[str, Any]) -> Any:
    ds_container = ctx.get("datastores")
    if ds_container:
        return ds_container
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None

def _resolve_datastore(ctx: Dict[str, Any], ds_alias: str) -> Dict[str, Any]:
    ds_alias = (ds_alias or "").strip()
    if not ds_alias:
        raise RuntimeError("io.* requires a non-empty datastore alias")

    ds_container = _get_datastore_container(ctx)
    if not ds_container:
        raise RuntimeError("No datastores found in ctx['datastores'] or ctx['env']['datastores']")

    # NEW: dict keyed by alias
    if isinstance(ds_container, dict):
        ds = ds_container.get(ds_alias)
        if ds is None:
            raise RuntimeError(f"Unknown datastore alias '{ds_alias}'. Known: {sorted(ds_container.keys())}")
        if not isinstance(ds, dict):
            raise RuntimeError(f"Datastore '{ds_alias}' must be a dict, got {type(ds).__name__}")
        if "ds_alias" not in ds:
            ds = dict(ds)
            ds["ds_alias"] = ds_alias
        return ds

    # OLD: list of dicts
    if isinstance(ds_container, list):
        for ds in ds_container:
            if isinstance(ds, dict) and (ds.get("ds_alias") or ds.get("alias")) == ds_alias:
                if "ds_alias" not in ds:
                    ds = dict(ds)
                    ds["ds_alias"] = ds_alias
                return ds
        raise RuntimeError(f"Unknown datastore alias '{ds_alias}' in list-form datastores")

    raise RuntimeError(f"Unsupported datastores container type: {type(ds_container).__name__}")

def _datastore_identity(ds: Dict[str, Any]) -> Dict[str, Any]:
    """
    Supports NEW nested structure:
      ds["workspace"] = {"ws_id": ..., "ws_name": ...}
      ds["datastore"] = {"ds_id": ..., "ds_name": ...}
    And legacy flat structure:
      ds["ws_id"], ds["ws_name"], ds["ds_id"], ds["ds_name"]
    """
    ws = ds.get("workspace") if isinstance(ds.get("workspace"), dict) else {}
    dso = ds.get("datastore") if isinstance(ds.get("datastore"), dict) else {}

    ws_id = _pick_first(ds, "workspace_id", "ws_id", "workspaceId", "wsId") or _pick_first(ws, "workspace_id", "ws_id", "workspaceId", "wsId")
    ws_name = _pick_first(ds, "workspace_name", "ws_name", "workspaceName", "wsName") or _pick_first(ws, "workspace_name", "ws_name", "workspaceName", "wsName")

    ds_id = _pick_first(ds, "datastore_id", "ds_id", "id", "datastoreId", "dsId") or _pick_first(dso, "datastore_id", "ds_id", "id", "datastoreId", "dsId")
    ds_name = _pick_first(ds, "datastore_name", "ds_name", "name", "datastoreName", "dsName") or _pick_first(dso, "datastore_name", "ds_name", "name", "datastoreName", "dsName")

    return {
        "ds_alias": _pick_first(ds, "ds_alias", "alias"),
        "ws_id": ws_id,
        "ws_name": ws_name,
        "ds_id": ds_id,
        "ds_name": ds_name,
        "ds_type": _pick_first(ds, "ds_type", "type"),
    }


# -----------------------------------------------------------------------------
# Table address parsing (legacy object + new src_schema/src_table)
# -----------------------------------------------------------------------------
def _parse_object(obj: str) -> Tuple[str, str]:
    if not obj or "." not in obj:
        raise RuntimeError("io.read_table params.object must be 'schema.table'")
    schema, table = obj.split(".", 1)
    if not schema or not table:
        raise RuntimeError("io.read_table params.object must be 'schema.table'")
    return schema, table

def _resolve_schema_table(ctx: Dict[str, Any]) -> Tuple[str, str, str]:
    """
    Returns (schema, table, address_mode)
    address_mode ∈ {"object", "schema_table"}
    """
    # 1) Legacy: object = "schema.table"
    obj = _resolve_param(ctx, "object")
    if isinstance(obj, str) and obj.strip():
        schema, table = _parse_object(obj.strip())
        return schema, table, "object"

    # 2) New PC: src_schema + src_table
    src_schema = _resolve_param(ctx, "src_schema")
    src_table = _resolve_param(ctx, "src_table")
    if isinstance(src_schema, str) and src_schema.strip() and isinstance(src_table, str) and src_table.strip():
        return src_schema.strip(), src_table.strip(), "schema_table"

    # 3) Synonyms: schema/table
    schema = _resolve_param(ctx, "schema")
    table = _resolve_param(ctx, "table")
    if isinstance(schema, str) and schema.strip() and isinstance(table, str) and table.strip():
        return schema.strip(), table.strip(), "schema_table"

    # 4) Synonyms: tgt_schema/tgt_table (sometimes reused)
    tgt_schema = _resolve_param(ctx, "tgt_schema")
    tgt_table = _resolve_param(ctx, "tgt_table")
    if isinstance(tgt_schema, str) and tgt_schema.strip() and isinstance(tgt_table, str) and tgt_table.strip():
        return tgt_schema.strip(), tgt_table.strip(), "schema_table"

    raise RuntimeError(
        "io.read_table requires either params.object='schema.table' OR params.src_schema + params.src_table"
    )


# -----------------------------------------------------------------------------
# Misc helpers for write
# -----------------------------------------------------------------------------
def _normalize_mode(mode: Any) -> str:
    m = str(mode or "append").strip().lower()
    if m not in {"append", "overwrite"}:
        raise RuntimeError(f"io.write_df params.mode must be 'append' or 'overwrite', got '{mode}'")
    return m

def _coerce_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"true", "t", "1", "y", "yes"}:
            return True
        if s in {"false", "f", "0", "n", "no"}:
            return False
    return bool(v)

def _resolve_src_df(ctx: Dict[str, Any], src_df_ref: Any) -> DataFrame:
    if isinstance(src_df_ref, DataFrame):
        return src_df_ref

    if isinstance(src_df_ref, dict) and isinstance(src_df_ref.get("df"), DataFrame):
        return src_df_ref["df"]

    if isinstance(src_df_ref, str) and src_df_ref.strip():
        ref = src_df_ref.strip()
        outputs = ctx.get("outputs") or {}
        if isinstance(outputs, dict):
            if "." in ref:
                name, channel = ref.split(".", 1)
                od = outputs.get(name)
                if isinstance(od, dict) and channel in od and isinstance(od[channel], DataFrame):
                    return od[channel]
            od = outputs.get(ref)
            if isinstance(od, dict) and isinstance(od.get("df"), DataFrame):
                return od["df"]

        params = ctx.get("params") or {}
        if isinstance(params, dict) and ref in params and isinstance(params[ref], DataFrame):
            return params[ref]
        if ref in ctx and isinstance(ctx[ref], DataFrame):
            return ctx[ref]

    raise RuntimeError(f"io.write_df cannot resolve src_df from reference: {src_df_ref!r}")

def _safe_count(df: Optional[DataFrame]) -> Optional[int]:
    if df is None:
        return None
    try:
        return int(df.count())
    except Exception:
        return None

def _extract_written_row_count(api_result: Any, src_df: Optional[DataFrame]) -> Optional[int]:
    if isinstance(api_result, dict):
        for k in ("written_row_count", "rows_written", "row_count", "count"):
            if api_result.get(k) is not None:
                try:
                    return int(api_result.get(k))
                except Exception:
                    pass
    return _safe_count(src_df)


# -----------------------------------------------------------------------------
# Physical API kwargs builders (signature-adaptive)
# -----------------------------------------------------------------------------
def _build_read_table_kwargs(*, spark, ident: Dict[str, Any], schema: str, table: str) -> Dict[str, Any]:
    sig = inspect.signature(read_table)
    supported = set(sig.parameters.keys())

    candidates = {
        "spark": spark,
        "workspace_id": ident.get("ws_id"),
        "ws_id": ident.get("ws_id"),
        "workspace_name": ident.get("ws_name"),
        "ws_name": ident.get("ws_name"),
        "datastore_id": ident.get("ds_id"),
        "ds_id": ident.get("ds_id"),
        "datastore_name": ident.get("ds_name"),
        "ds_name": ident.get("ds_name"),
        "schema": schema,
        "tgt_schema": schema,
        "table": table,
        "tgt_table": table,
    }

    kwargs: Dict[str, Any] = {}
    for k, v in candidates.items():
        if k in supported and v is not None:
            kwargs[k] = v
    return kwargs

def _build_write_table_kwargs(
    *,
    spark,
    src_df: DataFrame,
    tgt_ident: Dict[str, Any],
    tgt_schema: str,
    tgt_table: str,
    mode: str,
    auto_create_table_f: bool,
    partition_column: Optional[str],
    auto_schema_merge_f: bool,
    schema_history_ident: Optional[Dict[str, Any]],
    schema_history_schema: Optional[str],
    schema_history_table: Optional[str],
) -> Dict[str, Any]:
    sig = inspect.signature(write_table)
    supported = set(sig.parameters.keys())

    candidates = {
        "spark": spark,
        "df": src_df,
        "src_df": src_df,
        "workspace_id": tgt_ident.get("ws_id"),
        "ws_id": tgt_ident.get("ws_id"),
        "workspace_name": tgt_ident.get("ws_name"),
        "ws_name": tgt_ident.get("ws_name"),
        "datastore_id": tgt_ident.get("ds_id"),
        "ds_id": tgt_ident.get("ds_id"),
        "datastore_name": tgt_ident.get("ds_name"),
        "ds_name": tgt_ident.get("ds_name"),
        "schema": tgt_schema,
        "tgt_schema": tgt_schema,
        "table": tgt_table,
        "tgt_table": tgt_table,
        "mode": mode,
        "auto_create_table_f": auto_create_table_f,
        "partition_column": partition_column,
        "auto_schema_merge_f": auto_schema_merge_f,
    }

    if schema_history_ident:
        candidates.update({
            "schema_history_workspace_id": schema_history_ident.get("ws_id"),
            "schema_history_ws_id": schema_history_ident.get("ws_id"),
            "schema_history_datastore_id": schema_history_ident.get("ds_id"),
            "schema_history_ds_id": schema_history_ident.get("ds_id"),
            "schema_history_datastore_name": schema_history_ident.get("ds_name"),
            "schema_history_ds_name": schema_history_ident.get("ds_name"),
        })
    if schema_history_schema:
        candidates["schema_history_schema"] = schema_history_schema
    if schema_history_table:
        candidates["schema_history_table"] = schema_history_table

    kwargs: Dict[str, Any] = {}
    for k, v in candidates.items():
        if k in supported and v is not None:
            kwargs[k] = v
    return kwargs


def _success_result(**kwargs) -> Dict[str, Any]:
    out = {"status": "SUCCEEDED"}
    out.update(kwargs)
    return out

def _failed_result(exc: Exception, **kwargs) -> Dict[str, Any]:
    out = {"status": "FAILED", "error_message": str(exc), "error_type": type(exc).__name__}
    out.update(kwargs)
    return out


# -----------------------------------------------------------------------------
# Activity: io.read_table (NOW supports src_schema/src_table)
# -----------------------------------------------------------------------------
def io_read_table(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Read a Fabric table using alkali1.io.lh.read_table() and return Output Contract v1.0.0:
      {"df": DataFrame|None, "result": {...}}

    Supports either:
      - params.object = "schema.table" (legacy)
      - params.src_schema + params.src_table (new PC form)
    """
    ctx = _coerce_ctx(spark=spark, ctx=ctx, params=params, logger=logger)
    logger = ctx.get("logger")

    try:
        ds_alias = (
            _resolve_param(ctx, "ds")
            or _resolve_param(ctx, "src_ds")
            or _resolve_param(ctx, "datastore")
            or _resolve_param(ctx, "ds_alias")
            or _resolve_param(ctx, "tgt_ds")
        )
        if not ds_alias:
            raise RuntimeError("io.read_table requires ds/src_ds/datastore/ds_alias/tgt_ds")

        schema, table, mode = _resolve_schema_table(ctx)

        ds_cfg = _resolve_datastore(ctx, str(ds_alias))
        ident = _datastore_identity(ds_cfg)

        spark_sess = ctx.get("spark")
        if spark_sess is None:
            raise RuntimeError("io.read_table cannot resolve SparkSession (ctx['spark'] is missing)")

        _log_debug(
            logger,
            "io.read_table: resolved identity",
            ds_alias=ds_alias,
            ident=ident,
            schema=schema,
            table=table,
            address_mode=mode,
        )

        kwargs = _build_read_table_kwargs(spark=spark_sess, ident=ident, schema=schema, table=table)
        df = read_table(**kwargs)

        # Preserve legacy "object" in result if possible for downstream tooling
        obj = _resolve_param(ctx, "object")
        if not (isinstance(obj, str) and obj.strip()):
            obj = f"{schema}.{table}"

        return {"df": df, "result": _success_result(ds_alias=ds_alias, object=obj, identity=ident)}

    except Exception as e:
        _log_exception(logger, "io.read_table failed", error=str(e))
        return {"df": None, "result": _failed_result(e)}


# -----------------------------------------------------------------------------
# Activity: io.write_df (unchanged behavior, already engine-compatible)
# -----------------------------------------------------------------------------
def io_write_df(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Write a Spark DataFrame to a Fabric table via alkali1.io.lh.write_table().
    Returns Output Contract v1.0.0:
      {"df": None, "result": {...}}
    """
    ctx = _coerce_ctx(spark=spark, ctx=ctx, params=params, logger=logger)
    logger = ctx.get("logger")

    try:
        src_df_ref = _resolve_param(ctx, "src_df")
        src_df = _resolve_src_df(ctx, src_df_ref)

        tgt_ds = _resolve_param(ctx, "tgt_ds")
        tgt_schema = _resolve_param(ctx, "tgt_schema")
        tgt_table = _resolve_param(ctx, "tgt_table")
        if not tgt_ds or not tgt_schema or not tgt_table:
            raise RuntimeError("io.write_df requires tgt_ds, tgt_schema, tgt_table")

        mode = _normalize_mode(_resolve_param(ctx, "mode"))
        auto_create_table_f = _coerce_bool(_resolve_param(ctx, "auto_create_table_f"), default=False)
        partition_column = _resolve_param(ctx, "partition_column")
        auto_schema_merge_f = _coerce_bool(_resolve_param(ctx, "auto_schema_merge_f"), default=False)

        schema_history_ds_alias = _resolve_param(ctx, "schema_history_ds_alias")
        schema_history_schema = _resolve_param(ctx, "schema_history_schema")
        schema_history_table = _resolve_param(ctx, "schema_history_table")

        tgt_cfg = _resolve_datastore(ctx, str(tgt_ds))
        tgt_ident = _datastore_identity(tgt_cfg)

        schema_history_ident = None
        if schema_history_ds_alias:
            sh_cfg = _resolve_datastore(ctx, str(schema_history_ds_alias))
            schema_history_ident = _datastore_identity(sh_cfg)

        spark_sess = ctx.get("spark") or getattr(src_df, "sparkSession", None)
        if spark_sess is None:
            raise RuntimeError("io.write_df cannot resolve SparkSession")

        _log_debug(
            logger,
            "io.write_df: resolved targets",
            tgt_ds=tgt_ds,
            tgt_ident=tgt_ident,
            tgt_schema=tgt_schema,
            tgt_table=tgt_table,
            mode=mode,
            auto_create_table_f=auto_create_table_f,
            partition_column=partition_column,
            auto_schema_merge_f=auto_schema_merge_f,
            schema_history_ds_alias=schema_history_ds_alias,
        )

        kwargs = _build_write_table_kwargs(
            spark=spark_sess,
            src_df=src_df,
            tgt_ident=tgt_ident,
            tgt_schema=str(tgt_schema),
            tgt_table=str(tgt_table),
            mode=mode,
            auto_create_table_f=auto_create_table_f,
            partition_column=str(partition_column) if partition_column else None,
            auto_schema_merge_f=auto_schema_merge_f,
            schema_history_ident=schema_history_ident,
            schema_history_schema=str(schema_history_schema) if schema_history_schema else None,
            schema_history_table=str(schema_history_table) if schema_history_table else None,
        )

        api_result = write_table(**kwargs)
        written_row_count = _extract_written_row_count(api_result, src_df)

        return {
            "df": None,
            "result": _success_result(
                tgt_ds=tgt_ds,
                tgt_schema=tgt_schema,
                tgt_table=tgt_table,
                mode=mode,
                written_row_count=written_row_count,
                api_result=api_result,
            ),
        }

    except Exception as e:
        _log_exception(logger, "io.write_df failed", error=str(e))
        return {"df": None, "result": _failed_result(e)}


# -----------------------------------------------------------------------------
# Registration (ENGINE REQUIRED)
# -----------------------------------------------------------------------------
register_activity(
    name="io.read_table",
    fn=io_read_table,
    kind="io",
    notes="Read table via Fabric API (supports object OR src_schema/src_table; nested datastore identity; engine kw-call)",
)

register_activity(
    name="io.write_df",
    fn=io_write_df,
    kind="io",
    notes="Write DataFrame via Fabric API (nested datastore identity; engine kw-call)",
)
