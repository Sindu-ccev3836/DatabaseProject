# -*- coding: utf-8 -*-
# ===========================================================================
# File Path : alkali1/pc/engine/activities/dq_check_table_rules.py
# Version   : v1.0.0
# ===========================================================================

"""
Built-in activity: dq.check_table_rules

Purpose
-------
Evaluate table-level DQ rules using Great Expectations (GX).

Current supported expectations
-----------------------------
- expectation: "not_null"      -> GX expect_column_values_to_not_be_null
- expectation: "unique"        -> GX expect_column_values_to_be_unique
- expectation: "in_set"        -> GX expect_column_values_to_be_in_set
- expectation: "regex_match"   -> GX expect_column_values_to_match_regex
- expectation: "between"       -> GX expect_column_values_to_be_between
- expectation: "row_count_min" -> GX expect_table_row_count_to_be_between

Output Contract v1.0.0
----------------------
Returns:
{
  "df": <DataFrame | None>,
  "result": {"status": "SUCCEEDED"|"FAILED", ...}
}
"""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple

from pyspark.sql import DataFrame, Row
from pyspark.sql.types import (
    BooleanType,
    DoubleType,
    LongType,
    StringType,
    StructField,
    StructType,
)

from alkali1.io.lh import read_table
from alkali1.pc.engine.activity_registry import register_activity


ACTIVITY_NAME: str = "dq.check_table_rules"
SUPPORTED_EXPECTATIONS = {
    "not_null",
    "unique",
    "in_set",
    "regex_match",
    "between",
    "row_count_min",
}

DQ_RESULT_SCHEMA = StructType(
    [
        StructField("rule_id", StringType(), True),
        StructField("column", StringType(), True),
        StructField("expectation", StringType(), True),
        StructField("severity", StringType(), True),
        StructField("success", BooleanType(), True),
        StructField("unexpected_count", LongType(), True),
        StructField("unexpected_percent", DoubleType(), True),
        StructField("element_count", LongType(), True),
        StructField("observed_value", StringType(), True),
    ]
)


def _log_debug(logger: Any, message: str) -> None:
    fn = getattr(logger, "debug", None) if logger is not None else None
    if callable(fn):
        fn(str(message))


def _coerce_ctx_max_safe(
    *,
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
) -> Dict[str, Any]:
    """
    Max-safe ctx normalization for engine-style calls.
    """
    ctx = ctx or {}
    if not isinstance(ctx, dict):
        ctx = {"ctx": ctx}

    if spark is not None:
        ctx["spark"] = spark
    if logger is not None:
        ctx["logger"] = logger

    if params is not None:
        ctx["params"] = params
    else:
        act = ctx.get("act") or {}
        act_params = act.get("params") if isinstance(act, dict) else None
        if isinstance(act_params, dict):
            ctx["params"] = act_params
        elif not isinstance(ctx.get("params"), dict):
            ctx["params"] = {}

    return ctx


def _resolve_param(ctx: Dict[str, Any], key: str, default=None):
    p = ctx.get("params") or {}
    if isinstance(p, dict) and key in p:
        return p.get(key)
    return ctx.get(key, default)


def _as_bool(v: Any, default: bool = False) -> bool:
    if v is None:
        return default
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return bool(v)
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"1", "true", "t", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "f", "no", "n", "off"}:
            return False
    raise RuntimeError(f"PC_VALIDATION_ERROR: invalid boolean value: {v}")


def _pick_first(d: Dict[str, Any], *keys: str):
    for key in keys:
        if key in d and d.get(key) is not None:
            return d.get(key)
    return None


def _get_datastore_container(ctx: Dict[str, Any]) -> Any:
    ds = ctx.get("datastores")
    if ds is not None:
        return ds
    env = ctx.get("env") or {}
    if isinstance(env, dict):
        return env.get("datastores")
    return None


def _resolve_datastore(ctx: Dict[str, Any], ds_alias: str) -> Dict[str, Any]:
    ds_alias = (ds_alias or "").strip()
    if not ds_alias:
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_ds")

    container = _get_datastore_container(ctx)
    if container is None:
        raise RuntimeError("PC_VALIDATION_ERROR: ctx missing datastores (or env.datastores)")

    if isinstance(container, dict):
        ds = container.get(ds_alias)
        if isinstance(ds, dict):
            if "ds_alias" not in ds:
                ds = dict(ds)
                ds["ds_alias"] = ds_alias
            return ds
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    if isinstance(container, list):
        for item in container:
            if not isinstance(item, dict):
                continue
            alias = (item.get("ds_alias") or item.get("alias") or "").strip()
            if alias == ds_alias:
                return item
        raise RuntimeError(f"PC_VALIDATION_ERROR: unknown datastore alias '{ds_alias}'")

    raise RuntimeError("PC_VALIDATION_ERROR: unsupported datastores container shape")


def _datastore_identity(ds: Dict[str, Any]) -> Dict[str, Any]:
    ws = ds.get("workspace") if isinstance(ds.get("workspace"), dict) else {}
    dso = ds.get("datastore") if isinstance(ds.get("datastore"), dict) else {}

    ws_id = _pick_first(ws, "ws_id", "id") or ds.get("ws_id")
    ws_name = _pick_first(ws, "ws_name", "name") or ds.get("ws_name")
    ds_id = _pick_first(dso, "ds_id", "id") or ds.get("ds_id")
    ds_name = _pick_first(dso, "ds_name", "name") or ds.get("ds_name")

    return {
        "ws_id": ws_id,
        "ws_name": ws_name,
        "ds_id": ds_id,
        "ds_name": ds_name,
    }


def _read_src_table(ctx: Dict[str, Any]) -> Tuple[DataFrame, Dict[str, Any]]:
    spark = ctx.get("spark")
    if spark is None:
        raise RuntimeError("PC_VALIDATION_ERROR: spark not provided")

    src_ds = _resolve_param(ctx, "src_ds")
    src_schema = _resolve_param(ctx, "src_schema")
    src_table = _resolve_param(ctx, "src_table")

    if not isinstance(src_ds, str) or not src_ds.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_ds")
    if not isinstance(src_schema, str) or not src_schema.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_schema")
    if not isinstance(src_table, str) or not src_table.strip():
        raise RuntimeError("PC_VALIDATION_ERROR: missing src_table")

    ds = _resolve_datastore(ctx, src_ds)
    ident = _datastore_identity(ds)

    df = read_table(
        spark=spark,
        ws_id=ident.get("ws_id"),
        ws_name=ident.get("ws_name"),
        ds_id=ident.get("ds_id"),
        ds_name=ident.get("ds_name"),
        schema=src_schema.strip(),
        table=src_table.strip(),
        retry_number=int(_resolve_param(ctx, "retry_number", 0) or 0),
        logger=ctx.get("logger"),
    )
    return df, {
        "src_ds": src_ds.strip(),
        "src_schema": src_schema.strip(),
        "src_table": src_table.strip(),
        "identity": ident,
    }


def _validate_rules(rules: Any) -> List[Dict[str, Any]]:
    if not isinstance(rules, list) or not rules:
        raise RuntimeError("PC_VALIDATION_ERROR: rules must be a non-empty array")

    normalized: List[Dict[str, Any]] = []
    for idx, rule in enumerate(rules):
        if not isinstance(rule, dict):
            raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}] must be an object")

        rule_id = rule.get("rule_id")
        column = rule.get("column")
        expectation = str(rule.get("expectation") or "").strip().lower()
        severity = str(rule.get("severity") or "blocking").strip().lower()

        if not isinstance(rule_id, str) or not rule_id.strip():
            raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].rule_id is required")
        if expectation not in SUPPORTED_EXPECTATIONS:
            raise RuntimeError(
                "PC_VALIDATION_ERROR: rules[{}].expectation '{}' is unsupported; "
                "supported={}"
                .format(idx, expectation, sorted(SUPPORTED_EXPECTATIONS))
            )
        if severity not in {"blocking", "warning"}:
            raise RuntimeError(
                f"PC_VALIDATION_ERROR: rules[{idx}].severity must be 'blocking' or 'warning'"
            )

        expectation_needs_column = expectation in {
            "not_null",
            "unique",
            "in_set",
            "regex_match",
            "between",
        }
        if expectation_needs_column:
            if not isinstance(column, str) or not column.strip():
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].column is required for expectation='{expectation}'")
            column = column.strip()
        else:
            column = None

        value_set = rule.get("value_set")
        if expectation == "in_set":
            if not isinstance(value_set, list) or not value_set:
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].value_set must be a non-empty array for expectation='in_set'")

        regex = rule.get("regex")
        if expectation == "regex_match":
            if not isinstance(regex, str) or not regex.strip():
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].regex must be a non-empty string for expectation='regex_match'")
            regex = regex.strip()

        min_value = rule.get("min_value")
        max_value = rule.get("max_value")
        if expectation == "between" and min_value is None and max_value is None:
            raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}] requires min_value or max_value for expectation='between'")

        row_count_min = rule.get("row_count_min")
        if expectation == "row_count_min":
            if row_count_min is None:
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].row_count_min is required for expectation='row_count_min'")
            try:
                row_count_min = int(row_count_min)
            except Exception:
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].row_count_min must be an integer")
            if row_count_min < 0:
                raise RuntimeError(f"PC_VALIDATION_ERROR: rules[{idx}].row_count_min must be >= 0")

        normalized.append(
            {
                "rule_id": rule_id.strip(),
                "column": column,
                "expectation": expectation,
                "severity": severity,
                "rule_type": rule.get("rule_type"),
                "target_type": rule.get("target_type"),
                "value_set": value_set,
                "regex": regex,
                "min_value": min_value,
                "max_value": max_value,
                "strict_min": _as_bool(rule.get("strict_min", False), default=False),
                "strict_max": _as_bool(rule.get("strict_max", False), default=False),
                "parse_strings_as_datetimes": _as_bool(
                    rule.get("parse_strings_as_datetimes", rule.get("parse_as_datetime", False)),
                    default=False,
                ),
                "row_count_min": row_count_min,
            }
        )

    return normalized


def _new_gx_validator(df: DataFrame, data_context=None):
    try:
        from great_expectations.core.batch import Batch
        from great_expectations.core.expectation_suite import ExpectationSuite
        from great_expectations.execution_engine.sparkdf_execution_engine import (
            SparkDFExecutionEngine,
        )
        from great_expectations.validator.validator import Validator
    except Exception as exc:
        raise RuntimeError(
            "GX_RUNTIME_ERROR: GX 1.x Validator components are unavailable; "
            "install/enable a Great Expectations 1.x build with Spark support"
        ) from exc

    engine = SparkDFExecutionEngine()
    suite = ExpectationSuite(name="alkali_dq_runtime_suite")

    # Keep construction tolerant across GX 1.x minors.
    try:
        batch = Batch(data=df)
    except TypeError:
        batch = Batch(batch_definition=None, data=df)

    kwargs = {
        "execution_engine": engine,
        "batches": [batch],
        "expectation_suite": suite,
    }
    if data_context is not None:
        kwargs["data_context"] = data_context

    try:
        validator = Validator(**kwargs)
    except TypeError:
        kwargs["interactive_evaluation"] = True
        validator = Validator(**kwargs)

    return validator


def _run_expectation(validator, rule: Dict[str, Any]):
    expectation = rule["expectation"]
    col = rule.get("column")
    if expectation == "not_null":
        return validator.expect_column_values_to_not_be_null(
            column=col,
            result_format="SUMMARY",
        )
    if expectation == "unique":
        return validator.expect_column_values_to_be_unique(
            column=col,
            result_format="SUMMARY",
        )
    if expectation == "in_set":
        return validator.expect_column_values_to_be_in_set(
            column=col,
            value_set=rule.get("value_set"),
            result_format="SUMMARY",
        )
    if expectation == "regex_match":
        return validator.expect_column_values_to_match_regex(
            column=col,
            regex=rule.get("regex"),
            result_format="SUMMARY",
        )
    if expectation == "between":
        kwargs = {
            "column": col,
            "min_value": rule.get("min_value"),
            "max_value": rule.get("max_value"),
            "strict_min": bool(rule.get("strict_min", False)),
            "strict_max": bool(rule.get("strict_max", False)),
            "parse_strings_as_datetimes": bool(rule.get("parse_strings_as_datetimes", False)),
            "result_format": "SUMMARY",
        }
        return validator.expect_column_values_to_be_between(**kwargs)
    if expectation == "row_count_min":
        return validator.expect_table_row_count_to_be_between(
            min_value=int(rule.get("row_count_min")),
            result_format="SUMMARY",
        )
    raise RuntimeError(f"PC_VALIDATION_ERROR: unsupported expectation dispatch='{expectation}'")


def _gx_evaluate_rule(df: DataFrame, rule: Dict[str, Any]) -> Dict[str, Any]:
    """
    Run one GX expectation with fallback to ephemeral data context for Fabric runtimes.
    """
    validator = _new_gx_validator(df)

    try:
        gx_result = _run_expectation(validator, rule)
    except Exception as exc:
        # GX 1.x in some Fabric runtimes requires an active Data Context.
        if type(exc).__name__ != "DataContextRequiredError":
            raise

        try:
            import great_expectations as gx
            data_context = gx.get_context(mode="ephemeral")
        except Exception as context_exc:
            raise RuntimeError(
                "GX_RUNTIME_ERROR: failed to initialize GX ephemeral data context"
            ) from context_exc

        validator = _new_gx_validator(df, data_context=data_context)
        gx_result = _run_expectation(validator, rule)

    if hasattr(gx_result, "to_json_dict"):
        payload = gx_result.to_json_dict()
    elif isinstance(gx_result, dict):
        payload = gx_result
    else:
        payload = {}

    result_obj = payload.get("result") if isinstance(payload, dict) else {}
    result_obj = result_obj or {}

    return {
        "success": bool(payload.get("success")) if isinstance(payload, dict) else False,
        "unexpected_count": int(result_obj.get("unexpected_count") or 0),
        "unexpected_percent": float(result_obj.get("unexpected_percent") or 0.0),
        "element_count": int(result_obj.get("element_count") or 0),
        "observed_value": result_obj.get("observed_value"),
        "details": payload,
    }


def dq_check_table_rules(
    spark=None,
    ctx: Optional[Dict[str, Any]] = None,
    params: Optional[Dict[str, Any]] = None,
    logger=None,
    **_ignored,
) -> Dict[str, Any]:
    """
    Evaluate table-level DQ rules using GX.
    """
    ctx = _coerce_ctx_max_safe(spark=spark, ctx=ctx, params=params, logger=logger)
    _log_debug(ctx.get("logger"), f"{ACTIVITY_NAME}: start")

    try:
        df, src_meta = _read_src_table(ctx)
        _log_debug(
            ctx.get("logger"),
            (
                f"{ACTIVITY_NAME}: source resolved "
                f"src_ds={src_meta['src_ds']} "
                f"src_schema={src_meta['src_schema']} "
                f"src_table={src_meta['src_table']}"
            ),
        )
        rules = _validate_rules(_resolve_param(ctx, "rules"))
        fail_on_blocking = _as_bool(_resolve_param(ctx, "fail_on_blocking", True), default=True)
        _log_debug(
            ctx.get("logger"),
            f"{ACTIVITY_NAME}: validated rules count={len(rules)} fail_on_blocking={fail_on_blocking}",
        )

        rows: List[Row] = []
        dq_passed_rules: List[str] = []
        dq_failed_rules: List[str] = []
        blocking_failures: List[str] = []

        for rule in rules:
            _log_debug(
                ctx.get("logger"),
                (
                    f"{ACTIVITY_NAME}: evaluating rule_id={rule['rule_id']} "
                    f"expectation={rule['expectation']} column={rule['column']} severity={rule['severity']}"
                ),
            )
            eval_result = _gx_evaluate_rule(df, rule)
            passed = bool(eval_result["success"])
            _log_debug(
                ctx.get("logger"),
                (
                    f"{ACTIVITY_NAME}: rule_id={rule['rule_id']} success={passed} "
                    f"unexpected_count={eval_result['unexpected_count']} "
                    f"unexpected_percent={eval_result['unexpected_percent']}"
                ),
            )

            if passed:
                dq_passed_rules.append(rule["rule_id"])
            else:
                dq_failed_rules.append(rule["rule_id"])
                if rule["severity"] == "blocking":
                    blocking_failures.append(rule["rule_id"])

            rows.append(
                Row(
                    rule_id=rule["rule_id"],
                    column=rule["column"],
                    expectation=rule["expectation"],
                    severity=rule["severity"],
                    success=passed,
                    unexpected_count=int(eval_result["unexpected_count"]),
                    unexpected_percent=float(eval_result["unexpected_percent"]),
                    element_count=int(eval_result["element_count"]),
                    observed_value=(
                        json.dumps(eval_result.get("observed_value"), default=str)
                        if eval_result.get("observed_value") is not None
                        else None
                    ),
                )
            )

        status = "FAILED" if (fail_on_blocking and blocking_failures) else "SUCCEEDED"
        _log_debug(
            ctx.get("logger"),
            (
                f"{ACTIVITY_NAME}: completed status={status} "
                f"passed={len(dq_passed_rules)} failed={len(dq_failed_rules)} "
                f"blocking_failures={len(blocking_failures)}"
            ),
        )
        out_df = ctx["spark"].createDataFrame(rows, schema=DQ_RESULT_SCHEMA)

        return {
            "df": out_df,
            "result": {
                "status": status,
                "activity_type": ACTIVITY_NAME,
                "src_ds": src_meta["src_ds"],
                "src_schema": src_meta["src_schema"],
                "src_table": src_meta["src_table"],
                "identity": src_meta["identity"],
                "total_rules": len(rules),
                "dq_passed_rules": dq_passed_rules,
                "dq_failed_rules": dq_failed_rules,
                "blocking_failures": blocking_failures,
                "fail_on_blocking": fail_on_blocking,
                "gx_engine": "great_expectations.validator.validator.Validator",
            },
        }

    except Exception as exc:
        _log_debug(
            ctx.get("logger"),
            f"{ACTIVITY_NAME}: failed error_type={type(exc).__name__} error_message={exc}",
        )
        return {
            "df": None,
            "result": {
                "status": "FAILED",
                "activity_type": ACTIVITY_NAME,
                "error_type": type(exc).__name__,
                "error_message": str(exc),
            },
        }


register_activity(
    name=ACTIVITY_NAME,
    fn=dq_check_table_rules,
    kind="quality",
    notes=(
        "Evaluate table DQ rules using Great Expectations "
        "(supports not_null, unique, in_set, regex_match, between, row_count_min)"
    ),
)
