# File: alkali1/pc/engine/activities/control_invoke_set_spc.py
# -*- coding: utf-8 -*-

"""
control.invoke_set_spc

Control activity:
Invoke an inline SPC repeatedly over a declared finite set of items.

Characteristics:
- Alkali1 single-engine compatible
- Control-only (no IO, no dfs mutation)
- Deterministic SPC hashing
- Explicit engine-owned registration
"""

from __future__ import annotations

import json
import hashlib
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

from alkali1.pc.engine.activity_registry import register_activity


# ----------------------------------------------------------------------
# Utilities
# ----------------------------------------------------------------------

def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _log(logger, level: str, msg: str, extra: Optional[dict] = None) -> None:
    if logger:
        fn = getattr(logger, level.lower(), None)
        if callable(fn):
            fn(msg, extra=extra)
            return
    # fallback
    print(msg, extra)


# ----------------------------------------------------------------------
# SPC hashing helpers
# ----------------------------------------------------------------------

def _canonicalize_json(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _canonicalize_json(obj[k]) for k in sorted(obj.keys())}
    if isinstance(obj, list):
        return [_canonicalize_json(x) for x in obj]
    return obj


def _compute_spc_hash(spc_obj: dict) -> str:
    canonical_obj = _canonicalize_json(spc_obj)
    canonical_str = json.dumps(
        canonical_obj,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256(canonical_str.encode("utf-8")).hexdigest()


def _derive_spc_id(spc_obj: dict, spc_hash: str) -> str:
    meta = spc_obj.get("pc_metadata")
    if isinstance(meta, dict):
        name = meta.get("name")
        if isinstance(name, str) and name.strip():
            return name.strip()
    return spc_hash


# ----------------------------------------------------------------------
# Binding helpers
# ----------------------------------------------------------------------

def _require_str(x: Any, err: str) -> str:
    if not isinstance(x, str) or not x.strip():
        raise RuntimeError(err)
    return x.strip()


def _parse_binding_item(item: dict) -> dict:
    if not isinstance(item, dict):
        raise RuntimeError(
            "SET_INVOKE_ERROR: each set item must be an object"
        )
    return item


def _binding_as_window_ctx(binding: dict) -> dict:
    return {
        "id": binding["binding_id"],
        "source": binding["source"],
        "target": binding["target"],
        "extras": binding.get("extras"),
    }


# ----------------------------------------------------------------------
# Activity implementation
# ----------------------------------------------------------------------

def control_invoke_set_spc(ctx: Dict[str, Any]) -> None:
    """
    Validate and invoke an inline SPC over a finite set of bindings.

    Expected ctx keys:
    - ctx["act"] : activity definition
    - ctx["logger"] (optional)
    """
    logger = ctx.get("logger")
    act = ctx.get("act") or {}

    params = act.get("params") or {}
    spc_obj = params.get("spc")
    bindings = params.get("set")

    if not isinstance(spc_obj, dict):
        raise RuntimeError("control.invoke_set_spc requires params.spc (object)")

    if not isinstance(bindings, list) or not bindings:
        raise RuntimeError("control.invoke_set_spc requires params.set (non-empty list)")

    # ------------------------------------------------------------
    # SPC identity
    # ------------------------------------------------------------
    spc_hash = _compute_spc_hash(spc_obj)
    spc_id = _derive_spc_id(spc_obj, spc_hash)

    _log(
        logger,
        "info",
        f"control.invoke_set_spc: SPC '{spc_id}' "
        f"({len(bindings)} bindings, hash={spc_hash})",
    )

    # ------------------------------------------------------------
    # Iterate bindings
    # ------------------------------------------------------------
    for idx, raw_binding in enumerate(bindings):
        binding = _parse_binding_item(raw_binding)

        binding_id = _require_str(
            binding.get("binding_id"),
            "SET_INVOKE_ERROR: binding_id is required",
        )

        window_ctx = _binding_as_window_ctx(binding)

        _log(
            logger,
            "info",
            f"control.invoke_set_spc: invoking binding {idx + 1}/{len(bindings)} "
            f"(binding_id={binding_id})",
            extra={
                "spc_id": spc_id,
                "spc_hash": spc_hash,
                "binding": window_ctx,
                "ts_utc": _utc_now_iso(),
            },
        )

        # NOTE:
        # Actual SPC execution is intentionally not implemented here.
        # This activity is responsible only for validation, identity,
        # and controlled iteration.


# ----------------------------------------------------------------------
# ✅ Engine-owned registration
# ----------------------------------------------------------------------

register_activity(
    name="control.invoke_set_spc",
    fn=control_invoke_set_spc,
    kind="control",
    notes="Invoke an inline SPC over a declared finite set of source/target bindings",
)