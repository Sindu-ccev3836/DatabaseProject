# ===========================================================================
# File Path : alkali1/pc/engine/file_loader_registry.py
# File Name : file_loader_registry.py
# Version   : v1.0.1
# ===========================================================================

# -*- coding: utf-8 -*-

"""
File Loader Registry (Engine-Owned)

Purpose:
- Maintain mapping between file_format and loader implementation
- Support loader self-registration via import side-effects

Note:
- Loader discovery/import is performed by the engine.
- This registry provides registration + lookup + freeze only.
"""

from __future__ import annotations
from typing import Any, Dict, Optional


# ---------------------------------------------------------------------------
# 🤖 AI CONTRACT (File Loader Registry)
# ---------------------------------------------------------------------------
# Identity
# - Component : file_loader_registry
# - Ownership : Engine-owned (Platform Core)
#
# Purpose
# - Provide a stable registration and lookup mechanism for file loader plugins.
#
# Responsibilities (MUST)
# - Allow loader modules to register themselves under a file_format key
# - Provide get_file_loader(file_format) for activities to dispatch on format
# - Support freezing to prevent mutation after engine startup
#
# Non-Responsibilities (MUST NOT)
# - Must not auto-import/discover modules (engine does autoloading)
# - Must not execute IO, parsing, Spark, or table writes
# - Must not validate loader parameters (loader-owned)
#
# Invariants
# - Write-once (per file_format), read-many
# - Frozen before pipeline execution begins
# ---------------------------------------------------------------------------


_FILE_LOADERS: Dict[str, Any] = {}
_FROZEN: bool = False


def register_file_loader(file_format: str, loader: Any) -> None:
    """
    Register a loader instance (or callable object) under file_format.

    Expected loader interface (by convention):
      loader.load(files=..., ctx=..., params=..., datastore=...)
    """
    global _FROZEN

    if _FROZEN:
        raise RuntimeError("File loader registry is frozen; registration not allowed")

    if not file_format or not isinstance(file_format, str):
        raise RuntimeError("register_file_loader requires a non-empty file_format")

    key = file_format.lower().strip()
    if key in _FILE_LOADERS:
        raise RuntimeError(f"File loader already registered for file_format='{key}'")

    _FILE_LOADERS[key] = loader


def get_file_loader(file_format: str) -> Optional[Any]:
    """
    Retrieve the loader registered for file_format, or None if not found.
    """
    if not file_format:
        return None
    return _FILE_LOADERS.get(file_format.lower().strip())


def freeze_file_loader_registry() -> None:
    """
    Freeze the registry to prevent late mutation after engine startup.
    """
    global _FROZEN
    _FROZEN = True
