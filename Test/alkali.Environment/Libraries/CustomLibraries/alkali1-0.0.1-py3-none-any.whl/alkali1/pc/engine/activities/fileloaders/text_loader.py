# text_loader.py
from pyspark.sql import SparkSession, DataFrame
from .base import FileLoader
from alkali1.pc.engine.file_loader_registry import register_file_loader


class TextLoader(FileLoader):

    @property
    def capability(self) -> str:
        return "text.v1"

    def load(self, spark: SparkSession, activity: dict) -> DataFrame:
        delimiter = activity.get("field_delimiter", ",")
        hash_alg = activity.get("hash_algorithm", "md5")

        activity["_loader_param"] = {
            "field_delimiter": delimiter,
            "hash_algorithm": hash_alg
        }

        return (
            spark.read
            .option("delimiter", delimiter)
            .text(activity["current_file_path"])
        )


register_file_loader("text", TextLoader)