# File: alkalipc/pc/engine_resolver.py
# v1.8.2 – pc_compatibility REMOVED

from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple


def _parse_version3(v: Any) -> Tuple[int, int, int]:
    if not isinstance(v, str):
        return (0, 0, 0)

    s = v.strip().lower()
    if s.startswith("v"):
        s = s[1:]

    parts: List[int] = []
    for token in s.split("."):
        num = ""
        for ch in token:
            if ch.isdigit():
                num += ch
            else:
                break
        if not num:
            break
        parts.append(int(num))
        if len(parts) == 3:
            break

    while len(parts) < 3:
        parts.append(0)

    return tuple(parts)  # (major, minor, patch)


def resolve_engine_row(
    *,
    pc_version: str,
    registry_rows: List[Dict[str, Any]],
    engine_id: str = "alkali-engine",
    max_engine_version: Optional[str] = None,
    max_engine_release: Optional[str] = None,  # legacy alias
) -> Dict[str, Any]:
    """
    Resolve engine according to Alkali Design Spec v1.8.2.

    Rules:
    1. status == 'active'
    2. engine major == PC major
    3. engine minor >= PC minor (choose closest)
    4. highest patch within chosen minor
    """

    if not pc_version or not isinstance(pc_version, str):
        raise ValueError("pc_version must be a non-empty string")

    if max_engine_version is None and max_engine_release is not None:
        max_engine_version = max_engine_release

    pcM, pcN, pcP = _parse_version3(pc_version)
    cap = _parse_version3(max_engine_version) if max_engine_version else None

    candidates: List[Tuple[Tuple[int, int, int], Dict[str, Any]]] = []

    for r in registry_rows or []:
        if not isinstance(r, dict):
            continue
        if r.get("engine_id") != engine_id:
            continue
        if str(r.get("status", "")).lower() != "active":
            continue

        ev = r.get("engine_version") or r.get("engine_release")
        if not ev:
            continue

        eM, eN, eP = _parse_version3(ev)

        # Rule 1: major must match
        if eM != pcM:
            continue

        # Rule 2: minor must not be less
        if eN < pcN:
            continue

        # Optional cap
        if cap and (eM, eN, eP) > cap:
            continue

        candidates.append(((eM, eN, eP), r))

    if not candidates:
        raise RuntimeError(
            f"ENGINE_RESOLUTION_ERROR: No eligible engine found "
            f"pc_version={pc_version} engine_id={engine_id}"
        )

    # Closest minor
    closest_minor = min(ver[1] for ver, _ in candidates)

    # Highest patch within that minor
    same_minor = [(ver, row) for ver, row in candidates if ver[1] == closest_minor]
    max_patch = max(ver[2] for ver, _ in same_minor)

    winners = [(ver, row) for ver, row in same_minor if ver[2] == max_patch]

    # Deterministic stabilizer
    winners.sort(
        key=lambda x: (
            x[1].get("released_at") or "",
            str(x[1].get("module_path") or ""),
        )
    )

    selected = winners[-1][1]

    if not selected.get("module_path"):
        raise RuntimeError(
            f"ENGINE_RESOLUTION_ERROR: Selected engine missing module_path: {selected}"
        )

    return selected