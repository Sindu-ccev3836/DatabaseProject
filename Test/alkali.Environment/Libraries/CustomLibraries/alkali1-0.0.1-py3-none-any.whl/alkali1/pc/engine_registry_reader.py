# -*- coding: utf-8 -*-
"""
File: alkalipc/pc/engine_registry_reader.py

Purpose:
  Read the Alkali engine registry stored as a Delta table in a Fabric Lakehouse,
  using correct OneLake ABFSS addressing.

Key Fix (v2):
  - DO NOT use ds_id as the ABFSS container name
  - Use ds_name as container, ds_id as item path segment
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional
from pyspark.sql import SparkSession, DataFrame
from notebookutils import mssparkutils


# ---------------------------------------------------------------------------
# Logging helpers
# ---------------------------------------------------------------------------

def _log(logger: Any, level: str, msg: str, extra: Optional[dict] = None) -> None:
    if logger:
        fn = getattr(logger, level.lower(), None)
        if callable(fn):
            try:
                fn(msg, extra=extra) if extra else fn(msg)
            except TypeError:
                fn(f"{msg} {extra}" if extra else msg)
            return
    print(f"{level.upper()}: {msg} {extra or ''}".strip())


def _require_str(name: str, val: Any) -> str:
    if not isinstance(val, str) or not val.strip():
        raise RuntimeError(f"ENGINE_REGISTRY_ERROR: '{name}' must be a non-empty string")
    return val.strip()


# ---------------------------------------------------------------------------
# Delta helpers
# ---------------------------------------------------------------------------

def _delta_read(spark: SparkSession, path: str) -> DataFrame:
    return spark.read.format("delta").load(path)


def _path_exists(path: str) -> bool:
    try:
        mssparkutils.fs.ls(path)
        return True
    except Exception:
        return False


# ---------------------------------------------------------------------------
# Path construction (CORRECT OneLake model)
# ---------------------------------------------------------------------------

def _build_lakehouse_base_path(
    *,
    workspace_id: str,
    lakehouse_name: str,
    lakehouse_item_id: str,
) -> str:
    """
    Correct Fabric OneLake Lakehouse path:

      abfss://<lakehouse_name>@onelake.dfs.fabric.microsoft.com/<workspace_id>/<lakehouse_item_id>
    """
    ws = _require_str("ws_id", workspace_id)
    name = _require_str("ds_name", lakehouse_name)
    item = _require_str("ds_id", lakehouse_item_id)

    return f"abfss://{name}@onelake.dfs.fabric.microsoft.com/{ws}/{item}"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def read_engine_registry(
    *,
    spark: SparkSession,
    registry_workspace_id: str,
    registry_lakehouse_id: Optional[str] = None,  # legacy
    registry_datastore_id: Optional[str] = None,  # ds_id
    registry_datastore_name: Optional[str] = None,  # ds_name ✅ REQUIRED
    registry_datastore_type: Optional[str] = None,  # LAKEHOUSE
    schema: str = "alkali_meta",
    table: str = "engine_registry",
    logger: Any = None,
) -> List[Dict[str, Any]]:
    """
    Read engine registry Delta table from Fabric Lakehouse.

    Requires (preferred):
      - ws_id
      - ds_id
      - ds_name
      - ds_type == LAKEHOUSE
    """

    ws_id = _require_str("registry_workspace_id", registry_workspace_id)
    table = _require_str("table", table)

    # ---- Determine addressing mode ----
    if registry_lakehouse_id:
        raise RuntimeError(
            "ENGINE_REGISTRY_ERROR: legacy lh_id addressing is no longer supported "
            "without lakehouse name. Please use ds_id + ds_name."
        )

    ds_id = _require_str("engine_registry.ds_id", registry_datastore_id)
    ds_name = _require_str("engine_registry.ds_name", registry_datastore_name)

    ds_type = (registry_datastore_type or "").upper()
    if ds_type != "LAKEHOUSE":
        raise RuntimeError(
            f"ENGINE_REGISTRY_ERROR: engine registry must be stored in a LAKEHOUSE, got '{ds_type}'"
        )

    base = _build_lakehouse_base_path(
        workspace_id=ws_id,
        lakehouse_name=ds_name,
        lakehouse_item_id=ds_id,
    )

    # ---- Candidate physical layouts ----
    candidates = [
        f"{base}/Tables/{table}",
        f"{base}/Tables/{schema}/{table}",
        f"{base}/Tables/{schema}.{table}",
    ]

    _log(logger, "info", "engine_registry.read_start", {
        "workspace_id": ws_id,
        "ds_name": ds_name,
        "ds_id": ds_id,
        "candidates": candidates,
    })

    chosen_path = None
    last_err = None

    for p in candidates:
        if _path_exists(p):
            chosen_path = p
            break

    if chosen_path is None:
        for p in candidates:
            try:
                _ = _delta_read(spark, p)
                chosen_path = p
                break
            except Exception as e:
                last_err = e

    if chosen_path is None:
        raise RuntimeError(
            "ENGINE_REGISTRY_READ_ERROR: none of the candidate Delta paths exist or are readable. "
            f"Candidates={candidates} LastError={last_err}"
        )

    _log(logger, "info", "engine_registry.path_selected", {"path": chosen_path})

    try:
        df = _delta_read(spark, chosen_path)
        rows = [r.asDict(recursive=True) for r in df.collect()]
    except Exception as e:
        raise RuntimeError(
            f"ENGINE_REGISTRY_READ_ERROR: failed to read Delta table at {chosen_path} :: {e}"
        ) from e

    _log(logger, "info", "engine_registry.read_done", {"row_count": len(rows)})
    return rows
