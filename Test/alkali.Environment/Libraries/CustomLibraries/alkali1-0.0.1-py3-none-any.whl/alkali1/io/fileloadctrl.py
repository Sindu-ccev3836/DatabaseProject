# ===========================================================================
# File Path : alkali1/io/fileloadctrl.py
# Version   : v2.1.3 (DDL-aligned, lh.py enforced, backward compatible)
# ===========================================================================
# -*- coding: utf-8 -*-

"""
File Load Control Table Utilities

Authoritative, append-only control table access for file ingestion.
"""

from __future__ import annotations

from typing import Dict, Any, List
from datetime import datetime, timedelta
import json

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    TimestampType,
    LongType,
)
from pyspark.sql.window import Window

from alkali1.io.lh import read_table, write_table

# ===========================================================================
# Helpers
# ===========================================================================

def _now() -> datetime:
    return datetime.utcnow()


def _normalize_ctrl_ds(ds: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "ws_id": ds.get("workspace_id") or ds.get("ws_id"),
        "ws_name": ds.get("workspace_name") or ds.get("ws_name"),
        "ds_id": ds.get("lakehouse_id") or ds.get("ds_id"),
        "ds_name": ds.get("lakehouse_name") or ds.get("ds_name"),
    }


# ===========================================================================
# Canonical control table schema (DDL v2.1.2)
# ===========================================================================

CONTROL_TABLE_SCHEMA = StructType([
    StructField("src_path", StringType(), False),
    StructField("loader", StringType(), False),
    StructField("load_status", StringType(), False),
    StructField("load_start_time", TimestampType(), False),
    StructField("load_end_time", TimestampType(), True),

    StructField("src_hash", StringType(), True),
    StructField("hash_algorithm", StringType(), True),
    StructField("src_record_count", LongType(), True),
    StructField("record_count_processed", LongType(), True),
    StructField("failed_count", LongType(), True),

    StructField("error_message", StringType(), True),
    StructField("loader_param", StringType(), True),
])


# ===========================================================================
# Internal writer
# ===========================================================================

def _write_ctrl_row(
    *,
    spark: SparkSession,
    ctrl_ds: Dict[str, Any],
    ctrl_schema: str,
    ctrl_table: str,
    row: Dict[str, Any],
    logger=None,
) -> None:
    ds = _normalize_ctrl_ds(ctrl_ds)

    full_row = {
        "src_path": row["src_path"],
        "loader": row["loader"],
        "load_status": row["load_status"],
        "load_start_time": row["load_start_time"],
        "load_end_time": row.get("load_end_time"),

        "src_hash": row.get("src_hash"),
        "hash_algorithm": row.get("hash_algorithm"),
        "src_record_count": row.get("src_record_count"),
        "record_count_processed": row.get("record_count_processed"),
        "failed_count": row.get("failed_count"),

        "error_message": row.get("error_message"),
        "loader_param": row.get("loader_param") or "{}",
    }

    if logger:
        logger.debug(
            f"[fileloadctrl] INSERT {full_row['load_status']} src_path={full_row['src_path']}"
        )

    df = spark.createDataFrame([full_row], CONTROL_TABLE_SCHEMA)

    write_table(
        spark=spark,
        df=df,
        ws_id=ds["ws_id"],
        ws_name=ds["ws_name"],
        ds_id=ds["ds_id"],
        ds_name=ds["ds_name"],
        schema=ctrl_schema,
        table=ctrl_table,
        mode="append",
        allow_schema_merge=False,
        logger=logger,
    )


# ===========================================================================
# Public API — writers
# ===========================================================================

def insert_started(*, spark, ctrl_ds, ctrl_schema, ctrl_table, row, logger=None):
    _write_ctrl_row(
        spark=spark,
        ctrl_ds=ctrl_ds,
        ctrl_schema=ctrl_schema,
        ctrl_table=ctrl_table,
        row={
            "src_path": row["src_path"],
            "loader": row["loader"],
            "load_status": "STARTED",
            "load_start_time": row.get("load_start_time") or _now(),
            "loader_param": row.get("loader_param"),
        },
        logger=logger,
    )


def insert_succeeded(*, spark, ctrl_ds, ctrl_schema, ctrl_table, row, loader_result, logger=None):
    _write_ctrl_row(
        spark=spark,
        ctrl_ds=ctrl_ds,
        ctrl_schema=ctrl_schema,
        ctrl_table=ctrl_table,
        row={
            "src_path": row["src_path"],
            "loader": row["loader"],
            "load_status": "SUCCEEDED",
            "load_start_time": row.get("load_start_time") or _now(),
            "load_end_time": row.get("load_end_time") or _now(),

            "src_hash": loader_result.get("src_hash"),
            "hash_algorithm": loader_result.get("hash_algorithm"),
            "src_record_count": loader_result.get("src_record_count"),
            "record_count_processed": loader_result.get("record_count_processed"),
            "failed_count": loader_result.get("failed_count"),

            "loader_param": row.get("loader_param"),
        },
        logger=logger,
    )


def insert_failed(*, spark, ctrl_ds, ctrl_schema, ctrl_table, row, error, logger=None):
    _write_ctrl_row(
        spark=spark,
        ctrl_ds=ctrl_ds,
        ctrl_schema=ctrl_schema,
        ctrl_table=ctrl_table,
        row={
            "src_path": row["src_path"],
            "loader": row["loader"],
            "load_status": "FAILED",
            "load_start_time": row.get("load_start_time") or _now(),
            "load_end_time": row.get("load_end_time") or _now(),
            "error_message": error,
            "loader_param": row.get("loader_param"),
        },
        logger=logger,
    )


# ===========================================================================
# ✅ Backward‑compatible READ helpers (FIXES YOUR ERROR)
# ===========================================================================

def get_latest_status_map(
    *,
    spark: SparkSession,
    ctrl_ds: Dict[str, Any],
    ctrl_schema: str,
    ctrl_table: str,
    src_paths: List[str],
    logger=None,
) -> Dict[str, Dict[str, Any]]:
    """
    Read-only helper.
    Returns latest control-table row per src_path.
    """
    ds = _normalize_ctrl_ds(ctrl_ds)

    if logger:
        logger.debug(f"[fileloadctrl] get_latest_status_map for {len(src_paths)} paths")

    df = read_table(
        spark=spark,
        ws_id=ds["ws_id"],
        ws_name=ds["ws_name"],
        ds_id=ds["ds_id"],
        ds_name=ds["ds_name"],
        schema=ctrl_schema,
        table=ctrl_table,
        logger=logger,
    ).filter(F.col("src_path").isin(src_paths))

    window = Window.partitionBy("src_path").orderBy(
        F.col("load_start_time").desc(),
        F.col("load_end_time").desc(),
    )

    latest_df = (
        df.withColumn("rn", F.row_number().over(window))
          .filter(F.col("rn") == 1)
          .drop("rn")
    )

    result = {r["src_path"]: r.asDict() for r in latest_df.collect()}

    if logger:
        logger.debug(f"[fileloadctrl] latest map size = {len(result)}")

    return result


def find_zombies(*, spark, ctrl_ds, ctrl_schema, ctrl_table, min_gap_min, logger=None):
    ds = _normalize_ctrl_ds(ctrl_ds)
    cutoff = _now() - timedelta(minutes=min_gap_min)

    df = read_table(
        spark=spark,
        ws_id=ds["ws_id"],
        ws_name=ds["ws_name"],
        ds_id=ds["ds_id"],
        ds_name=ds["ds_name"],
        schema=ctrl_schema,
        table=ctrl_table,
        logger=logger,
    )

    zombies = (
        df.filter(F.col("load_status") == "STARTED")
          .filter(F.col("load_start_time") < F.lit(cutoff))
          .collect()
    )

    if logger:
        logger.debug(f"[fileloadctrl] zombies found: {len(zombies)}")

    return [r.asDict() for r in zombies]
