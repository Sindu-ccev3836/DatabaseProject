# -*- coding: utf-8 -*-
"""
AlkaliWH v1.0.0

Unified Warehouse IO class combining:
- FabricWarehouseSource (reader) from whreader.py
- FabricWarehouseWriter (writer) from whwriter.py

Design goals:
- One class AlkaliWH
- Share common methods (retry/backoff, quoting, exists/schema, etc.)
- Retain public method signatures:
  - read(self) -> DataFrame                (no parameters)
  - write(self, *, df, schema, table, ...) (retain writer.write parameters)
  - validate_schemas(self, *, df, schema, table, ...) (retain writer.validate_schemas parameters)
"""

from __future__ import annotations

import logging
import time
import random
from datetime import datetime
from typing import (
    Any, Callable, Dict, TypeVar, Sequence, Tuple, Type, Optional, Union, Literal, List
)

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import (
    StructType, StructField, DataType, ByteType, ShortType, IntegerType, LongType,
    FloatType, DoubleType, DecimalType, StringType, BooleanType, BinaryType,
    DateType, TimestampType, ArrayType, MapType
)
from pyspark.sql.utils import AnalysisException

try:
    from com.microsoft.spark.fabric.Constants import Constants  # type: ignore
except Exception as _e:
    Constants = None

T = TypeVar("T")

WriteMode = Literal["append", "overwrite", "upsertmerge"]
ValidationMode = Literal["exact", "compatible"]
OnValidationError = Literal["error", "warn"]


class AlkaliWH:
    """
    Unified Microsoft Fabric Warehouse I/O helper.

    - Read route configuration is provided at init (table route OR select_sql route), then call read().
    - Write target is provided per write(...) call (schema, table), consistent with FabricWarehouseWriter public API.
    - Cross-warehouse context is fixed per instance: workspace_id, warehouse_id, warehouse_name.
    """

    __version__ = "1.0.0"

    def __init__(
        self,
        spark: SparkSession = None,
        *,
        workspace_id: str,
        warehouse_id: str,
        warehouse_name: str,
        logger: Optional[logging.Logger] = None,

        # ---------- Read route configuration (optional until read() is used) ----------
        schema_name: Optional[str] = None,
        table_name: Optional[str] = None,
        select_sql: Optional[str] = None,
        extra_read_options: Optional[Dict[str, str]] = None,
        columns: Optional[Sequence[str]] = None,
        predicate_sql: Optional[str] = None,
        limit_rows: Optional[int] = None,
        expect_schema: Optional[StructType] = None,

        # ---------- Retry/backoff shared ----------
        retry_number: int = 2,
        retry_base_delay_sec: int = 30,
        retry_max_delay_sec: int = 300,
        retry_jitter_sec: int = 12,
        retryable_exceptions: Tuple[Type[BaseException], ...] = (Exception,),
        duration_rounding: str = "round",
        sleep_fn: Optional[Callable[[int], None]] = None,

        # ---------- Writer schema validation defaults ----------
        validate_schema: bool = False,
        validation_mode: ValidationMode = "compatible",
        schema_case_sensitive: bool = False,
        allow_extra_source_columns: bool = False,
        allow_missing_target_columns: bool = True,
        warn_on_nullable_mismatch: bool = True,
        on_validation_error: OnValidationError = "error",
        validate_on_create: bool = False,
    ):
        if Constants is None:
            raise ImportError(
                "Fabric Spark connector Constants not available. Ensure this runs in Fabric Spark and "
                "'from com.microsoft.spark.fabric.Constants import Constants' succeeds."
            )
        if not spark:
            raise RuntimeError("SparkSession is not active.")
        self.spark = spark

        # Logger
        self.logger = logger or logging.getLogger(__name__)

        # Required warehouse context
        for name, val in (("workspace_id", workspace_id), ("warehouse_id", warehouse_id), ("warehouse_name", warehouse_name)):
            if val is None or (isinstance(val, str) and val.strip() == ""):
                raise ValueError(f"{name} is required and must be a non-empty string.")
        self.workspace_id = workspace_id.strip()
        self.warehouse_id = warehouse_id.strip()
        self.warehouse_name = warehouse_name.strip()

        # Retry config (shared)
        self.attempts_total = max(1, int(retry_number) + 1)
        self.retry_base_delay_sec = max(0, int(retry_base_delay_sec))
        self.retry_max_delay_sec = max(0, int(retry_max_delay_sec))
        self.retry_jitter_sec = max(0, int(retry_jitter_sec))
        self.retryable_exceptions = retryable_exceptions or (Exception,)
        self.duration_rounding = (duration_rounding or "round").lower().strip()
        if self.duration_rounding not in {"round", "floor", "ceil"}:
            self.duration_rounding = "round"
        self.sleep_fn = sleep_fn or (lambda s: time.sleep(int(s)))

        # Read route config
        self.schema_name = (schema_name or "").strip() or None
        self.table_name = (table_name or "").strip() or None
        self.select_sql = select_sql
        self.extra_read_options = extra_read_options or {}
        self.columns = list(columns) if columns else None
        self.predicate_sql = predicate_sql
        self.limit_rows = int(limit_rows) if limit_rows is not None else None
        self.expect_schema = expect_schema

        # Writer validation defaults
        self.validate_schema_default = bool(validate_schema)
        self.validation_mode = validation_mode
        self.schema_case_sensitive = bool(schema_case_sensitive)
        self.allow_extra_source_columns = bool(allow_extra_source_columns)
        self.allow_missing_target_columns = bool(allow_missing_target_columns)
        self.warn_on_nullable_mismatch = bool(warn_on_nullable_mismatch)
        self.on_validation_error = on_validation_error
        self.validate_on_create = bool(validate_on_create)

        # Validate read route selection if read() is used later:
        # (schema_name + table_name) XOR (select_sql)
        self._has_table_route = bool(self.schema_name and self.table_name)
        self._has_select_route = bool(self.select_sql)

        self.logger.debug(
            "AlkaliWH initialised: WorkspaceId=%s DatawarehouseId=%s warehouse_name=%s",
            self.workspace_id, self.warehouse_id, self.warehouse_name
        )

    # -------------------------------------------------------------------------
    # Public API (RETAIN SIGNATURES)
    # -------------------------------------------------------------------------

    def read(self) -> DataFrame:
        """
        Retained reader public API: read(self) -> DataFrame

        Uses the route configured at __init__:
        - Table route: schema_name + table_name (optionally pushdown via columns/predicate/limit)
        - Select route: select_sql
        """
        # enforce exactly one route if read() is called
        if (self._has_table_route + self._has_select_route) != 1:
            raise ValueError("Provide exactly one read route at init: (schema_name + table_name) OR select_sql")

        if self._has_select_route:
            preview = self.select_sql[:300] + ("..." if len(self.select_sql) > 300 else "")
            self.logger.info("[AlkaliWH:read:select_sql_preview] %s", preview)
            context = f"workspace_id={self.workspace_id} warehouse_id={self.warehouse_id} warehouse_name={self.warehouse_name}"
            return self._run_with_retry(
                op_name="AlkaliWH:read_select_synapsesql",
                func=lambda: self._read_select_once(),
                attempts=self.attempts_total,
                base_delay_sec=self.retry_base_delay_sec,
                max_delay_sec=self.retry_max_delay_sec,
                jitter_sec=self.retry_jitter_sec,
                sleep_fn=self.sleep_fn,
                logger=self.logger,
                retryable_exceptions=self.retryable_exceptions,
                duration_rounding=self.duration_rounding,
                context=context,
            )

        context = f"workspace_id={self.workspace_id} warehouse_id={self.warehouse_id} warehouse_name={self.warehouse_name} schema={self.schema_name} table={self.table_name}"
        return self._run_with_retry(
            op_name="AlkaliWH:read_table_synapsesql",
            func=lambda: self._read_table_once(),
            attempts=self.attempts_total,
            base_delay_sec=self.retry_base_delay_sec,
            max_delay_sec=self.retry_max_delay_sec,
            jitter_sec=self.retry_jitter_sec,
            sleep_fn=self.sleep_fn,
            logger=self.logger,
            retryable_exceptions=self.retryable_exceptions,
            duration_rounding=self.duration_rounding,
            context=context,
        )

    def write(
        self,
        *,
        df: DataFrame,
        schema: str,
        table: str,
        mode: WriteMode = "append",
        merge_keys: Optional[Sequence[str]] = None,
        writer_options: Optional[Dict[str, str]] = None,
        validate_schema: Optional[bool] = None,
        truncate_destination_table: bool = False,
        auto_create_table: bool = True,
        database_name_override: Optional[str] = None,
        non_nullable_hint: Optional[Sequence[str]] = None,
    ) -> Dict[str, Union[str, int]]:
        """
        Retained writer public API: same parameters as FabricWarehouseWriter.write(...)
        """
        target = self._three_part(schema, table, database_name_override)
        row_count = -1
        try:
            row_count = df.count()
        except Exception:
            pass

        self.logger.info(
            "Starting write: mode=%s, target=%s, rows=%d, truncate=%s, auto_create=%s",
            mode, target, row_count, str(truncate_destination_table), str(auto_create_table)
        )

        # Optional schema validation (same behavior as writer)
        do_validate = self.validate_schema_default if validate_schema is None else bool(validate_schema)
        if do_validate:
            exists_for_validation = self._table_exists(target)
            if exists_for_validation or self.validate_on_create:
                try:
                    dest_schema = self._fetch_target_schema(target)
                    problems = self._validate_against_target(df.schema, dest_schema)
                    if problems:
                        msg = "Schema validation failed:\n- " + "\n- ".join(problems)
                        if self.on_validation_error == "error":
                            self.logger.error(msg)
                            raise ValueError(msg)
                        else:
                            self.logger.warning(msg)
                    else:
                        self.logger.info("Schema validation passed.")
                except AnalysisException:
                    self.logger.info("Schema validation skipped: table not found.")
                except Exception as e:
                    self.logger.exception("Schema validation error: %s", str(e))
                    if self.on_validation_error == "error":
                        raise

        # Auto-create if missing
        if not self._table_exists(target):
            if auto_create_table:
                final_df = self._enforce_non_nullable_hint(df, non_nullable_hint)
                (
                    final_df.limit(0).write
                    .mode("overwrite")
                    .option(Constants.WorkspaceId, self.workspace_id)
                    .option(Constants.DatawarehouseId, self.warehouse_id)
                    .synapsesql(target)
                )
            else:
                error_msg = f"Missing target table. Target '{target}' does not exist and auto_create_table=False"
                self.logger.error(error_msg)
                raise ValueError(error_msg)

        # Normal write paths
        if mode in ("append", "overwrite"):
            final_df = self._enforce_non_nullable_hint(df, non_nullable_hint)
            self._write_with_retry(final_df, target, mode.lower(), writer_options, truncate_destination_table)
            return {"mode_used": mode, "rows_written": row_count, "target": target}

        if mode == "upsertmerge":
            if not merge_keys:
                raise ValueError("UpsertMerge requires merge_keys.")
            for k in merge_keys:
                if k not in df.columns:
                    raise ValueError(f"merge_key '{k}' not found in source DataFrame columns.")

            df_target = self._read_with_retry(target)
            src_key_df = df.select(*merge_keys).dropDuplicates()
            df_tgt_only = df_target.join(src_key_df, on=list(merge_keys), how="left_anti")

            df_src_aligned, df_tgt_only_aligned = self._align_for_union(df, df_tgt_only)
            upsert_result = df_src_aligned.unionByName(df_tgt_only_aligned, allowMissingColumns=True)
            upsert_result = self._enforce_non_nullable_hint(upsert_result, non_nullable_hint)

            upsert_count = -1
            try:
                upsert_count = upsert_result.count()
            except Exception:
                pass

            self._write_with_retry(upsert_result, target, "overwrite", writer_options, truncate_destination_table)
            return {"mode_used": "upsertmerge", "rows_written": upsert_count, "target": target}

        raise ValueError(f"Unsupported mode: {mode}")

    def validate_schemas(
        self,
        *,
        df: DataFrame,
        schema: str,
        table: str,
        database_name_override: Optional[str] = None,
        validation_mode: Optional[ValidationMode] = None,
        schema_case_sensitive: Optional[bool] = None,
        allow_extra_source_columns: Optional[bool] = None,
        allow_missing_target_columns: Optional[bool] = None,
        warn_on_nullable_mismatch: Optional[bool] = None,
    ) -> bool:
        """
        Retained writer public API: same parameters as FabricWarehouseWriter.validate_schemas(...)
        """
        target = self._three_part(schema, table, database_name_override)
        try:
            dest_schema = self._fetch_target_schema(target)
        except AnalysisException:
            self.logger.info("[validate_schemas] Destination not found: %s — treating as valid for initial create", target)
            return True
        except Exception as e:
            self.logger.exception("[validate_schemas] Error fetching destination schema: %s", str(e))
            return False

        prev = (
            self.validation_mode,
            self.schema_case_sensitive,
            self.allow_extra_source_columns,
            self.allow_missing_target_columns,
            self.warn_on_nullable_mismatch,
        )
        try:
            if validation_mode is not None:
                self.validation_mode = validation_mode
            if schema_case_sensitive is not None:
                self.schema_case_sensitive = schema_case_sensitive
            if allow_extra_source_columns is not None:
                self.allow_extra_source_columns = allow_extra_source_columns
            if allow_missing_target_columns is not None:
                self.allow_missing_target_columns = allow_missing_target_columns
            if warn_on_nullable_mismatch is not None:
                self.warn_on_nullable_mismatch = warn_on_nullable_mismatch

            problems = self._validate_against_target(df.schema, dest_schema)
            if problems:
                self.logger.warning("[validate_schemas] Problems found: %s", "; ".join(problems))
                return False

            self.logger.info("[validate_schemas] Validation passed for %s", target)
            return True
        finally:
            (
                self.validation_mode,
                self.schema_case_sensitive,
                self.allow_extra_source_columns,
                self.allow_missing_target_columns,
                self.warn_on_nullable_mismatch,
            ) = prev

    # -------------------------------------------------------------------------
    # Internals: base readers, read once
    # -------------------------------------------------------------------------

    def _base_reader(self):
        reader = (
            self.spark.read
            .option(Constants.WorkspaceId, self.workspace_id)
            .option(Constants.DatawarehouseId, self.warehouse_id)
            .option(Constants.DatabaseName, self.warehouse_name)
        )
        for k, v in (self.extra_read_options or {}).items():
            reader = reader.option(k, v)
        return reader

    def _read_table_once(self) -> DataFrame:
        w = self._quote_ident(self.warehouse_name)
        s = self._quote_ident(self.schema_name)
        t = self._quote_ident(self.table_name)

        # pushdown via T-SQL when requested
        if self.columns or self.predicate_sql or self.limit_rows is not None:
            select_cols = ", ".join(self._quote_ident(c) for c in (self.columns or ["*"]))
            top_clause = f"TOP ({self.limit_rows}) " if self.limit_rows is not None else ""
            where_clause = f" WHERE {self.predicate_sql}" if self.predicate_sql else ""
            t_sql = f"SELECT {top_clause}{select_cols} FROM {s}.{t}{where_clause}"
            self.logger.info("[AlkaliWH:sql_pushdown] %s", t_sql)

            df = self._base_reader().synapsesql(t_sql)
            if self.expect_schema is not None:
                self._validate_exact_schema(df, self.expect_schema)
            return df

        # non-pushdown table read via 3-part name
        table_3p = f"{w}.{s}.{t}"
        self.logger.info("[AlkaliWH:synapsesql_table] %s", table_3p)
        df = self._base_reader().synapsesql(table_3p)
        if self.expect_schema is not None:
            self._validate_exact_schema(df, self.expect_schema)
        return df

    def _read_select_once(self) -> DataFrame:
        self.logger.info("[AlkaliWH:select_sql_exec] warehouse=%s", self.warehouse_name)
        df = self._base_reader().synapsesql(self.select_sql)
        if self.expect_schema is not None:
            self._validate_exact_schema(df, self.expect_schema)
        return df

    # -------------------------------------------------------------------------
    # Shared: schema validation helpers
    # -------------------------------------------------------------------------

    def _validate_exact_schema(self, df: DataFrame, expect: StructType) -> None:
        act = df.schema
        if len(expect.fields) != len(act.fields):
            raise ValueError(f"Schema mismatch: expected {len(expect.fields)} fields, got {len(act.fields)}")
        for ef, af in zip(expect.fields, act.fields):
            if ef.name != af.name or ef.dataType != af.dataType or ef.nullable != af.nullable:
                raise ValueError(
                    f"Schema mismatch at field '{ef.name}': expected ({ef.dataType},{ef.nullable}) "
                    f"got ({af.dataType},{af.nullable})"
                )

    def _three_part(self, schema: str, table: str, database_name_override: Optional[str]) -> str:
        db = (database_name_override or self.warehouse_name).strip()
        return f"{db}.{schema}.{table}"

    def _quote_ident(self, name: str) -> str:
        if name is None:
            return "NULL"
        safe = name.replace("_", "")
        if not safe.isalnum() or any(ch in name for ch in " .,;`'\\\""):
            return f"[{name}]"
        return name

    # -------------------------------------------------------------------------
    # Writer internals: exists/schema/read/write with retry, union alignment, type checks
    # -------------------------------------------------------------------------

    def _table_exists(self, three_part: str) -> bool:
        self.logger.info("[exists_check:start] target=%s", three_part)
        try:
            self._run_with_retry(
                op_name="exists_check",
                func=lambda: (
                    self.spark.read
                    .option(Constants.WorkspaceId, self.workspace_id)
                    .option(Constants.DatawarehouseId, self.warehouse_id)
                    .synapsesql(three_part)
                    .limit(1)
                    .count()
                ),
                attempts=self.attempts_total,
                base_delay_sec=self.retry_base_delay_sec,
                max_delay_sec=self.retry_max_delay_sec,
                jitter_sec=self.retry_jitter_sec,
                sleep_fn=self.sleep_fn,
                logger=self.logger,
                retryable_exceptions=self.retryable_exceptions,
                duration_rounding="round",
                context=f"target={three_part}",
            )
            self.logger.info("[exists_check:success] target=%s", three_part)
            return True
        except AnalysisException as ae:
            self.logger.warning("[exists_check:not_found:AnalysisException] target=%s msg=%s", three_part, str(ae))
            return False
        except Exception as e:
            msg = str(e)
            known_nonexistence_signals = (
                "FabricSparkTDSReadError",
                "FabricSparkTDSInternalError",
                "Either source is invalid or user doesn't have read access",
                "Failed to lookup datamart by name",
            )
            if any(s in msg for s in known_nonexistence_signals):
                self.logger.warning("[exists_check:not_found:read_error] target=%s msg=%s", three_part, msg)
                return False
            self.logger.error("[exists_check:failed] target=%s err=%s", three_part, msg)
            raise

    def _fetch_target_schema(self, three_part: str) -> StructType:
        df0 = (
            self.spark.read
            .option(Constants.WorkspaceId, self.workspace_id)
            .option(Constants.DatawarehouseId, self.warehouse_id)
            .synapsesql(three_part)
            .limit(0)
        )
        return df0.schema

    def _read_with_retry(self, three_part: str) -> DataFrame:
        # keeping behavior consistent with writer: a direct read without retry wrapper
        return (
            self.spark.read
            .option(Constants.WorkspaceId, self.workspace_id)
            .option(Constants.DatawarehouseId, self.warehouse_id)
            .synapsesql(three_part)
        )

    def _write_with_retry(
        self,
        df: DataFrame,
        three_part: str,
        mode: str,
        writer_options: Optional[Dict[str, str]],
        truncate_destination_table: bool,
    ) -> None:
        def _do_write() -> None:
            writer = (
                df.write
                .mode(mode)
                .option(Constants.WorkspaceId, self.workspace_id)
                .option(Constants.DatawarehouseId, self.warehouse_id)
                .option("truncate", "true" if truncate_destination_table else "false")
            )
            if writer_options:
                for k, v in writer_options.items():
                    writer = writer.option(k, v)
            writer.synapsesql(three_part)

        self._run_with_retry(
            op_name="write",
            func=_do_write,
            attempts=self.attempts_total,
            base_delay_sec=self.retry_base_delay_sec,
            max_delay_sec=self.retry_max_delay_sec,
            jitter_sec=self.retry_jitter_sec,
            sleep_fn=self.sleep_fn,
            logger=self.logger,
            retryable_exceptions=self.retryable_exceptions,
            duration_rounding="round",
            context=f"target={three_part}, mode={mode}",
        )

    def _align_for_union(self, src: DataFrame, tgt: DataFrame):
        src_cols, tgt_cols = set(src.columns), set(tgt.columns)
        src_only, tgt_only = sorted(src_cols - tgt_cols), sorted(tgt_cols - src_cols)
        from pyspark.sql.functions import lit
        for c in tgt_only:
            src = src.withColumn(c, lit(None))
        for c in src_only:
            tgt = tgt.withColumn(c, lit(None))
        final_cols = src.columns + tgt_only
        return src.select(*final_cols), tgt.select(*final_cols)

    def _validate_against_target(self, src: StructType, dest: StructType) -> List[str]:
        problems: List[str] = []
        norm = (lambda s: s if self.schema_case_sensitive else s.lower())
        src_dict = {norm(f.name): f for f in src.fields}
        dest_dict = {norm(f.name): f for f in dest.fields}

        for col in sorted(src_dict.keys() & dest_dict.keys()):
            sfield = src_dict[col]
            dfield = dest_dict[col]
            if not self._types_compatible(sfield.dataType, dfield.dataType):
                problems.append(
                    f"Type mismatch for column '{dfield.name}': source={sfield.dataType}, "
                    f"destination={dfield.dataType} (mode={self.validation_mode})"
                )
            if self.warn_on_nullable_mismatch:
                if (not dfield.nullable) and sfield.nullable:
                    self.logger.warning(
                        "Nullability mismatch: destination '%s' is NOT NULL but source schema marks it nullable.",
                        dfield.name
                    )

        src_cols = set(src_dict.keys())
        dest_cols = set(dest_dict.keys())
        missing_in_source = sorted(dest_cols - src_cols)
        extra_in_source = sorted(src_cols - dest_cols)

        if missing_in_source and not self.allow_missing_target_columns:
            problems.append(f"Missing columns in source (required by destination): {missing_in_source}")
        if extra_in_source and not self.allow_extra_source_columns:
            problems.append(f"Extra columns in source (not present in destination): {extra_in_source}")
        return problems

    def _types_compatible(self, src_type: DataType, dest_type: DataType) -> bool:
        if self.validation_mode == "exact":
            return src_type == dest_type
        if src_type == dest_type:
            return True
        if isinstance(src_type, ByteType) and isinstance(dest_type, (ShortType, IntegerType, LongType)):
            return True
        if isinstance(src_type, ShortType) and isinstance(dest_type, (IntegerType, LongType)):
            return True
        if isinstance(src_type, IntegerType) and isinstance(dest_type, LongType):
            return True
        if isinstance(src_type, FloatType) and isinstance(dest_type, DoubleType):
            return True
        if isinstance(src_type, DecimalType) and isinstance(dest_type, DecimalType):
            return (src_type.precision <= dest_type.precision) and (src_type.scale <= dest_type.scale)
        if isinstance(src_type, DateType) and isinstance(dest_type, TimestampType):
            return True
        if isinstance(src_type, (ArrayType, MapType)) or isinstance(dest_type, (ArrayType, MapType)):
            return False
        if isinstance(src_type, (StringType, BooleanType, BinaryType)) or isinstance(dest_type, (StringType, BooleanType, BinaryType)):
            return src_type == dest_type
        return False

    # NOT NULL enforcement helpers (as in writer)
    def _assert_no_nulls(self, df: DataFrame, cols: Optional[Sequence[str]]) -> None:
        if not cols:
            return
        from pyspark.sql import functions as F
        for c in cols:
            if c in df.columns:
                if df.filter(F.col(c).isNull()).limit(1).count() > 0:
                    raise ValueError(f"[write] Column '{c}' contains NULLs but destination expects NOT NULL.")

    def _with_non_nullable(self, df: DataFrame, cols: Optional[Sequence[str]]) -> DataFrame:
        if not cols:
            return df
        fields: List[StructField] = []
        for f in df.schema.fields:
            if f.name in cols and f.nullable:
                fields.append(StructField(f.name, f.dataType, nullable=False, metadata=f.metadata))
            else:
                fields.append(f)
        new_schema = StructType(fields)
        return self.spark.createDataFrame(df.rdd, new_schema)

    def _enforce_non_nullable_hint(self, df: DataFrame, hint: Optional[Sequence[str]]) -> DataFrame:
        self._assert_no_nulls(df, hint)
