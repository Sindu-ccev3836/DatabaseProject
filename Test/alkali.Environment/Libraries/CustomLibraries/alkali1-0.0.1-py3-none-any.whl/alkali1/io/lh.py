# ===========================================================================
# File Path : alkali1/io/lh.py
# Version   : 1.0.22 (Complete, PC-driven schema history, API-compatible)
# ===========================================================================
# -*- coding: utf-8 -*-

"""
Alkali Lakehouse IO Helper

AUTHORITATIVE RESPONSIBILITIES
------------------------------
- Fabric OneLake ABFSS file access (ID-based only)
- Fabric Catalog table IO (FQN only)
- Schema lifecycle governance (INITIAL_CREATE, SCHEMA_MERGE)

SCHEMA HISTORY CONTRACT
-----------------------
The following PC parameters are AUTHORITATIVE and MUST be used to build
the schema history table FQN:

- schema_history_ws_name   (resolved from schema_history_ds)
- schema_history_ds_name
- schema_history_schema
- schema_history_table

The *_id parameters MUST be accepted for API compatibility but are NOT
used for FQN construction.

NO inference. NO spark.conf. NO defaults.
"""

from __future__ import annotations

import random
import time
import json
from typing import Any, Dict, Optional, List, Callable

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType
from pyspark.sql.functions import current_timestamp, lit

version = "1.0.22"

# -------------------------------------------------------------------------
# Retry helper
# -------------------------------------------------------------------------

def _with_retry(
    func: Callable[[], Any],
    *,
    retry_number: int,
    logger: Optional[Any],
    action_name: str,
    base_sleep: float = 0.5,
) -> Any:
    attempt = 0
    while True:
        try:
            return func()
        except Exception:
            attempt += 1
            if attempt > retry_number:
                if logger:
                    logger.error(
                        f"[alkali1.io.lh] Failed action={action_name}",
                        exc_info=True,
                    )
                raise
            time.sleep(base_sleep * (2 ** (attempt - 1)) + random.random())

# -------------------------------------------------------------------------
# Identifier helpers (Fabric Catalog FQN)
# -------------------------------------------------------------------------

def _needs_quoting(identifier: str) -> bool:
    import re
    return not re.match(r"^[A-Za-z_][A-Za-z0-9_]*$", identifier or "")

def quote_ident(identifier: str) -> str:
    if _needs_quoting(identifier):
        return f"`{identifier.replace('`', '``')}`"
    return identifier

def build_table_fqn(ws_name: str, ds_name: str, schema: str, table: str) -> str:
    return ".".join([
        quote_ident(ws_name),
        quote_ident(ds_name),
        quote_ident(schema),
        quote_ident(table),
    ])

# -------------------------------------------------------------------------
# ABFSS helpers (FILES ONLY — ID-based)
# -------------------------------------------------------------------------

def _normalize_relative_path(relative_path: str) -> str:
    return relative_path.lstrip("/").replace("\\", "/")

def build_files_abfss_path(
    ws_id: str,
    ds_id: str,
    relative_path: str,
) -> str:
    rp = _normalize_relative_path(relative_path)
    return f"abfss://{ws_id}@onelake.dfs.fabric.microsoft.com/{ds_id}/{rp}"

# -------------------------------------------------------------------------
# Filesystem adapter (Fabric)
# -------------------------------------------------------------------------

def _get_fs():
    from notebookutils import mssparkutils
    return mssparkutils.fs

def rename_file_abfss(
    src_path: str,
    dst_path: str,
    *,
    overwrite: bool = False,
    logger: Optional[Any] = None,
) -> None:
    fs = _get_fs()
    if overwrite and fs.exists(dst_path):
        fs.rm(dst_path)
    fs.mv(src_path, dst_path)

# -------------------------------------------------------------------------
# Table IO
# -------------------------------------------------------------------------

def read_table(
    spark: SparkSession,
    ws_id: Optional[str],
    ws_name: Optional[str],
    ds_id: Optional[str],
    ds_name: Optional[str],
    schema: str,
    table: str,
    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> DataFrame:
    fqn = build_table_fqn(ws_name, ds_name, schema, table)
    return _with_retry(
        lambda: spark.table(fqn),
        retry_number=retry_number,
        logger=logger,
        action_name="read_table",
    )

def write_table(
    spark: SparkSession,
    df: DataFrame,
    ws_id: Optional[str],
    ws_name: Optional[str],
    ds_id: Optional[str],
    ds_name: Optional[str],
    schema: str,
    table: str,
    mode: str = "append",
    auto_create_table_f: bool = True,
    allow_schema_merge: bool = False,

    # ✅ MUST remain for API compatibility
    schema_history_ws_id: Optional[str] = None,
    schema_history_ws_name: Optional[str] = None,
    schema_history_ds_id: Optional[str] = None,
    schema_history_ds_name: Optional[str] = None,
    schema_history_schema: Optional[str] = None,
    schema_history_table: Optional[str] = None,

    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> Dict[str, Any]:

    tgt_fqn = build_table_fqn(ws_name, ds_name, schema, table)

    schema_history_enabled = all([
        schema_history_ws_name,
        schema_history_ds_name,
        schema_history_schema,
        schema_history_table,
    ])

    table_exists = spark.catalog.tableExists(tgt_fqn)

    # ------------------------------------------------------------------
    # INITIAL CREATE
    # ------------------------------------------------------------------
    if not table_exists:
        if not auto_create_table_f:
            raise RuntimeError(f"Target table does not exist: {tgt_fqn}")

        df.write.format("delta").mode("overwrite").saveAsTable(tgt_fqn)

        if schema_history_enabled:
            _record_schema_history(
                spark=spark,
                history_ws_name=schema_history_ws_name,
                history_ds_name=schema_history_ds_name,
                history_schema=schema_history_schema,
                history_table=schema_history_table,
                ws_id=ws_id,
                ds_id=ds_id,
                ds_name=ds_name,
                target_schema=schema,
                target_table=table,
                change_type="INITIAL_CREATE",
                schema_diff_json=json.dumps(df.schema.jsonValue()),
            )

        return {"rows_written": df.count(), "change_type": "INITIAL_CREATE"}

    # ------------------------------------------------------------------
    # EXISTING TABLE
    # ------------------------------------------------------------------
    existing_schema: StructType = spark.table(tgt_fqn).schema
    incoming_schema: StructType = df.schema

    if existing_schema != incoming_schema and allow_schema_merge:
        (
            df.write.format("delta")
            .option("mergeSchema", "true")
            .mode(mode)
            .saveAsTable(tgt_fqn)
        )

        if schema_history_enabled:
            _record_schema_history(
                spark=spark,
                history_ws_name=schema_history_ws_name,
                history_ds_name=schema_history_ds_name,
                history_schema=schema_history_schema,
                history_table=schema_history_table,
                ws_id=ws_id,
                ds_id=ds_id,
                ds_name=ds_name,
                target_schema=schema,
                target_table=table,
                change_type="SCHEMA_MERGE",
                schema_diff_json=json.dumps(incoming_schema.jsonValue()),
            )

        return {"rows_written": df.count(), "change_type": "SCHEMA_MERGE"}

    # ------------------------------------------------------------------
    # NO SCHEMA CHANGE
    # ------------------------------------------------------------------
    df.write.format("delta").mode(mode).saveAsTable(tgt_fqn)
    return {"rows_written": df.count(), "change_type": "NO_CHANGE"}

# -------------------------------------------------------------------------
# Schema history writer (STRICT PC-FQN CONTRACT)
# -------------------------------------------------------------------------

def _record_schema_history(
    *,
    spark: SparkSession,
    history_ws_name: str,
    history_ds_name: str,
    history_schema: str,
    history_table: str,
    ws_id: str,
    ds_id: str,
    ds_name: str,
    target_schema: str,
    target_table: str,
    change_type: str,
    schema_diff_json: str,
) -> None:

    history_fqn = build_table_fqn(
        history_ws_name,
        history_ds_name,
        history_schema,
        history_table,
    )

    df = (
        spark.createDataFrame([{}])
        .withColumn("change_timestamp", current_timestamp())
        .withColumn("workspace_id", lit(ws_id))
        .withColumn("lakehouse_id", lit(ds_id))
        .withColumn("lakehouse_name", lit(ds_name))
        .withColumn("notebook_workspace_name", lit(None))
        .withColumn("notebook_name", lit(None))
        .withColumn("schema_name", lit(target_schema))
        .withColumn("table_name", lit(target_table))
        .withColumn("change_type", lit(change_type))
        .withColumn("changed_by", lit(None))
        .withColumn("old_ddl", lit(None))
        .withColumn("new_ddl", lit(None))
        .withColumn("ddl_path", lit(None))
        .withColumn("schema_diff_json", lit(schema_diff_json))
    )

    df.write.format("delta").mode("append").saveAsTable(history_fqn)

# -------------------------------------------------------------------------
# File IO
# -------------------------------------------------------------------------

def read_files(
    spark: SparkSession,
    ws_id: Optional[str],
    ws_name: Optional[str],
    ds_id: Optional[str],
    ds_name: Optional[str],
    relative_path: str,
    fmt: str,
    options: Optional[Dict[str, Any]] = None,
    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> DataFrame:
    path = build_files_abfss_path(ws_id, ds_id, relative_path)
    return _with_retry(
        lambda: spark.read.format(fmt).options(**(options or {})).load(path),
        retry_number=retry_number,
        logger=logger,
        action_name="read_files",
    )

def write_files(
    df: DataFrame,
    ws_id: Optional[str],
    ws_name: Optional[str],
    ds_id: Optional[str],
    ds_name: Optional[str],
    relative_path: str,
    fmt: str,
    mode: str = "append",
    options: Optional[Dict[str, Any]] = None,
    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> Dict[str, Any]:
    path = build_files_abfss_path(ws_id, ds_id, relative_path)

    def _write():
        (
            df.write
            .format(fmt)
            .mode(mode)
            .options(**(options or {}))
            .save(path)
        )

    _with_retry(
        _write,
        retry_number=retry_number,
        logger=logger,
        action_name="write_files",
    )

    return {"path": path}

# -------------------------------------------------------------------------
# Folder operations
# -------------------------------------------------------------------------

def folder_ls(
    ws_id: Optional[str],
    ws_name: Optional[str],
    ds_id: Optional[str],
    ds_name: Optional[str],
    relative_folder: str,
    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> List[Dict[str, Any]]:
    fs = _get_fs()
    path = build_files_abfss_path(ws_id, ds_id, relative_folder)
    return [{"path": f.path} for f in fs.ls(path)]

# -------------------------------------------------------------------------
# Legacy aliases (REQUIRED by built-in activities)
# -------------------------------------------------------------------------

read_files_abfss = read_files
write_files_abfss = write_files



# -------------------------------------------------------------------------
# Raw file write (NON-SPARK, FILES ONLY)
# -------------------------------------------------------------------------
def write_file_text(
    *,
    ws_id: str,
    ds_id: str,
    relative_path: str,
    content: str,
    overwrite: bool = True,
    retry_number: int = 0,
    logger: Optional[Any] = None,
) -> Dict[str, Any]:
    """
    Write raw text content to a Fabric Lakehouse Files path using ABFSS identity
    routing (NO Spark).

    Intended for control-plane I/O:
    - HTTP API payloads (JSON / XML / text)
    - Metadata sidecar files (*.meta.json)
    - Small config / audit artifacts

    MUST NOT be used for table I/O or bulk Spark writes.
    """

    # Build ABFSS path using authoritative helper
    path = build_files_abfss_path(
        ws_id=ws_id,
        ds_id=ds_id,
        relative_path=relative_path,
    )

    # Debug logging (safe, non-secret)
    if logger:
        logger.debug(
            "[alkali1.io.lh.write_file_text] Writing file",
            extra={
                "abfss_path": path,
                "overwrite": overwrite,
                "bytes": len(content.encode("utf-8")),
                "ws_id": ws_id,
                "ds_id": ds_id,
            },
        )

    def _write():
        fs = _get_fs()
        parent = path.rsplit("/", 1)[0]
        fs.mkdirs(parent)
        fs.put(path, content, overwrite=overwrite)

    # Execute with Alkali-standard retry semantics
    _with_retry(
        _write,
        retry_number=retry_number,
        logger=logger,
        action_name="write_file_text",
    )

    return {
        "path": path,
        "bytes_written": len(content.encode("utf-8")),
    }
