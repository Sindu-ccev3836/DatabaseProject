# alkali1/io/__init__.py

"""
Public IO API for Alkali Lakehouse.

This module defines the stable import surface.
Do NOT import from alkali1.io.lh or alkali1.io.fileloadctrl directly.
"""

# ---------------------------------------------------------------------
# Table & file IO (lh.py)
# ---------------------------------------------------------------------
from .lh import (
    read_table,
    write_table,
    read_files,
    write_files,
    folder_ls,
)

# ---------------------------------------------------------------------
# File load control (fileloadctrl.py)
# ---------------------------------------------------------------------
from .fileloadctrl import (
    insert_started,
    insert_succeeded,
    insert_failed,
    get_latest_status_map,
    find_zombies,
)

__all__ = [
    # lh.py
    "read_table",
    "write_table",
    "read_files",
    "write_files",
    "folder_ls",

    # fileloadctrl.py
    "insert_started",
    "insert_succeeded",
    "insert_failed",
    "get_latest_status_map",
    "find_zombies",
]
