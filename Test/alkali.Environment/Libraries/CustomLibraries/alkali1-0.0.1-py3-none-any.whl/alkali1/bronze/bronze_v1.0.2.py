"""
alkalietl.bronze
Bronze-layer ingestion helpers.

v1.0.2
- load_csv(): file-based watermarking using a control table.
- pipeline_run_id: propagated to control + target table to identify a run.
- purge_failed_load_f: clean up failed partial loads from previous and current runs.
- Control table extended with ETL context + loadg_dtm.
"""

from __future__ import annotations

from typing import Optional, Any, List, Tuple, Dict

from datetime import datetime

from pyspark.sql import SparkSession, DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType,
    StructField,
    StringType,
    LongType,
    TimestampType,
)

from alkalietl.io.lakehouse import AlkaliLH, RunStatus


__version__ = "1.0.2"


# ---------------------------------------------------------------------------
# Control table schema (file-based watermark + ETL context) v1.0.2
# ---------------------------------------------------------------------------

CTL_SCHEMA_STRUCT = StructType(
    [
        StructField("src_workspace_id", StringType(), False),
        StructField("src_lakehouse_id", StringType(), False),
        StructField("src_file_root", StringType(), True),
        StructField("file_path", StringType(), False),      # relative under Files
        StructField("file_name", StringType(), True),

        StructField("tgt_workspace_id", StringType(), False),
        StructField("tgt_lakehouse_id", StringType(), False),
        StructField("tgt_schema", StringType(), False),
        StructField("tgt_table", StringType(), False),

        StructField("etl_ws_id", StringType(), False),
        StructField("etl_ws_name", StringType(), False),
        StructField("etl_lh_id", StringType(), False),
        StructField("etl_lh_name", StringType(), False),
        StructField("notebook_name", StringType(), False),
        StructField("pipeline_run_id", StringType(), False),

        # Formerly etl_instance_id -> renamed to loadg_dtm (load generation datetime)
        StructField("loadg_dtm", TimestampType(), False),

        StructField("rows_ingested", LongType(), True),
        StructField("status", StringType(), False),         # SUCCESS / FAILED
        StructField("error_message", StringType(), True),
        StructField("schema_string", StringType(), True),
        StructField("ingested_at_utc", TimestampType(), False),
    ]
)


def _normalize_files_relative_path(path: str) -> str:
    """
    Normalise a Lakehouse Files path to a relative path under /Files.

    Accepts:
      - "/Files/foo/bar.csv"
      - "Files/foo/bar.csv"
      - "/File/foo/bar.csv"
      - "File/foo/bar.csv"
      - "foo/bar.csv"

    Returns:
      - "foo/bar.csv"
    """
    p = path.strip()
    while p.startswith("/"):
        p = p[1:]

    lower = p.lower()
    if lower.startswith("files/"):
        return p[6:]
    if lower.startswith("file/"):
        return p[5:]
    return p


def _build_lakehouse_name(prefix: str, lh_id: str) -> str:
    """
    Simple helper to derive a human-readable name for a lakehouse context.
    """
    short = lh_id[:8] if lh_id else "unknown"
    return f"{prefix}_{short}"


# ---------------------------------------------------------------------------
# Bronze load function (file-based watermark + purge_failed_load_f)
# ---------------------------------------------------------------------------

def load_csv(
    *,
    src_ws_id: str,
    src_lh_id: str,
    src_file_path: str,   # "/Files/..." or "Files/..." or relative under Files
    tgt_ws_id: str,
    tgt_lh_id: str,
    tgt_schema: str,
    tgt_table: str,
    ctl_ws_id: str,
    ctl_lh_id: str,
    ctl_schema: str,
    ctl_table: str,
    src_schema: Optional[StructType] = None,
    logger: Any = None,
    pipeline_run_id: Optional[str] = None,
    purge_failed_load_f: bool = False,
    notebook_name: Optional[str] = None,
) -> None:
    """
    Load CSV(s) from a source Lakehouse Files folder into a Bronze Delta table,
    using a file-based watermark stored in a shared control Delta table.

    Idempotency / duplication avoidance:
      - A file is considered already loaded if a control row exists with:
          src_ws_id, src_lh_id, src_file_root, file_path,
          tgt_ws_id, tgt_lh_id, tgt_schema, tgt_table,
          status = 'SUCCESS'
        In that case, the file is skipped (not even read).

    File-based watermark:
      - One control-table row per file per pipeline_run_id.
      - Key includes source, target, ETL context, notebook_name, pipeline_run_id.

    purge_failed_load_f (True/False):
      - If True:
        1) Before reading/loading a file, delete rows in the target table
           for any previous FAILED runs (file_path + pipeline_run_id) recorded
           in the control table.
        2) If ingestion of a file fails in the current run, delete rows in
           the target table for that file where:
             src_file_name = <file_name>
             AND pipeline_run_id = <current pipeline_run_id>

      - This relies on two columns being present in the target table:
            src_file_name STRING
            pipeline_run_id STRING

    Schema drift:
      - If src_schema is None, a unified schema is inferred across ALL CSV
        files under src_file_path using AlkaliLH.get_csv_common_schema().
      - New runs reuse this union schema so new files with extra/missing
        columns are tolerated.

    Parameters
    ----------
    src_ws_id, src_lh_id : str
        Source Lakehouse workspace & item IDs.
    src_file_path : str
        Folder or file under Lakehouse Files.
    tgt_ws_id, tgt_lh_id : str
        Target (Bronze) Lakehouse workspace & item IDs.
    tgt_schema, tgt_table : str
        Target Delta table location.
    ctl_ws_id, ctl_lh_id : str
        Control Lakehouse workspace & item IDs.
    ctl_schema, ctl_table : str
        Control Delta table location.
    src_schema : StructType, optional
        Explicit schema for CSV reading. If None, schema is unified across
        all CSV files using get_csv_common_schema.
    logger : any, optional
        Logger compatible with AlkaliLH logging.
    pipeline_run_id : str, optional
        Unique identifier for this pipeline run. If None, a timestamp-based
        ID is generated.
    purge_failed_load_f : bool, default False
        Enable cleanup of failed partial loads from previous and current runs.
    notebook_name : str, optional
        Name of the notebook or job, used in the control table for uniqueness.
    """
    spark = SparkSession.getActiveSession()
    if spark is None:
        raise RuntimeError("No active SparkSession found. Run inside Fabric Spark.")

    # pipeline_run_id default
    if pipeline_run_id is None:
        pipeline_run_id = datetime.utcnow().strftime("run_%Y%m%dT%H%M%S")

    if notebook_name is None:
        notebook_name = "unknown_notebook"

    # For ETL context, we assume ETL runs in the target workspace/lakehouse.
    etl_ws_id = tgt_ws_id
    etl_ws_name = _build_lakehouse_name("etl_ws", tgt_lh_id)
    etl_lh_id = tgt_lh_id
    etl_lh_name = _build_lakehouse_name("etl_lh", tgt_lh_id)

    # This datetime identifies the "load generation" moment.
    loadg_dtm = datetime.utcnow()

    # ----------------------------------------------------------------------
    # Initialise Alkali lakehouse helpers
    # ----------------------------------------------------------------------
    src_lh = AlkaliLH(
        spark=spark,
        lh_workspace_id=src_ws_id,
        lh_name=_build_lakehouse_name("src", src_lh_id),
        lh_id=src_lh_id,
        logger=logger,
    )
    tgt_lh = AlkaliLH(
        spark=spark,
        lh_workspace_id=tgt_ws_id,
        lh_name=_build_lakehouse_name("tgt", tgt_lh_id),
        lh_id=tgt_lh_id,
        logger=logger,
        default_schema=tgt_schema,
    )
    ctl_lh = AlkaliLH(
        spark=spark,
        lh_workspace_id=ctl_ws_id,
        lh_name=_build_lakehouse_name("ctl", ctl_lh_id),
        lh_id=ctl_lh_id,
        logger=logger,
        default_schema=ctl_schema,
    )

    src_rel = _normalize_files_relative_path(src_file_path)
    src_fs = src_lh._get_fs()
    src_base_abfss = src_lh._files_abfss_path(src_rel)

    extra_ctx = {
        "src_ws_id": src_ws_id,
        "src_lh_id": src_lh_id,
        "src_rel": src_rel,
        "tgt_ws_id": tgt_ws_id,
        "tgt_lh_id": tgt_lh_id,
        "tgt_schema": tgt_schema,
        "tgt_table": tgt_table,
        "ctl_ws_id": ctl_ws_id,
        "ctl_lh_id": ctl_lh_id,
        "ctl_schema": ctl_schema,
        "ctl_table": ctl_table,
        "pipeline_run_id": pipeline_run_id,
        "etl_ws_id": etl_ws_id,
        "etl_ws_name": etl_ws_name,
        "etl_lh_id": etl_lh_id,
        "etl_lh_name": etl_lh_name,
        "notebook_name": notebook_name,
        "purge_failed_load_f": purge_failed_load_f,
        "loadg_dtm": loadg_dtm.isoformat(),
    }

    if logger:
        logger.info("bronze.load_csv: start", extra=extra_ctx)

    # ----------------------------------------------------------------------
    # Discover CSV files in source folder (or the single file)
    # ----------------------------------------------------------------------
    if src_base_abfss.lower().endswith(".csv"):
        if not src_fs.exists(src_base_abfss):
            raise FileNotFoundError(
                f"Source CSV file not found: {src_base_abfss}"
            )
        csv_abfss_paths = [src_base_abfss]
    else:
        try:
            entries = src_fs.ls(src_base_abfss)
        except Exception as e:
            raise RuntimeError(
                f"Failed to list source path '{src_base_abfss}': "
                f"{type(e).__name__}: {e}"
            ) from e

        csv_abfss_paths = [
            e.path
            for e in entries
            if (not e.isDir) and e.path.lower().endswith(".csv")
        ]

    if not csv_abfss_paths:
        if logger:
            logger.info(
                "bronze.load_csv: no CSV files found at source path",
                extra={"src_base_abfss": src_base_abfss, **extra_ctx},
            )
        return

    files_root_prefix = src_lh.files_root_abfss.rstrip("/") + "/"

    # Derive relative file paths and names
    rel_paths: List[str] = []
    file_names: List[str] = []
    for p in csv_abfss_paths:
        if p.startswith(files_root_prefix):
            rel = p[len(files_root_prefix) :]
        else:
            rel = p  # fallback
        rel_paths.append(rel)
        file_names.append(rel.rsplit("/", 1)[-1] if "/" in rel else rel)

    src_file_root = src_rel  # normalised root spec

    # ----------------------------------------------------------------------
    # Read control table to find already processed files (SUCCESS)
    # and previously FAILED runs for purge
    # ----------------------------------------------------------------------
    processed_rel_paths: set[str] = set()
    failed_by_file: Dict[str, List[str]] = {}  # file_path -> [pipeline_run_id]
    ctl_path = build_table_abfss_path(
        lh_workspace_id=ctl_ws_id,
        lh_id=ctl_lh_id,
        schema_name=ctl_schema,
        table_name=ctl_table,
    )

    try:
        ctl_df_all = spark.read.format("delta").load(ctl_path)

        ctl_filtered = ctl_df_all.filter(
            (F.col("src_workspace_id") == src_ws_id)
            & (F.col("src_lakehouse_id") == src_lh_id)
            & (F.col("src_file_root") == src_file_root)
            & (F.col("tgt_workspace_id") == tgt_ws_id)
            & (F.col("tgt_lakehouse_id") == tgt_lh_id)
            & (F.col("tgt_schema") == tgt_schema)
            & (F.col("tgt_table") == tgt_table)
        )

        # SUCCESS paths (any pipeline_run_id)
        processed_rel_paths = {
            row["file_path"]
            for row in (
                ctl_filtered.filter(F.col("status") == "SUCCESS")
                .select("file_path")
                .distinct()
                .collect()
            )
        }

        if purge_failed_load_f:
            # FAILED paths + their pipeline_run_ids
            failed_rows = (
                ctl_filtered.filter(F.col("status") == "FAILED")
                .select("file_path", "pipeline_run_id")
                .collect()
            )
            for row in failed_rows:
                fp = row["file_path"]
                pr = row["pipeline_run_id"]
                failed_by_file.setdefault(fp, []).append(pr)

        if logger:
            logger.debug(
                "bronze.load_csv: loaded existing control rows",
                extra={
                    "ctl_path": ctl_path,
                    "already_processed_count": len(processed_rel_paths),
                    "failed_file_count": len(failed_by_file),
                    **extra_ctx,
                },
            )
    except Exception:
        # Control table may not exist yet – treat as first run.
        if logger:
            logger.debug(
                "bronze.load_csv: no existing control table or read failed; "
                "treating as first run for this feed",
                extra={**extra_ctx},
            )

    # Compute files to process (Guard 1: skip already-successfully-loaded files)
    to_process: List[Tuple[str, str, str]] = [
        (abfss, rel, fname)
        for abfss, rel, fname in zip(csv_abfss_paths, rel_paths, file_names)
        if rel not in processed_rel_paths
    ]

    if not to_process:
        if logger:
            logger.info(
                "bronze.load_csv: all files already processed; nothing to do",
                extra={
                    "total_files": len(csv_abfss_paths),
                    "processed_files": len(processed_rel_paths),
                    **extra_ctx,
                },
            )
        return

    if logger:
        logger.info(
            "bronze.load_csv: files selected for ingestion",
            extra={
                "total_files": len(csv_abfss_paths),
                "new_files": len(to_process),
                **extra_ctx,
            },
        )

    # ----------------------------------------------------------------------
    # Determine schema (schema drift support)
    # ----------------------------------------------------------------------
    if src_schema is not None:
        effective_schema = src_schema
        if logger:
            logger.debug(
                "bronze.load_csv: using provided src_schema",
                extra={**extra_ctx},
            )
    else:
        effective_schema = src_lh.get_csv_common_schema(
            lh_ws_id=src_ws_id,
            lh_id=src_lh_id,
            file_path=src_rel,
            skip_top_lines=1,          # assuming header
            sampling_ration="0.2",
        )
        if logger:
            logger.debug(
                "bronze.load_csv: inferred unified schema via get_csv_common_schema",
                extra={
                    "schema_string": effective_schema.simpleString(),
                    **extra_ctx,
                },
            )

    # ----------------------------------------------------------------------
    # For each file: optional purge of previous FAILED loads + ingest
    # ----------------------------------------------------------------------
    total_rows_ingested = 0

    for abfss_path, rel_path, file_name in to_process:
        file_ctx = {
            **extra_ctx,
            "file_abfss": abfss_path,
            "file_path": rel_path,
            "file_name": file_name,
        }

        # 1. Purge previous FAILED loads for this file if requested
        if purge_failed_load_f and rel_path in failed_by_file:
            failed_runs = failed_by_file[rel_path]
            if logger:
                logger.info(
                    "bronze.load_csv: purging previous FAILED loads for file",
                    extra={**file_ctx, "failed_runs": failed_runs},
                )

            # Best-effort delete from target table for all failed runs of this file
            for failed_pr in failed_runs:
                delete_sql = (
                    f"DELETE FROM {tgt_schema}.{tgt_table} "
                    f"WHERE src_file_name = '{file_name}' "
                    f"AND pipeline_run_id = '{failed_pr}'"
                )
                try:
                    spark.sql(delete_sql)
                    if logger:
                        logger.debug(
                            "bronze.load_csv: purged failed partial load from target",
                            extra={
                                **file_ctx,
                                "failed_pipeline_run_id": failed_pr,
                                "delete_sql": delete_sql,
                            },
                        )
                except Exception as e:
                    # Do not stop ingestion; log and continue
                    if logger:
                        logger.error(
                            "bronze.load_csv: failed to purge previous failed load "
                            "from target (ignored)",
                            extra={
                                **file_ctx,
                                "failed_pipeline_run_id": failed_pr,
                                "error_type": type(e).__name__,
                                "error_message": str(e),
                            },
                        )

        # 2. Ingest this file
        try:
            if logger:
                logger.info(
                    "bronze.load_csv: ingesting file",
                    extra=file_ctx,
                )

            df_file: DataFrame = (
                spark.read.schema(effective_schema)
                .option("header", "true")
                .csv(abfss_path)
                .withColumn("_src_file_path", F.input_file_name())
                .withColumn("_ingested_at_utc", F.current_timestamp())
                .withColumn("_src_workspace_id", F.lit(src_ws_id))
                .withColumn("_src_lakehouse_id", F.lit(src_lh_id))
                .withColumn("src_file_name", F.lit(file_name))
                .withColumn("pipeline_run_id", F.lit(pipeline_run_id))
            )

            row_count = df_file.count()
            total_rows_ingested += row_count

            # Guard 2 (within-run idempotency): clean any partial data from same run
            # for this file before writing, just in case of retries.
            if purge_failed_load_f:
                pre_delete_sql = (
                    f"DELETE FROM {tgt_schema}.{tgt_table} "
                    f"WHERE src_file_name = '{file_name}' "
                    f"AND pipeline_run_id = '{pipeline_run_id}'"
                )
                try:
                    spark.sql(pre_delete_sql)
                    if logger:
                        logger.debug(
                            "bronze.load_csv: pre-purged any partial data for current run/file",
                            extra={**file_ctx, "delete_sql": pre_delete_sql},
                        )
                except Exception as pre_del_err:
                    if logger:
                        logger.error(
                            "bronze.load_csv: failed to pre-purge data for current run/file "
                            "(ignored)",
                            extra={
                                **file_ctx,
                                "error_type": type(pre_del_err).__name__,
                                "error_message": str(pre_del_err),
                            },
                        )

            # Write to Bronze
            tgt_lh.write_table(
                df=df_file,
                schema=tgt_schema,
                table=tgt_table,
                mode="append",
                auto_create_table=True,
                auto_merge_schema=True,
            )

            # Write SUCCESS control row
            ctl_row = [
                (
                    src_ws_id,
                    src_lh_id,
                    src_file_root,
                    rel_path,
                    file_name,
                    tgt_ws_id,
                    tgt_lh_id,
                    tgt_schema,
                    tgt_table,
                    etl_ws_id,
                    etl_ws_name,
                    etl_lh_id,
                    etl_lh_name,
                    notebook_name,
                    pipeline_run_id,
                    loadg_dtm,
                    row_count,
                    "SUCCESS",
                    None,
                    effective_schema.simpleString(),
                    datetime.utcnow(),
                )
            ]
            ctl_df_to_write = spark.createDataFrame(
                ctl_row, schema=CTL_SCHEMA_STRUCT
            )

            ctl_lh.write_table(
                df=ctl_df_to_write,
                schema=ctl_schema,
                table=ctl_table,
                mode="append",
                auto_create_table=True,
                auto_merge_schema=True,
            )

            if logger:
                logger.info(
                    "bronze.load_csv: file ingested successfully",
                    extra={**file_ctx, "rows_ingested": row_count},
                )

        except Exception as e:
            # Best-effort cleanup for current run if requested
            if purge_failed_load_f:
                delete_sql = (
                    f"DELETE FROM {tgt_schema}.{tgt_table} "
                    f"WHERE src_file_name = '{file_name}' "
                    f"AND pipeline_run_id = '{pipeline_run_id}'"
                )
                try:
                    spark.sql(delete_sql)
                    if logger:
                        logger.debug(
                            "bronze.load_csv: purged partial data for current failed file",
                            extra={**file_ctx, "delete_sql": delete_sql},
                        )
                except Exception as purge_err:
                    if logger:
                        logger.error(
                            "bronze.load_csv: failed to purge partial data for "
                            "current failed file (ignored)",
                            extra={
                                **file_ctx,
                                "error_type": type(purge_err).__name__,
                                "error_message": str(purge_err),
                            },
                        )

            # Record FAILED in control table
            err_msg = str(e)
            if len(err_msg) > 4000:
                err_msg = err_msg[:4000]

            ctl_row = [
                (
                    src_ws_id,
                    src_lh_id,
                    src_file_root,
                    rel_path,
                    file_name,
                    tgt_ws_id,
                    tgt_lh_id,
                    tgt_schema,
                    tgt_table,
                    etl_ws_id,
                    etl_ws_name,
                    etl_lh_id,
                    etl_lh_name,
                    notebook_name,
                    pipeline_run_id,
                    loadg_dtm,
                    None,
                    "FAILED",
                    err_msg,
                    effective_schema.simpleString(),
                    datetime.utcnow(),
                )
            ]
            ctl_df_to_write = spark.createDataFrame(
                ctl_row, schema=CTL_SCHEMA_STRUCT
            )

            ctl_lh.write_table(
                df=ctl_df_to_write,
                schema=ctl_schema,
                table=ctl_table,
                mode="append",
                auto_create_table=True,
                auto_merge_schema=True,
            )

            if logger:
                logger.error(
                    "bronze.load_csv: file ingestion FAILED",
                    extra={
                        **file_ctx,
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                    },
                )
            # Re-raise to signal pipeline failure
            raise

    if logger:
        logger.info(
            "bronze.load_csv: completed successfully",
            extra={
                **extra_ctx,
                "files_ingested": len(to_process),
                "rows_total": total_rows_ingested,
            },
        )