# alkali/common/logger.py
"""
Description
-----------
Unified logging module for Alkali notebook workloads running on Microsoft Fabric.
It supports console logging in SGT and optional Delta Lake logging for centralized
pipeline/notebook observability.

AI contract
-----------
- Keep public APIs stable: `_get_notebook_name`, `_get_user_id`, and `get_logger`.
- Preserve log table column order and names in the Delta handler payload.
- Do not remove Fabric-safe fallbacks; runtime metadata lookups must fail safely.
- Prefer additive changes to log schema behavior unless explicitly requested.
"""

from __future__ import annotations

import logging
import sys
from typing import Optional, Dict, Any
from datetime import datetime, timezone

from pyspark.sql import SparkSession
from pyspark.sql.types import (
    StructType, StructField, StringType, TimestampType
)

# ETL run status (SUCCESS / FAILED)
from .status import RunStatus

# Singapore time helpers (module name: sgtime.py)
from .sgtime import get_sg_now, get_sg_now_str

# Fabric runtime utilities (safe import)
try:
    from notebookutils import mssparkutils  # type: ignore
except Exception:
    mssparkutils = None

__version__ = "1.0.4"


# ---------------------------------------------------------------------
# Notebook Context Helper
# ---------------------------------------------------------------------
def _get_notebook_name() -> str:
    """
    Return Fabric notebook name when running inside Fabric.
    Falls back to 'unknown_notebook' when unavailable.
    """
    if mssparkutils and hasattr(mssparkutils, "runtime"):
        try:
            return (
                mssparkutils.runtime.context.get("currentNotebookName")
                or "unknown_notebook"
            )
        except Exception:
            return "unknown_notebook"
    return "unknown_notebook"


def _get_user_id() -> str:
    """
    Return runtime user identity for the current notebook run.
    Resolution order:
    1) Email/UPN-like values (preferred, including mssparkutils.env.getUserName)
    2) Object id values (GUID), with currentUserId as last candidate
    3) Non-email user identity values (for display name fallback, including env username)
    4) "NA" when unavailable
    """
    if mssparkutils and hasattr(mssparkutils, "runtime"):
        try:
            ctx = mssparkutils.runtime.context
            env_username = None

            # Fabric env API can expose the current username/UPN in notebook runtime.
            if hasattr(mssparkutils, "env") and hasattr(mssparkutils.env, "getUserName"):
                try:
                    env_value = mssparkutils.env.getUserName()
                    if env_value:
                        env_username = str(env_value).strip()
                except Exception:
                    env_username = None

            email_like_keys = (
                "email",
                "mail",
                "upn",
                "userPrincipalName",
                "currentUser",
                "userName",
                "user",
            )
            non_email_identity_keys = (
                "currentUser",
                "userName",
                "user",
            )
            id_like_keys = (
                "userId",
                "oid",
                "objectId",
                "aadObjectId",
                "currentUserId",
            )

            # Prefer an address-like identity when available.
            if env_username and "@" in env_username:
                return env_username

            for key in email_like_keys:
                value = ctx.get(key)
                if value:
                    candidate = str(value).strip()
                    if "@" in candidate:
                        return candidate

            # Fall back to object id values (GUID), currentUserId checked last.
            for key in id_like_keys:
                value = ctx.get(key)
                if value:
                    candidate = str(value).strip()
                    if candidate:
                        return candidate

            # Fall back to non-email identity values (often display names).
            if env_username:
                return env_username

            for key in non_email_identity_keys:
                value = ctx.get(key)
                if value:
                    candidate = str(value).strip()
                    if candidate:
                        return candidate
        except Exception:
            return "NA"
    return "NA"


def _get_workspace_name() -> str:
    """
    Return current Fabric workspace name.
    Falls back to "NA" when unavailable.
    """
    if not mssparkutils:
        return "NA"

    # Prefer env API in Fabric runtime.
    if hasattr(mssparkutils, "env") and hasattr(mssparkutils.env, "getWorkspaceName"):
        try:
            value = mssparkutils.env.getWorkspaceName()
            if value:
                candidate = str(value).strip()
                if candidate:
                    return candidate
        except Exception:
            pass

    # Secondary fallback via runtime context if present.
    if hasattr(mssparkutils, "runtime"):
        try:
            ctx = mssparkutils.runtime.context
            for key in ("workspaceName", "currentWorkspaceName"):
                value = ctx.get(key)
                if value:
                    candidate = str(value).strip()
                    if candidate:
                        return candidate
        except Exception:
            pass

    return "NA"


# ---------------------------------------------------------------------
# Console Logging Handler (SGT)
# ---------------------------------------------------------------------
def _create_console_handler(log_level: int):
    """
    Console handler with:
    - SGT formatted timestamps
    - auto 'source' using notebook name
    - default 'context' based on module.funcName
      (top-level logs use 'notebook.<module>')
    """
    handler = logging.StreamHandler()

    log_format = "%(asctime)s %(levelname)s %(source)s %(context)s %(message)s"

    from zoneinfo import ZoneInfo

    class SGTFormatter(logging.Formatter):
        def formatTime(self, record, datefmt=None):
            dt = datetime.fromtimestamp(record.created, tz=ZoneInfo("Asia/Singapore"))
            return dt.strftime("%Y-%m-%d %H:%M:%S.%f")

    handler.setFormatter(SGTFormatter(log_format))

    class SourceFilter(logging.Filter):
        def filter(self, record):
            if not hasattr(record, "source") or not record.source:
                record.source = _get_notebook_name()
            return True

    class ContextFilter(logging.Filter):
        def filter(self, record):
            # Only set context if caller did not provide one
            if not hasattr(record, "context") or not record.context:
                module_name = getattr(record, "module", None) or "notebook"
                func_name = getattr(record, "funcName", None) or "<module>"

                # If log originates from top-level code, normalise module to 'notebook'
                if func_name == "<module>":
                    module_name = "notebook"

                record.context = f"{module_name}.{func_name}"
            return True

    handler.addFilter(SourceFilter())
    handler.addFilter(ContextFilter())
    handler.setLevel(log_level)
    return handler


# ---------------------------------------------------------------------
# Delta Lake Handler — writes logs to Lakehouse Delta table
# ---------------------------------------------------------------------
def _create_delta_handler(
    spark: SparkSession,
    lh_workspace_id: str,
    lh_id: str,
    lh_table_path: str,  # path under /Tables (e.g. "log/nb_logs")
    log_level: int,
    batch_workspace_id: Optional[str],
    batch_pipeline_name: Optional[str],
    batch_pipeline_id: Optional[str],
):
    """
    Writes log rows to Delta via ABFSS:
    abfss://<workspace>@onelake.dfs.fabric.microsoft.com/<lakehouse>/Tables/<path>

    Schema must match the Lakehouse table, e.g. log.nb_logs:
        log_time_utc TIMESTAMP NOT NULL
        log_time_sgt STRING NOT NULL
        log_level STRING NOT NULL
        notebook_name STRING
        context STRING
        log_message STRING NOT NULL
        user_id STRING NOT NULL
        workspace_id STRING
        workspace_name STRING
        pipeline_name STRING
        pipeline_id STRING
    """
    full_path = (
        f"abfss://{lh_workspace_id}"
        f"@onelake.dfs.fabric.microsoft.com/{lh_id}/Tables/{lh_table_path}"
    )

    schema = StructType(
        [
            StructField("log_time_utc", TimestampType(), False),
            StructField("log_time_sgt", StringType(), False),
            StructField("log_level", StringType(), False),
            StructField("notebook_name", StringType(), True),
            StructField("context", StringType(), True),
            StructField("log_message", StringType(), False),
            StructField("user_id", StringType(), False),
            StructField("workspace_id", StringType(), True),
            StructField("workspace_name", StringType(), True),
            StructField("pipeline_name", StringType(), True),
            StructField("pipeline_id", StringType(), True),
        ]
    )

    class DeltaHandler(logging.Handler):
        def emit(self, record):
            try:
                # 1) UTC timestamp for log_time_utc (naive, as expected by Delta TIMESTAMP)
                now_utc = datetime.now(timezone.utc).replace(tzinfo=None)

                # 2) SGT ISO-8601 string for log_time_sgt
                now_sgt_str = get_sg_now_str()

                # 3) Runtime user id for auditability in notebook logs
                user_id = _get_user_id()

                # 4) Workspace name from Fabric runtime
                workspace_name = _get_workspace_name()

                log_row = [
                    (
                        now_utc,  # log_time_utc
                        now_sgt_str,  # log_time_sgt
                        record.levelname,  # log_level
                        getattr(record, "source", None),  # notebook_name
                        getattr(record, "context", None),  # context
                        record.getMessage(),  # log_message
                        user_id,  # user_id
                        batch_workspace_id,  # workspace_id
                        workspace_name,  # workspace_name
                        batch_pipeline_name,  # pipeline_name
                        batch_pipeline_id,  # pipeline_id
                    )
                ]
                df = spark.createDataFrame(log_row, schema=schema)
                (
                    df.write
                    .format("delta")
                    .mode("append")
                    .save(full_path)
                )
            except Exception as e:
                sys.stderr.write(
                    f"[AlkaliLogger] Failed to write to {full_path}: {e}\n"
                )

    handler = DeltaHandler()
    handler.setLevel(log_level)

    # Attach same contextual filters as console handler
    class SourceFilter(logging.Filter):
        def filter(self, record):
            if not hasattr(record, "source") or not record.source:
                record.source = _get_notebook_name()
            return True

    class ContextFilter(logging.Filter):
        def filter(self, record):
            # Only set context if caller did not provide one
            if not hasattr(record, "context") or not record.context:
                module_name = getattr(record, "module", None) or "notebook"
                func_name = getattr(record, "funcName", None) or "<module>"

                # Top-level → normalise module to 'notebook'
                if func_name == "<module>":
                    module_name = "notebook"

                record.context = f"{module_name}.{func_name}"
            return True

    handler.addFilter(SourceFilter())
    handler.addFilter(ContextFilter())
    return handler


# ---------------------------------------------------------------------
# AlkaliLogger façade
# ---------------------------------------------------------------------
class AlkaliLogger:
    """
    Unified logger façade for the Alkali ETL Framework.

    - debug(): milestone logs
    - info(): general info logs
    - error(): structured error logging
    - success(): ETL SUCCESS log
    - failed(): ETL FAILED log

    v1.0.4:
    - Uses stacklevel=2 so that context reflects the *caller* of AlkaliLogger,
      not this wrapper class itself.
    """

    def __init__(self, logger: logging.Logger):
        self._logger = logger

    def debug(self, msg: str, extra: Optional[Dict[str, Any]] = None):
        self._logger.debug(msg, extra=extra or {}, stacklevel=2)

    def info(self, msg: str, extra: Optional[Dict[str, Any]] = None):
        self._logger.info(msg, extra=extra or {}, stacklevel=2)

    
    #
    def warn(self, msg: str, extra: Optional[Dict[str, Any]] = None):
        """
        Warning-level log (non-fatal issues, retries, recoverable conditions).
        """
        self._logger.warning(msg, extra=extra or {}, stacklevel=2)

    #
    def warning(self, msg: str, extra: Optional[Dict[str, Any]] = None):
        """
        Alias for warn(), compatible with logging.Logger.warning().
        """
        self.warn(msg, extra=extra)



    def error(
        self,
        msg: str,
        extra: Optional[Dict[str, Any]] = None,
        exc: Exception = None,
        exc_info=None
    ):
        if exc:
            self._logger.error(
                msg,
                extra=extra or {},
                exc_info=True,
                stacklevel=2,
            )
        else:
            self._logger.error(msg, extra=extra or {}, stacklevel=2)

    def success(self, action: str, extra: Optional[Dict[str, Any]] = None):
        """
        Convenience method for logging a SUCCESS end state.
        """
        self.info(f"{action} {RunStatus.SUCCESS}", extra=extra)

    def failed(self, action: str, extra: Optional[Dict[str, Any]] = None):
        """
        Convenience method for logging a FAILED end state.
        """
        self.info(f"{action} {RunStatus.FAILED}", extra=extra)


# ---------------------------------------------------------------------
# get_logger() – Public factory
# ---------------------------------------------------------------------
def get_logger(
    spark: SparkSession,
    name: str,
    *,
    log_level: str = "INFO",
    lh_workspace_id: Optional[str] = None,
    lh_id: Optional[str] = None,
    lh_table_path: Optional[str] = None,
    batch_workspace_id: Optional[str] = None,
    batch_pipeline_name: Optional[str] = None,
    batch_pipeline_id: Optional[str] = None,
) -> AlkaliLogger:
    """
    Create a unified AlkaliLogger with:
    - Console logging (SGT)
    - Optional Delta Lake logging (UTC + SGT string)

    Parameters
    ----------
    spark : SparkSession
    name : str
        Logger name
    log_level : str
        "DEBUG", "INFO", "ERROR", "WARNING", "CRITICAL"
    lh_workspace_id : str, optional
        Target Lakehouse workspace GUID
    lh_id : str, optional
        Target Lakehouse GUID
    lh_table_path : str, optional
        Folder path under /Tables in the Lakehouse (e.g. "log/nb_logs")
    batch_workspace_id : str, optional
    batch_pipeline_name : str, optional
    batch_pipeline_id : str, optional
    """
    level_map = {
        "DEBUG": logging.DEBUG,
        "INFO": logging.INFO,
        "ERROR": logging.ERROR,
        "WARNING": logging.WARNING,
        "WARN": logging.WARNING,
        "CRITICAL": logging.CRITICAL,
    }
    final_level = level_map.get(log_level.upper(), logging.INFO)

    base_logger = logging.getLogger(name)

    # Prevent attaching duplicate handlers if called multiple times with same name
    if not base_logger.handlers:
        base_logger.setLevel(final_level)
        base_logger.propagate = False

        # Console handler
        base_logger.addHandler(_create_console_handler(final_level))

        # Optional Delta handler
        if lh_workspace_id and lh_id and lh_table_path:
            base_logger.addHandler(
                _create_delta_handler(
                    spark=spark,
                    lh_workspace_id=lh_workspace_id,
                    lh_id=lh_id,
                    lh_table_path=lh_table_path,
                    log_level=final_level,
                    batch_workspace_id=batch_workspace_id,
                    batch_pipeline_name=batch_pipeline_name,
                    batch_pipeline_id=batch_pipeline_id,
                )
            )

    return AlkaliLogger(base_logger)