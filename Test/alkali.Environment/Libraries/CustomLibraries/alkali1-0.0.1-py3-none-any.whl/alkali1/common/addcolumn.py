from typing import List, Optional
from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql import types as T


def add_hash_column(
    df: DataFrame,
    cols_to_hash: List[str],
    hash_col_name: str = "row_hash",
    guid_cols: Optional[List[str]] = None,
    date_only_cols: Optional[List[str]] = None,
) -> DataFrame:
    """
    v1.0.0 – aligned with [EDM_STDFB].[SP_BUILD_HASH_EXPRESSION] v3.1.0

    - Buckets columns by type (exact numeric, approx numeric, datetime, character,
      binary, GUID) using Spark types.
    - Added 'date_only_cols' parameter to allow explicitly specifying which
      columns should be treated as SQL DATE (serialized as 'yyyy-MM-dd') vs
      DATETIME/DATETIME2 (serialized as 'yyyy-MM-dd HH:mm:ss.SSS').

    Per-type serialization:

    * Exact numeric: Byte/Short/Int/Long/Decimal
        -> CAST(CAST(col AS DECIMAL(38,6)) AS STRING), NULL -> '<NULL>'

    * Approx numeric: Double/Float
        -> ROUND(col, 5) -> DECIMAL(38,6) -> STRING, NULL -> '<NULL>'

    * Date/time:
        - Columns in 'date_only_cols':
              'yyyy-MM-dd'
        - Other date/time columns:
              'yyyy-MM-dd HH:mm:ss.SSS'
        NULL -> '<NULL>'

    * Character: StringType (not in guid_cols)
        - Normalize newlines: CRLF & CR -> LF
        - utf-8 bytes -> hex text (uppercase)
        - NULL -> '<NULL>'

    * Binary: BinaryType
        - hex text (uppercase), NULL -> '<NULL>'

    * GUID: StringType in guid_cols
        -> string (VARCHAR(36)), NULL -> '<NULL>'

    All serialized values are concatenated with '\n' in this bucket order:
        1) Exact numeric
        2) Approx numeric
        3) Date/time
        4) Character
        5) Binary
        6) GUID

    Then SHA2_256 is applied over UTF-8, returned as 64-char uppercase hex.
    """

    guid_cols = set(guid_cols or [])
    date_only_cols = set(date_only_cols or [])

    schema_by_name = {field.name: field.dataType for field in df.schema.fields}

    # Buckets
    exact_cols: List[str] = []
    approx_cols: List[str] = []
    dt_cols: List[str] = []
    char_cols: List[str] = []
    bin_cols: List[str] = []
    guid_cols_bucket: List[str] = []

    # --- Bucket columns by Spark type ---
    for col_name in cols_to_hash:
        if col_name not in schema_by_name:
            raise ValueError(f"Column '{col_name}' not found in DataFrame schema.")
        dtype = schema_by_name[col_name]

        if isinstance(dtype, (T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.DecimalType)):
            exact_cols.append(col_name)
        elif isinstance(dtype, (T.DoubleType, T.FloatType)):
            approx_cols.append(col_name)
        elif isinstance(dtype, (T.TimestampType, T.DateType)):
            dt_cols.append(col_name)
        elif isinstance(dtype, T.BinaryType):
            bin_cols.append(col_name)
        elif isinstance(dtype, T.StringType):
            if col_name in guid_cols:
                guid_cols_bucket.append(col_name)
            else:
                char_cols.append(col_name)
        else:
            raise TypeError(f"Unsupported data type for column '{col_name}': {dtype}")

    serialized_exprs = []

    # --- Exact numerics: DECIMAL(38,6) -> string ---
    for col_name in exact_cols:
        col = F.col(col_name)
        dec = col.cast("decimal(38,6)")
        ser = F.when(dec.isNull(), F.lit("<NULL>")).otherwise(dec.cast("string"))
        serialized_exprs.append(ser)

    # --- Approx numerics: ROUND(col, 5) -> DECIMAL(38,6) -> string ---
    for col_name in approx_cols:
        col = F.col(col_name)
        rounded = F.round(col.cast("double"), 5)
        dec = rounded.cast("decimal(38,6)")
        ser = F.when(dec.isNull(), F.lit("<NULL>")).otherwise(dec.cast("string"))
        serialized_exprs.append(ser)

    # --- Date/time: DATE vs DATETIME/DATETIME2 based on 'date_only_cols' ---
    for col_name in dt_cols:
        col = F.col(col_name)

        if col_name in date_only_cols:
            # Treat as SQL DATE: 'yyyy-MM-dd'
            d = col.cast("date")
            ser_d = F.date_format(d, "yyyy-MM-dd")
            ser = F.when(d.isNull(), F.lit("<NULL>")).otherwise(ser_d)
        else:
            # Treat as SQL datetime/datetime2: 'yyyy-MM-dd HH:mm:ss.SSS'
            ts = col.cast("timestamp")
            ser_ts = F.date_format(ts, "yyyy-MM-dd HH:mm:ss.SSS")
            ser = F.when(ts.isNull(), F.lit("<NULL>")).otherwise(ser_ts)

        serialized_exprs.append(ser)

    # --- Character: CRLF/CR -> LF, then bytes->hex (uppercase) ---
    for col_name in char_cols:
        col = F.col(col_name)
        norm = F.regexp_replace(col, r"\r\n", "\n")
        norm = F.regexp_replace(norm, r"\r", "\n")
        bin_col = F.encode(norm, "UTF-8")
        hex_text = F.upper(F.hex(bin_col))
        ser = F.when(col.isNull(), F.lit("<NULL>")).otherwise(hex_text)
        serialized_exprs.append(ser)

    # --- Binary: VARBINARY -> hex (uppercase) ---
    for col_name in bin_cols:
        col = F.col(col_name)
        hex_text = F.upper(F.hex(col))
        ser = F.when(col.isNull(), F.lit("<NULL>")).otherwise(hex_text)
        serialized_exprs.append(ser)

    # --- GUID: string form, NULL -> '<NULL>' ---
    for col_name in guid_cols_bucket:
        col = F.col(col_name)
        ser_str = col.cast("string")
        ser = F.when(ser_str.isNull(), F.lit("<NULL>")).otherwise(ser_str)
        serialized_exprs.append(ser)

    # --- Final concat & hash ---
    if not serialized_exprs:
        hash_input = F.lit("<NO_COLS>")
    else:
        hash_input = F.concat_ws("\n", *serialized_exprs)

    hash_hex = F.upper(F.sha2(hash_input, 256))
    return df.withColumn(hash_col_name, hash_hex)