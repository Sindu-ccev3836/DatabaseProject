%%sql

CREATE TABLE IF NOT EXISTS log.log_notebook
(
    log_time TIMESTAMP NOT NULL,
    log_level STRING NOT NULL,
    notebook_name STRING,
    context STRING,
    log_message STRING NOT NULL,
    pipeline_workspace_id STRING,
    pipeline_name STRING,
    pipeline_id STRING
)
USING DELTA
LOCATION 'abfss://e443e6c7-15d5-43a2-aa8f-4e95baf4073c@onelake.dfs.fabric.microsoft.com/35af3c5b-cf27-4b62-8454-897b91dbb32e/Tables/log/log_notebook';


%%sql

CREATE TABLE IF NOT EXISTS log.log_notebook
(
    -- Dual timestamps
    log_time_utc   TIMESTAMP       NOT NULL,   -- ALWAYS stored in UTC
    log_time_sgt   STRING          NOT NULL,   -- EXACT SGT string (ISO8601)

    -- Log metadata
    log_level              STRING  NOT NULL,
    notebook_name          STRING,
    context                STRING,
    log_message            STRING  NOT NULL,

    -- Pipeline metadata
    pipeline_workspace_id  STRING,
    pipeline_name          STRING,
    pipeline_id            STRING
)
USING DELTA
LOCATION 'abfss://e443e6c7-15d5-43a2-aa8f-4e95baf4073c@onelake.dfs.fabric.microsoft.com/35af3c5b-cf27-4b62-8454-897b91dbb32e/Tables/log/nb_logs';