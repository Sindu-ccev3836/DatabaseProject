
"""
RunStatus enum for the Alkali framework.

Used across:
- IO (AlkaliLH)
- Bronze / Silver / Gold ETL steps
- ETL logging and monitoring
"""


# ---------------------------------------------------------------------
# RunStatus – unified SUCCESS / FAILED enum for ETL
# ---------------------------------------------------------------------
class RunStatus:
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"