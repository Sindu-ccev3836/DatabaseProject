# alkali/common/sg_time.py

from datetime import datetime
from zoneinfo import ZoneInfo

_SG_TZ = ZoneInfo("Asia/Singapore")


def get_sg_now():
    """
    Return the current Singapore local time (SGT, UTC+8)
    as a naive datetime (tz removed) for Delta Lake TIMESTAMP columns.
    """
    return datetime.now(_SG_TZ).replace(tzinfo=None)


def get_sg_now_str():
    """
    Return current Singapore local time as an ISO-8601 string.
    Format: 'YYYY-MM-DDTHH:MM:SS.ssssss'

    Example:
    '2026-03-21T20:45:10.123456'
    """
    return datetime.now(_SG_TZ).isoformat(timespec="microseconds")